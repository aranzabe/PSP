/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objects;

import java.util.concurrent.Semaphore;

/**
 *
 * @author jorge
 */
public class Casilla {

    private TipoItem tipo;
    private int valor;
    private Semaphore sem;

    public Casilla() {
        this.tipo = (int) (Math.random() * 2 + 1) == 1 ? TipoItem.ORO : TipoItem.VIDA;
        this.valor = (int) (Math.random() * 100 + 1);
        this.sem=new Semaphore(1);
    }

    public TipoItem getTipo() {
        return tipo;
    }

    public int getValor() {
        return valor;
    }    

    void acceder() throws InterruptedException {
        sem.acquire();
    }

    void salir() {
        sem.release();
    }
}
