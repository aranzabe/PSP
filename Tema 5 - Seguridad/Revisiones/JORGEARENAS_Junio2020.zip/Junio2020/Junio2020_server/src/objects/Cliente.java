/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objects;

import java.io.IOException;
import java.net.Socket;

/**
 *
 * @author jorge
 */
public class Cliente {
    private Socket socket;
    private String name;
    private int vida,oro;
    
    public Cliente(String name,Socket socket) {
        this.socket = socket;
        this.name = name;
        this.vida=0;
        this.oro=0;
    }

    public Socket getSocket() {
        return socket;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getVida() {
        return vida;
    }

    public int getOro() {
        return oro;
    }

    void addOro(int valor) {
        this.oro+=valor;
    }

    void addVida(int valor) {
        this.vida+=valor;
    }

    public void desconectar() throws IOException {
        socket.close();
    }
    
    
    
}
