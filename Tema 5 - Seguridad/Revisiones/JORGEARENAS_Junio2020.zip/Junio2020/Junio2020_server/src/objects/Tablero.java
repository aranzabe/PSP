/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objects;

/**
 *
 * @author jorge
 */
public class Tablero {

    private Casilla[][] tablero;
    private int contador;

    public Tablero(int filas, int columnas) {
        this.tablero = new Casilla[filas][columnas];
        this.contador = contador;
        for (int x = 0; x < tablero.length; x++) {
            for (int y = 0; y < tablero[0].length; y++) {
                tablero[x][y] = new Casilla();
            }
        }
    }

    public Casilla[][] getTablero() {
        return tablero;
    }

    public int getContador() {
        return contador;
    }

    public void acceder() {
        this.contador++;
    }

    public int filas() {
        return tablero.length;
    }

    public int columnas() {
        return tablero[0].length;
    }

    public String obtenValor(int fila, int columna, Cliente cliente, Escritor e) throws Exception {
        Casilla c = this.tablero[fila][columna];
        String msg="";
        if (c != null) {
            c.acceder();
            if (c.getTipo() == TipoItem.ORO) {
                cliente.addOro(c.getValor());
                msg="Has obtenido " + c.getValor() + " unidades de oro. tienes "+cliente.getOro();
            } else {
                cliente.addVida(c.getValor());
                msg="Has obtenido " + c.getValor() + " unidades de vida. tienes "+cliente.getVida();
            }
            c.salir();
            this.tablero[fila][columna] = null;
        } else {
            msg="La casilla está vacia. pierdes turno.";
        }
        return msg;
        
    }

    public void reponerCasilla(int fila, int colum) {
        if(tablero[fila][colum]==null){
            tablero[fila][colum]=new Casilla();
        }
    }

    public synchronized boolean todasVacias() {
        boolean vacias=true;         
        for (int i = 0; i < tablero.length&&vacias; i++) {
            for (int j = 0; j < tablero[0].length&&vacias; j++) {
                if(tablero[i][j]!=null)
                    vacias=false;
            }
        }
        return vacias;
    }

    public void abandonar() {
        this.contador--;
    }

}
