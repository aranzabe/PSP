/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor;

import java.io.*;
import java.net.*;
import java.security.*;
import java.util.ArrayList;
import javax.crypto.SealedObject;
import objects.*;
import seguridad.Seguridad;

/**
 *
 * @author jorge
 */
public class Servidor {

    private static final int NUMTABLEROS = 3, FILAS = 4, COLUMS = 4;
    private static ArrayList<Cliente> clientes;
    public static void main(String[] args) throws Exception {
        Socket cliente;
        ServerSocket servidor = new ServerSocket(9000);
        clientes=new ArrayList<>();
        Tablero[] tableros = new Tablero[NUMTABLEROS];
        for (int i = 0; i < tableros.length; i++) {
            tableros[i] = new Tablero(FILAS, COLUMS);
        }
        HiloReponedor rep = new HiloReponedor(tableros);
        rep.start();
        System.out.println("Servidor iniciado...");
        while (true) {
            cliente = servidor.accept();
            Claves claves = new Claves();
            Escritor e = new Escritor(cliente, claves);
            generaymandaclaves(claves, e);
            Cliente c=new Cliente("", cliente);
            Hilo h = new Hilo(c, tableros, e, rep);
            h.start();
        }

    }

    private static void generaymandaclaves(Claves claves, Escritor escritor) throws Exception {
        //Generamos ambas claves
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        keyGen.initialize(2048);
        KeyPair par = keyGen.generateKeyPair();
        claves.setPrivada(par.getPrivate());
        claves.setPublica(par.getPublic());

        //Recibimos la clave del otro extremo
        claves.setOtroExtremo((PublicKey) escritor.ois().readObject());
        //Mandamos la clave publica al otro extremo
        escritor.oos().writeObject(claves.getPublica());
    }
    
    static void guardaInfo(Cliente cliente) {
        clientes.add(cliente);        
    }

}
