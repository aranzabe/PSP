/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor;

import java.io.IOException;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import objects.*;

/**
 *
 * @author jorge
 */
public class Hilo extends Thread {
    
    private Cliente cliente;
    private Tablero tablero;
    private Tablero[] tableros;
    private Escritor e;
    private HiloReponedor rep;
    private static final int NUMJUGADORES = 5;

    Hilo(Cliente cliente, Tablero[] tableros, Escritor escritor,HiloReponedor rep) {
        this.cliente = cliente;
        this.tableros = tableros;
        this.e = escritor;
        this.rep=rep;
    }

    @Override
    public void run() {
        try {
            e.escribir("Indique su nombre: ");
            String name = (String) e.leer();
            cliente.setName(name);
            int numTab;
            do {
                String cad = "¿En qué tablero quiere jugar?";
                for (int i = 0; i < tableros.length; i++) {
                    int n = i + 1;
                    cad += "\n" + n + ". tablero " + n;
                }
                e.escribir(cad);
                numTab = (int) e.leer();
                if (numTab < 1 || numTab > tableros.length) {
                    e.escribir(true);
                }
            } while (numTab < 1 || numTab > tableros.length);
            e.escribir(true);
            this.tablero = tableros[numTab];
            entrarTablero();
            System.out.println(name + " se ha conectado al tablero " + numTab);
            jugar();
            e.escribir("El juego ha concluido, Muchas gracias!"
                    + "\n--------------------------------------"
                    + "\nOro conseguido: "+cliente.getOro()
                    + "\nVida conseguida: "+cliente.getVida()); 
            
        }catch(SocketException se){
            Servidor.guardaInfo(cliente);
            tablero.abandonar();
            System.out.println(cliente.getName()+" se ha desconectado.");            
        } catch (Exception ex) {
            ex.printStackTrace();
        }finally{
            try {
                cliente.desconectar();
            } catch (IOException ex) {
                Logger.getLogger(Hilo.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private synchronized void entrarTablero() throws Exception {
        if (tablero.getContador() < NUMJUGADORES) {
            e.escribir("ha accedido al tablero con éxito");
            tablero.acceder();
            /*if (tablero.getContador() == NUMJUGADORES) {
                notifyAll();
            } else {
                wait();
            }
            e.escribir("empezamos");*/
        } else {
            e.escribir("El tablero está completo");
            System.out.println(cliente.getName() + " ha sido expulsado.");
            //e.escribir("Lo sentimos, intentelo de nuevo mas tarde");
            cliente.desconectar();
        }

    }

    private void jugar() throws Exception {
        int fila, columna;
        while (!rep.isFin() && !tablero.todasVacias()) {
            e.escribir(true);
            do {
                e.escribir(true);
                e.escribir("Introduzca la fila a la que desea acceder (1," + tablero.filas() + "): ");
                fila = ((int) e.leer()) - 1;
            } while (fila < 0 || fila > tablero.filas() - 1);
            e.escribir(false);
            do {
                e.escribir(true);
                e.escribir("Introduzca la columna a la que desea acceder (1," + tablero.columnas() + "): ");
                columna = ((int) e.leer()) - 1;
            } while (columna < 0 || columna > tablero.columnas() - 1);
            e.escribir(false);
            String msg = tablero.obtenValor(fila, columna, cliente, e);
            e.escribir(msg);

        }
        e.escribir(false);                
    }

}
