/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor;

import java.util.logging.Level;
import java.util.logging.Logger;
import objects.Casilla;
import objects.Tablero;

/**
 *
 * @author jorge
 */
public class HiloReponedor extends Thread {

    private Tablero[] tableros;
    private boolean fin = false;
    private static final int SEGUNDOS = 300, PLAZO = 30;

    public HiloReponedor(Tablero[] tableros) {
        this.tableros = tableros;
    }

    public boolean isFin() {
        return fin;
    }

    @Override
    public void run() {
        int contador = 0;
        try {
            while (contador < SEGUNDOS) {
                reponer();
                sleep(PLAZO * 1000);
                contador += PLAZO;
                System.out.println("reponiendo tableros");
            }
            //juego finalizado
            fin = true;
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
    }

    private synchronized void reponer() {
        for (int i = 0; i < tableros.length; i++) {
            Casilla[][] tab = tableros[i].getTablero();
            for (int x = 0; x < tab.length; x++) {
                for (int y = 0; y < tab[0].length; y++) {
                    tableros[i].reponerCasilla(x, y);
                }
            }
        }
    }

}
