/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

import java.io.EOFException;
import java.net.*;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Scanner;
import objects.Claves;
import objects.Escritor;
import seguridad.Seguridad;

/**
 *
 * @author jorge
 */
public class Cliente {

    private static Scanner sc = new Scanner(System.in);
    private static Escritor e;

    public static void main(String[] args) throws Exception {
        Socket servidor = null;
        try {
            InetAddress dir = InetAddress.getLocalHost();
            servidor = new Socket(dir, 9000);
            Claves claves = new Claves();
            e = new Escritor(servidor, claves);
            generaymandaclaves(claves, e);
            System.out.print(e.leer());
            e.escribir(sc.next());
            do {
                System.out.println((String) e.leer());
                e.escribir(sc.nextInt());
            } while (!((boolean) e.leer()));
            System.out.println(e.leer());            
            jugar();    
            System.out.println(e.leer());

        } catch (EOFException eo) {
            System.out.println("Ha sido desconectado del servidor");
        }catch(SocketException se){
            System.out.println("El servidor se ha desconectado");       
        } catch (Exception e) {
            System.out.println("ERROR");
            e.printStackTrace();
        } finally {
            servidor.close();
        }
    }

    private static void generaymandaclaves(Claves claves, Escritor escritor) throws Exception {
        //Generamos ambas claves
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        keyGen.initialize(2048);
        KeyPair par = keyGen.generateKeyPair();
        claves.setPrivada(par.getPrivate());
        claves.setPublica(par.getPublic());

        //Mandamos la clave publica al otro extremo
        escritor.oos().writeObject(claves.getPublica());
        //Recibimos la clave del otro extremo
        claves.setOtroExtremo((PublicKey) escritor.ois().readObject());
    }

    private static void jugar() throws Exception {
        while ((boolean)e.leer()) {
            while ((boolean) e.leer()) {
                System.out.println(e.leer());
                e.escribir(sc.nextInt());                
            }
            while ((boolean) e.leer()) {
                System.out.println(e.leer());
                e.escribir(sc.nextInt());
            }
            System.out.println(e.leer());            
        }
        
    }
}
