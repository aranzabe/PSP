/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor;

import baseDatos.Conexion;
import java.io.*;
import java.net.*;
import java.security.*;
import java.sql.*;

/**
 *
 * @author jorge
 */
public class Server {

    public static void main(String[] args) throws Exception {
        ServerSocket servidor = new ServerSocket(1050);
        Socket cliente = servidor.accept();
        DataInputStream dis = new DataInputStream(cliente.getInputStream());
        DataOutputStream dos = new DataOutputStream(cliente.getOutputStream());
        String usuario,pass;
        Conexion conex=new Conexion();
        while (true) {
            /* 0 -> Registrar
               1 -> Logear*/
            int op = dis.readInt();
            switch(op){
                case 0:
                    usuario=dis.readUTF();
                    pass=dis.readUTF();                    
                    conex.abrirConexion();
                    conex.insertarDato("user", usuario, pass);                    
                    conex.cerrarConexion();
                    dos.writeBoolean(true);
                    break;
                case 1:
                    usuario=dis.readUTF();
                    pass=dis.readUTF();                    
                    conex.abrirConexion();
                    String passEnBDD=conex.obtenerValor("user", usuario, "pass");
                    if(MessageDigest.isEqual(pass.getBytes(), passEnBDD.getBytes())){
                        dos.writeBoolean(true);
                    }else dos.writeBoolean(false);
                    conex.cerrarConexion();
                    break;

            }
        }
    }

    private static String hexadecimal(byte[] resumen) {
        String hex = "";
        for (int i = 0; i < resumen.length; i++) {
            String h = Integer.toHexString(resumen[i] & 0xFF);
            if (h.length() == 1) {
                hex += 0;
            }
            hex += h;
        }
        return hex;
    }
}
