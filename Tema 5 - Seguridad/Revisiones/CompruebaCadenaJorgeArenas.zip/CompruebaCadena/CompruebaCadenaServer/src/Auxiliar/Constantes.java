/*
 * Esta clase es muy recomendable, para centralizar aquí los datos comunes de la aplicación.
 */
package Auxiliar;

/**
 *
 * @author fernando
 */
public class Constantes {
    public static String bbdd = "psp";
    public static String usuario = "root";
    public static String passwd = "";
    
    public static String TablaUsuarios = "user";
    
    public static String ficheroBitacora = "bitacora.txt";
}
