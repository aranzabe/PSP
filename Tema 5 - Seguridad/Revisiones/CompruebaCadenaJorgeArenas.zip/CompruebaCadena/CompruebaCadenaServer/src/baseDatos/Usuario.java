/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package baseDatos;

/**
 *
 * @author faranzabe
 */
public class Usuario {

    private String usuario;
    private String passwd;

    public Usuario() {
    }

    public Usuario(String usuario, String passwd) {
        this.usuario = usuario;
        this.passwd = passwd;
    }

    public String getDNI() {
        return usuario;
    }

    public void setDNI(String DNI) {
        this.usuario = DNI;
    }

    public String getNombre() {
        return passwd;
    }

    public void setNombre(String Nombre) {
        this.passwd = Nombre;
    }

    @Override
    public String toString() {
        return "Persona{" + "DNI=" + usuario + ", Nombre=" + passwd + '}';
    }

}
