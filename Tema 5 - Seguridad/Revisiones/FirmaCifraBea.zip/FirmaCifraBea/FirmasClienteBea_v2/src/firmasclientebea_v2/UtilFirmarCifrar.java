/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package firmasclientebea_v2;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.SignatureException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

/**
 *
 * @author beani
 */
public class UtilFirmarCifrar {
    
    public byte[]  firmar (String mensaje, PrivateKey pri){
        byte[] firma = null;
        try {
            
            Signature dsa = Signature.getInstance("SHA1withDSA");
            dsa.initSign(pri);
            dsa.update(mensaje.getBytes());
            firma = dsa.sign(); //Mensaje firmado.
            
            
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(UtilFirmarCifrar.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InvalidKeyException ex) {
            Logger.getLogger(UtilFirmarCifrar.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SignatureException ex) {
            Logger.getLogger(UtilFirmarCifrar.class.getName()).log(Level.SEVERE, null, ex);
        }
        return firma;
    }
    
    public byte[] cifrar (SecretKey claveSecreta, String mensaje){
        byte [] TextoCifrado = null;
        try {
            Cipher c = Cipher.getInstance("AES/ECB/PKCS5Padding");
            c.init(Cipher.ENCRYPT_MODE, claveSecreta);
            //Realizamos el cifrado de la información con el método doFinal().
            //Cifraremos el siguiente texto plano:
            byte []TextoPlano = mensaje.getBytes();
            TextoCifrado = c.doFinal(TextoPlano);
        } catch (InvalidKeyException ex) {
            Logger.getLogger(UtilFirmarCifrar.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalBlockSizeException ex) {
            Logger.getLogger(UtilFirmarCifrar.class.getName()).log(Level.SEVERE, null, ex);
        } catch (BadPaddingException ex) {
            Logger.getLogger(UtilFirmarCifrar.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(UtilFirmarCifrar.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchPaddingException ex) {
            Logger.getLogger(UtilFirmarCifrar.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return TextoCifrado;

    }
    
}
