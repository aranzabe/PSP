/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package firmasclientebea_v2;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author beani
 */
public class FirmasClienteBea_v2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            // TODO code application logic here
            
            InetAddress dir;
            Socket servidor;

            dir = InetAddress.getLocalHost();
            servidor = new Socket(dir, 5000);
            
            Ventana v = new Ventana(servidor);
            v.setVisible(true);
            
        } catch (UnknownHostException ex) {
            Logger.getLogger(FirmasClienteBea_v2.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FirmasClienteBea_v2.class.getName()).log(Level.SEVERE, null, ex);
        }
            
            
    }
    
}
