/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package firmasservidorbea_v2;


import Datos.Firma;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectInputStream;
import java.net.Socket;
import java.security.PublicKey;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.SecretKey;

/**
 *
 * @author beani
 */
public class Hilo extends Thread{
    private Socket s;
    
    public Hilo(Socket s){
        this.s = s;
    }

    @Override
    public void run() {
        
        try {
            DataOutputStream dos = new DataOutputStream(s.getOutputStream());
            DataInputStream dis = new DataInputStream(s.getInputStream());
            ObjectInputStream ois = new ObjectInputStream(s.getInputStream());
            UtilFirmarCifrar util = new UtilFirmarCifrar();
            PublicKey clavePublica = (PublicKey) ois.readObject();
            SecretKey claveSecreta = (SecretKey) ois.readObject();
            int op;
            while (true) {
                op = dis.readInt();
                
                if (op == 0) { 
                    String mensaje;
                    byte  []firma;
                    Firma f =(Firma) ois.readObject();

                    mensaje = f.getMensaje();
                    firma = f.getFirma();
                        
                    if (util.verifica(clavePublica, mensaje, firma)) {
                        dos.writeInt(1);
                    } else {
                        dos.writeInt(0);
                    }
                    
                } else if(op == 1){
                    
                    byte[] cifrado=(byte[]) ois.readObject();
                    String mensaje=util.desencriptar(cifrado, claveSecreta);
                    System.out.println("El cliente ha enviado el siguiente mensaje: "+mensaje);    
                    
                }else if (op == 2){
                    byte[] firma = (byte[]) ois.readObject();
                    System.out.println(new String(firma)+" FIRMA");
                    byte[] ci = (byte[]) ois.readObject();
                    System.out.println(new String (ci)+ "CIFRADO");
                    String mensaje = util.desencriptar(ci, claveSecreta);
                    
                    if (util.verifica(clavePublica, mensaje, firma)) {
                        dos.writeInt(1);
                    } else {
                        dos.writeInt(0);
                    }
                }
            }
            
        } catch (Exception ex) {
            Logger.getLogger(Hilo.class.getName()).log(Level.SEVERE, null, ex);
        }  
        
                        
    }    
    
    
}
