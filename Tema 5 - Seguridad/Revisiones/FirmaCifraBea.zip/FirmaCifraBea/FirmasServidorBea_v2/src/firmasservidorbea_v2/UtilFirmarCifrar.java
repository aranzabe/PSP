/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package firmasservidorbea_v2;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.Signature;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

/**
 *
 * @author beani
 */
public class UtilFirmarCifrar {
    
    public boolean verifica(PublicKey clavePublica, String mensaje, byte[] firma) throws Exception {
        Signature verifica_dsa = Signature.getInstance("SHA1withDSA");
        verifica_dsa.initVerify(clavePublica);

        //msg = "Otra cosa";
        verifica_dsa.update(mensaje.getBytes());
        return verifica_dsa.verify(firma);

    }

    public String desencriptar(byte[] cifrado, SecretKey claveSecreta) {
        byte []Desencriptado = null;
        try {
            Cipher c = Cipher.getInstance("AES/ECB/PKCS5Padding");
            c.init(Cipher.DECRYPT_MODE, claveSecreta);
            Desencriptado = c.doFinal(cifrado);
            //System.out.println("Desencriptado: " + new String(Desencriptado));
            
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(UtilFirmarCifrar.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchPaddingException ex) {
            Logger.getLogger(UtilFirmarCifrar.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InvalidKeyException ex) {
            Logger.getLogger(UtilFirmarCifrar.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalBlockSizeException ex) {
            Logger.getLogger(UtilFirmarCifrar.class.getName()).log(Level.SEVERE, null, ex);
        } catch (BadPaddingException ex) {
            Logger.getLogger(UtilFirmarCifrar.class.getName()).log(Level.SEVERE, null, ex);
        }
        return new String(Desencriptado);
    }
}
