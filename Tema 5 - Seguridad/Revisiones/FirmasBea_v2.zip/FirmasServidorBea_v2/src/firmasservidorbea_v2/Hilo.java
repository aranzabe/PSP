/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package firmasservidorbea_v2;

import Datos.Firma;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author beani
 */
public class Hilo extends Thread{
    private Socket s;
    
    public Hilo(Socket s){
        this.s = s;
    }

    @Override
    public void run() {
        
        
        while(true){
            boolean primeraVez = true;
            try {
                ObjectInputStream  ois = new ObjectInputStream(s.getInputStream());
                DataOutputStream enviar = new DataOutputStream(s.getOutputStream());
                String mensaje;
                byte  []firma;
                PublicKey  clavepubl= null;

                Firma f =(Firma) ois.readObject();
                if(primeraVez){
                    mensaje = f.getMensaje();
                    firma = f.getFirma();
                    clavepubl = f.getPublickey();
                }else{
                    mensaje = f.getMensaje();
                    firma = f.getFirma();
                }
                

                //El receptor del mensaje, verifica con clave pública
                //el mensaje firmado.
                Signature verifica_dsa = Signature.getInstance("SHA1withDSA");
                verifica_dsa.initVerify(clavepubl);

                mensaje = "jejeje";
                verifica_dsa.update(mensaje.getBytes());
                boolean check = verifica_dsa.verify(firma);
               if (check) enviar.writeInt(1);
                else       enviar.writeInt(0);
            } catch (NoSuchAlgorithmException ex) {

            } catch (IOException ex) {

            } catch (SignatureException ex) {

            } catch (ClassNotFoundException ex) {

            } catch (InvalidKeyException ex) {

            }
        }
    }
    
    
    
}
