/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package firmasservidorbea;

import Datos.Firma;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author beani
 */
public class Hilo extends Thread{
    private Socket s;

    public Hilo(Socket s) {
        this.s = s;
    }

    @Override
    public void run() {
        try {
            ObjectInputStream  ois = new ObjectInputStream(s.getInputStream());
            DataOutputStream enviar = new DataOutputStream(s.getOutputStream());
            String mensaje;
            byte  []firma;
            PublicKey  clavepubl;
            
            Firma f =(Firma) ois.readObject();
            
            mensaje = f.getMensaje();
            firma = f.getFirma();
            clavepubl = f.getPublickey();
            
            //El receptor del mensaje, verifica con clave pública
            //el mensaje firmado.
            Signature verifica_dsa = Signature.getInstance("SHA1withDSA");
            verifica_dsa.initVerify(clavepubl);
            
            //mensaje = "jejeje";
            verifica_dsa.update(mensaje.getBytes());
            boolean check = verifica_dsa.verify(firma);
            if (check) enviar.writeUTF("FIRMA VERIFICADA");
            else       enviar.writeUTF("Firma no verificada");
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(Hilo.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Hilo.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SignatureException ex) {
            Logger.getLogger(Hilo.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Hilo.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InvalidKeyException ex) {
            Logger.getLogger(Hilo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
}
