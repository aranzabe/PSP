/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package firmasclientebea;

import Datos.Firma;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.SignatureException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author beani
 */
public class FirmasCLienteBea {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        InetAddress dir;
        Socket servidor;
        
        
        try {

            dir = InetAddress.getLocalHost();
            servidor = new Socket(dir, 5000);
            
            
            BufferedReader bf = new BufferedReader(new InputStreamReader (System.in));
            String mensaje ="";
            
            //La clase KeyPairGenerator nos permite gernerar el par de claves.
            KeyPairGenerator keyGen = KeyPairGenerator.getInstance("DSA");
            //Se inicia el generador de claves. Se usa el método initialize y le 
            //pasamos dos argumentos, el tamaño de la clave y un generador de números 
            //aleatorios.
            //  - El tamaño de un generador de claves DSA (en bits) estará entre 512 y 1024
            //    En cualquier caso múltiplos de 64, en caso contrario da error.
            //  - Como generador de números aleatorios podemos usar una instancia de
            //    SecureRandom.
            SecureRandom numero = SecureRandom.getInstance("SHA1PRNG");
            keyGen.initialize(1024, numero);
                
            
            //Creamos el par de claves (privada y pública).
            KeyPair par = keyGen.generateKeyPair();
            PrivateKey clavepriv = par.getPrivate();
            PublicKey  clavepubl = par.getPublic();
            
            //Firmamos con la clave privada el mensaje.
            //Al especificar el nombre del algoritmo de firma se debe especificar, también,
            //el nombre del algoritmo resumen utilizado por el algoritmo de firma.
            //Tendremos dos:
            //  - SHAwithDSA --> firma con DSA resumen con SHA.
            //  - MD5withRSA --> firma con RSA resumen con MD5.
            Signature dsa = Signature.getInstance("SHA1withDSA");
            dsa.initSign(clavepriv);
            
            System.out.println("Introduce un mensaje para firmar");
            mensaje = bf.readLine();
            dsa.update(mensaje.getBytes());
            
            byte []firma = dsa.sign(); //Mensaje firmado.
            
            
            ObjectOutputStream  oos = new ObjectOutputStream(servidor.getOutputStream());
            DataInputStream recibir = new DataInputStream(servidor.getInputStream());
            
            Firma f = new Firma(mensaje, firma, clavepubl);
            
            oos.writeObject(f);
            System.out.println(recibir.readUTF());
           
        } catch (IOException ex) {
            
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(FirmasCLienteBea.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InvalidKeyException ex) {
            Logger.getLogger(FirmasCLienteBea.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SignatureException ex) {
            Logger.getLogger(FirmasCLienteBea.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
}
