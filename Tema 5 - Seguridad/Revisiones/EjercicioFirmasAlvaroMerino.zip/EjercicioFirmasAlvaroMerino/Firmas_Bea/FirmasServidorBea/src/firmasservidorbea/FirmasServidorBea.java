/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package firmasservidorbea;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author beani
 */
public class FirmasServidorBea {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            // TODO code application logic here
            ServerSocket ss = new ServerSocket(5000);
            Socket s;
            System.out.println("Arrancando servidor");
            while(true){
                s = ss.accept();

                Hilo h = new Hilo (s);
                h.start();
                
            }
        } catch (IOException ex) {
            Logger.getLogger(FirmasServidorBea.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
