package firmaservidor_flor;

import datos.Firma;
import java.io.ObjectInputStream;
import java.net.Socket;
import utils.UtilFirma;

/**
 *
 * @author Flor
 */
class Hilo extends Thread {

    Socket cliente;

    Hilo(Socket cliente) {
        this.cliente = cliente;
    }

    @Override
    public void run() {
        try {
            boolean valide = false;
            Firma f;

            while (!valide) {
                ObjectInputStream ois = new ObjectInputStream(cliente.getInputStream());
                f = (Firma) ois.readObject();

                UtilFirma.verificarFirma(f.getMensaje(), f.getFirma(), f.getClavePublica());

            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

}
