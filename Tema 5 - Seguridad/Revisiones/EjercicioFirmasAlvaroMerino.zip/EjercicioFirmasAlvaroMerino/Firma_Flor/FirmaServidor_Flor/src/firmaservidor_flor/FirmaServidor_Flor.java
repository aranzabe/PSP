
package firmaservidor_flor;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author Flor
 */
public class FirmaServidor_Flor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            ServerSocket ss = new ServerSocket(50000);
            Socket cliente;
            while (true) {
                cliente = ss.accept();
                Hilo h = new Hilo(cliente);
                h.start();
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
    
}
