/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import datos.Firma;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.SignatureException;

/**
 *
 * @author Flor
 */
public class UtilFirma {

    public static Firma verificarFirma(String mensaje, byte[] firma, PublicKey clavepubl) {
        Firma f = null;

        try {
            //Firmamos con la clave privada el mensaje.
            //  - SHAwithDSA --> firma con DSA resumen con SHA.
            //  - MD5withRSA --> firma con RSA resumen con MD5.
            Signature verifica = Signature.getInstance("SHA1withDSA");
            verifica.initVerify(clavepubl);

            verifica.update(mensaje.getBytes());
            boolean check = verifica.verify(firma);
            if (check) System.out.println("OK");
            else       System.out.println("Firma no verificada");

        } catch (NoSuchAlgorithmException | InvalidKeyException | SignatureException ex) {
        }

        return f;
    }
}
