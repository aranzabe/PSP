/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1.firmaserver;

import Mensaje.Mensaje;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.Signature;
import java.security.SignatureException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author anfur
 */
public class HiloServer extends Thread{
    private Socket cliente;

    public HiloServer(Socket cliente) {
        this.cliente = cliente;
    }
    
    
    
    @Override
    public void run(){
        try {
            Mensaje mensajeServer;
            
            ObjectOutputStream oos = new ObjectOutputStream(cliente.getOutputStream());
            ObjectInputStream ois = new ObjectInputStream(cliente.getInputStream());
            
            mensajeServer=(Mensaje) ois.readObject();
            
            System.out.println("El mensaje firmado es: "+mensajeServer.getMensaje());
            
            //El receptor del mensaje, verifica con clave pública
            //el mensaje firmado.
            Signature verifica_dsa = Signature.getInstance("SHA1withDSA");
            verifica_dsa.initVerify(mensajeServer.getClavePublica());

            //mensajeServer.setMensaje("Otra cosa");
            verifica_dsa.update(mensajeServer.getMensaje().getBytes());
            boolean check = verifica_dsa.verify(mensajeServer.getMensajeBytes());
            if (check) System.out.println("OK");
            else       System.out.println("Firma no verificada");
        } catch (IOException ex) {
            Logger.getLogger(HiloServer.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(HiloServer.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InvalidKeyException ex) {
            Logger.getLogger(HiloServer.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(HiloServer.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SignatureException ex) {
            Logger.getLogger(HiloServer.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
}
