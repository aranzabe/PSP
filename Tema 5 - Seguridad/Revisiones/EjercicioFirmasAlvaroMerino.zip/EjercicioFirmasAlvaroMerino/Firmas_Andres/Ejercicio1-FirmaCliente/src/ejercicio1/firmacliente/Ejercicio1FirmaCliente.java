/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1.firmacliente;

import Mensaje.Mensaje;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.SignatureException;

/**
 *
 * @author anfur
 */
public class Ejercicio1FirmaCliente {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, NoSuchAlgorithmException, InvalidKeyException, SignatureException{
        Socket server;
        InetAddress ip;

        ip=InetAddress.getLocalHost();
        server = new Socket (ip,1234);
        ObjectOutputStream oos = new ObjectOutputStream(server.getOutputStream());
        ObjectInputStream ois = new ObjectInputStream(server.getInputStream());
        Mensaje mensajeCliente = new Mensaje();
        
        //La clase KeyPairGenerator nos permite gernerar el par de claves.
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("DSA");
        
        SecureRandom numero = SecureRandom.getInstance("SHA1PRNG");
        keyGen.initialize(1024, numero);

        //Creamos el par de claves (privada y pública).
        KeyPair par = keyGen.generateKeyPair();
        PrivateKey clavepriv = par.getPrivate();
        PublicKey  clavepubl = par.getPublic();
        mensajeCliente.setClavePublica(clavepubl);
        //Iniciamos la firma del mensaje con la clave privada
        Signature dsa = Signature.getInstance("SHA1withDSA");
        dsa.initSign(clavepriv);
        
        String cadena="MensajeFirmado";
        mensajeCliente.setMensaje(cadena);
        dsa.update(cadena.getBytes());
        byte []firma = dsa.sign(); //Mensaje firmado.
        mensajeCliente.setMensajeBytes(firma);
        
        System.out.println("El mensaje que se enviará es: "+mensajeCliente.getMensaje());
        
        oos.writeObject(mensajeCliente);
            
    }
    
    
    
}
