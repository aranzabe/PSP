/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mensaje;

import java.io.Serializable;
import java.security.PublicKey;

/**
 *
 * @author anfur
 */
public class Mensaje implements Serializable{
    private String mensaje;
    private PublicKey clavePublica;
    private byte[] mensajeBytes;

    public Mensaje(String mensaje, PublicKey clavePublica, byte[] mensajeBytes) {
        this.mensaje = mensaje;
        this.clavePublica = clavePublica;
        this.mensajeBytes = mensajeBytes;
    }

    public Mensaje() {
    }
    
    

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public PublicKey getClavePublica() {
        return clavePublica;
    }

    public void setClavePublica(PublicKey clavePublica) {
        this.clavePublica = clavePublica;
    }

    public byte[] getMensajeBytes() {
        return mensajeBytes;
    }

    public void setMensajeBytes(byte[] mensajeBytes) {
        this.mensajeBytes = mensajeBytes;
    }
    
    
    
}
