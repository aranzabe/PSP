/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package encdescservidorbea;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

/**
 *
 * @author beani
 */
public class EncDescServidorBea {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            // TODO code application logic here

            ServerSocket ss = new ServerSocket(1050);
            Socket s;
            System.out.println("Arrancando servidor");
            s = ss.accept();
            
            
            ObjectOutputStream oos = new ObjectOutputStream (s.getOutputStream());
            ObjectInputStream ois = new ObjectInputStream(s.getInputStream());
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); 
            
            
            
            //Se crean el par de claves públicas y privada.
            KeyPairGenerator KeyGen = KeyPairGenerator.getInstance("RSA");
            KeyGen.initialize(1024);
            KeyPair par = KeyGen.generateKeyPair();
            PrivateKey clavepriv = par.getPrivate();
            PublicKey clavepubl = par.getPublic();
            PublicKey claveCliente = null;
            
            oos.writeObject(clavepubl);
            claveCliente = (PublicKey) ois.readObject();
            
            
            
            while(true){
                
                //Recibimos el mensaje cifrado del cliente
                byte [] cifrado = (byte[]) ois.readObject();
                //Desciframos el texto con la clave desenvuelta.
                Cipher c2 = Cipher.getInstance("RSA/ECB/PKCS1Padding");
                c2.init(Cipher.DECRYPT_MODE, clavepriv);
                byte []TextoDescifrado = c2.doFinal(cifrado);
                System.out.println("Mensjae recibido por el cliente: " + new String(TextoDescifrado));
                
                
                
                
                
                
                //Ciframos el texto con la clave secreta.
                Cipher c = Cipher.getInstance("RSA/ECB/PKCS1Padding");
                c.init(Cipher.ENCRYPT_MODE, claveCliente);
                System.out.print("Introduce un mensaje: ");
                String mensaje = br.readLine();
                byte[] TextoPlano = mensaje.getBytes();
                byte[] TextoCifrado = c.doFinal(TextoPlano);
               // System.out.println("Encriptado: " + new String(TextoCifrado));
                oos.writeObject(TextoCifrado);//Mandamos el mensaje cifrado
            }
        } catch (IOException ex) {
            Logger.getLogger(EncDescServidorBea.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(EncDescServidorBea.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(EncDescServidorBea.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchPaddingException ex) {
            Logger.getLogger(EncDescServidorBea.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InvalidKeyException ex) {
            Logger.getLogger(EncDescServidorBea.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalBlockSizeException ex) {
            Logger.getLogger(EncDescServidorBea.class.getName()).log(Level.SEVERE, null, ex);
        } catch (BadPaddingException ex) {
            Logger.getLogger(EncDescServidorBea.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
