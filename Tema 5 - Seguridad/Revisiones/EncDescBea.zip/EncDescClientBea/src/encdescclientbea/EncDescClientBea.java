/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package encdescclientbea;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

/**
 *
 * @author beani
 */
public class EncDescClientBea {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        
            
            // TODO code application logic here
            InetAddress dir;
            Socket servidor = null;
           
            try{
                dir = InetAddress.getLocalHost();
                servidor = new Socket(dir, 1050);             
                
                
                ObjectInputStream ois = new ObjectInputStream(servidor.getInputStream());
                ObjectOutputStream oos = new ObjectOutputStream(servidor.getOutputStream());
                BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
                
                
                //Se crean el par de claves públicas y privada.
                KeyPairGenerator KeyGen = KeyPairGenerator.getInstance("RSA");
                KeyGen.initialize(1024);
                KeyPair par = KeyGen.generateKeyPair();
                PrivateKey clavepriv = par.getPrivate();
                PublicKey clavepubl = par.getPublic();
                
                PublicKey publicServer = null;
                
                publicServer = (PublicKey) ois.readObject();
                oos.writeObject(clavepubl);
                
                
                
                while(true){
                    //Ciframos el texto con la clave secreta.
                    Cipher c = Cipher.getInstance("RSA/ECB/PKCS1Padding");
                    c.init(Cipher.ENCRYPT_MODE, publicServer);
                    System.out.print("Introduce un mensaje: ");
                    String mensaje = br.readLine();
                    byte[] TextoPlano = mensaje.getBytes();
                    byte[] TextoCifrado = c.doFinal(TextoPlano);
                    //System.out.println("Encriptado: " + new String(TextoCifrado));
                    oos.writeObject(TextoCifrado);//Mandamos el mensaje cifrado
                    
                    
                    
                    
                    
                    //Recibimos el mensaje cifrado del cliente
                    byte [] cifrado = (byte[]) ois.readObject();
                    //Desciframos el texto con la clave desenvuelta.
                    Cipher c2 = Cipher.getInstance("RSA/ECB/PKCS1Padding");
                    c2.init(Cipher.DECRYPT_MODE, clavepriv);
                    byte []TextoDescifrado = c2.doFinal(cifrado);
                    System.out.println("Mensjae recibido por el servidor: " + new String(TextoDescifrado));
                }
                
                
            } catch (UnknownHostException ex) {
                Logger.getLogger(EncDescClientBea.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(EncDescClientBea.class.getName()).log(Level.SEVERE, null, ex);
            } catch (NoSuchAlgorithmException ex) {
                Logger.getLogger(EncDescClientBea.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(EncDescClientBea.class.getName()).log(Level.SEVERE, null, ex);
            } catch (NoSuchPaddingException ex) {
                Logger.getLogger(EncDescClientBea.class.getName()).log(Level.SEVERE, null, ex);
            } catch (InvalidKeyException ex) {
                Logger.getLogger(EncDescClientBea.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IllegalBlockSizeException ex) {
                Logger.getLogger(EncDescClientBea.class.getName()).log(Level.SEVERE, null, ex);
            } catch (BadPaddingException ex) {
                Logger.getLogger(EncDescClientBea.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            servidor.close();
        
    }
    
}
