/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mensaje;

import java.io.Serializable;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.SignatureException;

/**
 *
 * @author jorge
 */
public class Mensaje implements Serializable{

    private String msg;    
    private byte[] firma;

    public Mensaje(String mensaje) {
        this.msg = mensaje;
    }

    public void firmar(PrivateKey clavePrivada) throws Exception {
        byte[] firma = null;        
        Signature dsa = Signature.getInstance("SHA1withDSA");
        dsa.initSign(clavePrivada);
        dsa.update(msg.getBytes());
        this.firma = dsa.sign(); //Mensaje firmado.
    }

    public boolean verifica(PublicKey clavePublica) throws Exception {
        Signature verifica_dsa = Signature.getInstance("SHA1withDSA");
        verifica_dsa.initVerify(clavePublica);

        //msg = "Otra cosa";
        verifica_dsa.update(msg.getBytes());
        return verifica_dsa.verify(firma);
    }

}
