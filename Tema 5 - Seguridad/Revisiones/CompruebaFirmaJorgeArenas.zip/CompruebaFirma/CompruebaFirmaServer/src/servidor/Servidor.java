/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor;

import java.io.IOException;
import java.net.*;

/**
 *
 * @author jorge
 */
public class Servidor {
    public static void main(String[] args) throws IOException {
        ServerSocket servidor=new ServerSocket(9000);
        Socket cliente;
        System.out.println("Servidor iniciado...");
        while(true){
            cliente=servidor.accept();
            Hilo h=new Hilo(cliente);
            h.start();
        }
    }
}
