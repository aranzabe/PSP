/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor;

import mensaje.Mensaje;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author jorge
 */
public class Hilo extends Thread {

    private Socket cliente;

    public Hilo(Socket cliente) {
        this.cliente = cliente;
    }

    @Override
    public void run() {
        try {
            DataOutputStream dos = new DataOutputStream(cliente.getOutputStream());
            DataInputStream dis = new DataInputStream(cliente.getInputStream());
            ObjectInputStream ois = new ObjectInputStream(cliente.getInputStream());
            PublicKey clavePublica = (PublicKey) ois.readObject();
            while (dis.readBoolean()) {
                Mensaje msg = (Mensaje) ois.readObject();
                if (msg.verifica(clavePublica)) {
                    dos.writeUTF("OK");
                } else {
                    dos.writeUTF("CUIDADO! TEXTO ALTERADO...");
                }
            }
            System.out.println("Conexion cerrada");
        } catch (Exception ex) {
            Logger.getLogger(Hilo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
