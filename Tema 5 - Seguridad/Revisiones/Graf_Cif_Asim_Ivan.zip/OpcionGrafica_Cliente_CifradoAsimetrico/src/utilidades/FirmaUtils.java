/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utilidades;

import objetos.Firma;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.SignatureException;

/**
 *
 * @author ivanc
 */
public class FirmaUtils {
    
    public static Firma firmar (String msg) throws NoSuchAlgorithmException, InvalidKeyException, SignatureException{
        Firma f = null;
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("DSA");
        SecureRandom numero = SecureRandom.getInstance("SHA1PRNG");
        keyGen.initialize(1024, numero);
        KeyPair par = keyGen.generateKeyPair();
        PrivateKey cpriv = par.getPrivate();
        PublicKey cpub = par.getPublic();
        Signature dsa = Signature.getInstance("SHA1withDSA");
        dsa.initSign(cpriv);
        dsa.update(msg.getBytes());
        byte[] firma = dsa.sign();
        f = new Firma(msg, firma, cpub);
        return f;
        
    }
    
}
