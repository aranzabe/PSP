/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objetos;

import java.io.Serializable;
import java.security.PublicKey;

/**
 *
 * @author ivanc
 */
public class Firma implements Serializable {

    private String mensaje;
    private byte[] firma;
    private PublicKey clavePublica;

    public Firma(String mensaje, byte[] firma, PublicKey clavePublica) {
        this.mensaje = mensaje;
        this.firma = firma;
        this.clavePublica = clavePublica;
    }

    public String getMensaje() {
        return mensaje;
    }

    public byte[] getFirma() {
        return firma;
    }

    public PublicKey getClavePublica() {
        return clavePublica;
    }

}
