/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utilidades;

import objetos.Firma;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;

/**
 *
 * @author ivanc
 */
public class UtilFirma {
    
    public static Firma validarFirma(String msg, byte[] firma, PublicKey cpub, Socket cliente) throws IOException {
        Firma f = null;

        try {
            Signature s = Signature.getInstance("SHA1withDSA");
            s.initVerify(cpub);
            DataOutputStream dos = new DataOutputStream(cliente.getOutputStream());
            //mensaje = "adios";
            s.update(msg.getBytes());
            boolean check = s.verify(firma);
            if (check) dos.writeUTF("OK");
            else       dos.writeUTF("KO");

        } catch (NoSuchAlgorithmException | InvalidKeyException | SignatureException ex) {}
        return f;
    }
    
}
