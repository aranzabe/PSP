/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejecutable;

import objetos.Firma;
import java.io.DataOutputStream;
import java.io.ObjectInputStream;
import java.net.Socket;
import utilidades.UtilFirma;

/**
 *
 * @author ivanc
 */
public class HiloServidor extends Thread {
    
    Socket cliente;

    HiloServidor(Socket cliente) {
        this.cliente = cliente;
    }

    @Override
    public void run() {
        try {
            Firma f;
               
            DataOutputStream dos = new DataOutputStream(cliente.getOutputStream());
            
            while (true) {
                ObjectInputStream ois = new ObjectInputStream(cliente.getInputStream());
                f = (Firma) ois.readObject();

                UtilFirma.validarFirma(f.getMensaje(), f.getFirma(), f.getClavePublica(), cliente);

            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
}
