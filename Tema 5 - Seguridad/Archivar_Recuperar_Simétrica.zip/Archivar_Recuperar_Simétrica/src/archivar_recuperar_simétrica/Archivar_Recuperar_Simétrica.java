/*
 * En el siguiente ejemplo veremos como generar una clave secreta AES y almacenarla en un fichero.
 */
package archivar_recuperar_simétrica;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;


/**
 *
 * @author faranzabe
 */
public class Archivar_Recuperar_Simétrica {

    
    static void Archivar_Privada(String nombre_fichero, SecretKey clave) throws NoSuchAlgorithmException, IOException{
        ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(nombre_fichero));
        out.writeObject(clave);
        out.close();
    }
    
    
    
    static Key Recuperar_Privada(String nombre_fichero) throws IOException, ClassNotFoundException{
        ObjectInputStream in = new ObjectInputStream(new FileInputStream(nombre_fichero));
        Key secreta = (Key) in.readObject();
        return secreta;
    }
    
    
    /**
     * ******************************************************************************
     * ********************** Programa principal ************************************
     * ******************************************************************************
     */
    public static void main(String[] args) {
        try {
            KeyGenerator kg = KeyGenerator.getInstance("AES");
            kg.init(128);
            SecretKey clave = kg.generateKey();
            
            System.out.println("Clave privada almacenada: " + clave.toString());
            
            Archivar_Privada("Clave.pri", clave);
            SecretKey Key2 = (SecretKey) Recuperar_Privada("Clave.pri");
            
            System.out.println("Clave recuperada: " + Key2.toString());
            
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(Archivar_Recuperar_Simétrica.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Archivar_Recuperar_Simétrica.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Archivar_Recuperar_Simétrica.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}
