/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientecifrarobjeto;

import clases.Persona;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import javax.crypto.Cipher;
import javax.crypto.CipherOutputStream;
import javax.crypto.KeyGenerator;
import javax.crypto.SealedObject;
import javax.crypto.SecretKey;

/**
 *
 * @author faranzabe
 */
public class ClienteCifrarObjeto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Persona p = new Persona("Alberto", 19);
        try {
            //Nos conectamos al servidor
            Socket cliente = new Socket("localhost", 5000);
            
            //Abrimos el flujo de entrada de datos y recibimos la clave pública del servidor
            ObjectInputStream flujoE = new ObjectInputStream(cliente.getInputStream());
            PublicKey publicaServer = (PublicKey) flujoE.readObject();
            
            //Instanciamos el Cipher y lo inicializamos en el modo encriptación con la clave pública del servidor
            Cipher c = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            c.init(Cipher.ENCRYPT_MODE, publicaServer);
            //Creamos un objeto encapsulado con el cipher creado anteriormente y el objeto que queremos encapsualr (tiene que implementar serializable)
            SealedObject sealedObject = new SealedObject(p, c);
            
            System.out.println("Objeto encapsulado");
            
            ObjectOutputStream flujoS = new ObjectOutputStream(cliente.getOutputStream());
            flujoS.writeObject(sealedObject);
            
            System.out.println("Objeto enviado al servidor");
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

}
