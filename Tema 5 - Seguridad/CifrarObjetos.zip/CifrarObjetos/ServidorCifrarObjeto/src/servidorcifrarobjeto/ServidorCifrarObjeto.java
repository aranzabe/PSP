/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidorcifrarobjeto;

import clases.Persona;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.Key;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import javax.crypto.Cipher;
import javax.crypto.SealedObject;

/**
 *
 * @author faranzabe
 */
public class ServidorCifrarObjeto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            ServerSocket servidor = new ServerSocket(5000);
            //Generamos el par de clave pública y privada
            KeyPairGenerator KeyGen = KeyPairGenerator.getInstance("RSA");
            KeyGen.initialize(1024);
            KeyPair par = KeyGen.generateKeyPair();
            PrivateKey clavepriv = par.getPrivate();
            PublicKey clavepubl = par.getPublic();
            //Recibimos un cliente
            Socket cliente = servidor.accept();
            //Le enviamos la clave pública para que cifre
            ObjectOutputStream flujoS = new ObjectOutputStream(cliente.getOutputStream());
            flujoS.writeObject(clavepubl);
            //Recibimos el objeto encapsulado
            ObjectInputStream flujoE = new ObjectInputStream(cliente.getInputStream());

            SealedObject c = (SealedObject) flujoE.readObject();
            
            //Instanciamos el cipher y lo inicializamos
            Cipher c2 = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            c2.init(Cipher.DECRYPT_MODE, clavepriv);
            //Recogemos el objeto persona del objeto encapsulado
            Persona p = (Persona)c.getObject(c2);
            //Mostramos sus datos para verificar que son los correctos
            System.out.println("Nombre: "+p.getNombre()+", edad: "+p.getEdad());

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
}
