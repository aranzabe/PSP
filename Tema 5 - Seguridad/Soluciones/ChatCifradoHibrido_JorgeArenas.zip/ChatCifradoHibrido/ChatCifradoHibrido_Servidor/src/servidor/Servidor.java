/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Scanner;
import javax.crypto.KeyGenerator;
import javax.crypto.SealedObject;
import javax.crypto.SecretKey;
import mensaje.Mensaje;
import seguridad.Seguridad;

/**
 *
 * @author jorge
 */
public class Servidor {

    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) throws Exception {
        //Establecemos la conexion
        ServerSocket servidor = new ServerSocket(9000);
        Socket cliente;
        System.out.println("Esperando conexion");
        cliente = servidor.accept();
        System.out.println("Cliente conectado");
        ObjectOutputStream oos = new ObjectOutputStream(cliente.getOutputStream());
        ObjectInputStream ois = new ObjectInputStream(cliente.getInputStream());

        //Generamos ambas claves
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        keyGen.initialize(2048);
        KeyPair par = keyGen.generateKeyPair();
        PrivateKey clavepriv = par.getPrivate();
        PublicKey clavepubl = par.getPublic();
        
        //Recibimos la clave del otro extremo
        PublicKey clientKey = (PublicKey) ois.readObject();
        //Mandamos la clave publica al otro extremo
        oos.writeObject(clavepubl);
        
        //Generamos la clave simétrica.
        KeyGenerator kg = KeyGenerator.getInstance("AES");
        kg.init(128);
        SecretKey claveSimetrica = kg.generateKey();
        //la enviamos cifrada al cliente
        oos.writeObject(Seguridad.cifrarObjeto(claveSimetrica, clientKey));
        
        try {
            String cad = "";
            while (!cad.equals("fin")) {
                Mensaje msg=(Mensaje) Seguridad.desencriptarObjetoSimetric((SealedObject)ois.readObject(),claveSimetrica);                
                cad=msg.getMsg();
                byte[]firma=msg.getFirma();                                
                System.out.println("Mensaje recibido: " + cad);                                
                System.out.print("Escribe:");
                cad = sc.nextLine();
                msg=new Mensaje(cad);
                msg.firmar(clavepriv);                
                oos.writeObject(Seguridad.cifrarObjetoSimetric(msg, claveSimetrica));                
            }
        } catch (SocketException se) {
            System.out.println("El cliente se ha desconectado");
        } finally {
            cliente.close();
        }
    }

}
