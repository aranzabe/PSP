/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mensaje;

import java.io.Serializable;
import java.security.PrivateKey;
import seguridad.Seguridad;

/**
 *
 * @author jorge
 */
public class Mensaje implements Serializable{

    private String msg;
    private byte[] firma;

    public Mensaje(String msg) {
        this.msg = msg;
        this.firma = firma;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public byte[] getFirma() {
        return firma;
    }

    public void firmar(PrivateKey prk) throws Exception {
        this.firma = Seguridad.firmar(msg, prk);
    }

}
