/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Scanner;
import javax.crypto.SealedObject;
import javax.crypto.SecretKey;
import mensaje.Mensaje;
import seguridad.Seguridad;

/**
 *
 * @author jorge
 */
public class Cliente {

    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) throws Exception {
        //Establecemos la conexion
        InetAddress dir = InetAddress.getLocalHost();
        Socket servidor = new Socket(dir, 9000);
        ObjectOutputStream oos = new ObjectOutputStream(servidor.getOutputStream());
        ObjectInputStream ois = new ObjectInputStream(servidor.getInputStream());

        //Generamos ambas claves        
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        keyGen.initialize(2048);
        KeyPair par = keyGen.generateKeyPair();
        PrivateKey clavepriv = par.getPrivate();
        PublicKey clavepubl = par.getPublic();

        //Mandamos la clave publica al otro extremo
        oos.writeObject(clavepubl);
        //Recibimos la clave del otro extremo
        PublicKey serverKey = (PublicKey) ois.readObject();
        
        //Obtenemos la clave simetrica del servidor.
        SecretKey claveSimetrica=(SecretKey) Seguridad.desencriptarObjeto((SealedObject) ois.readObject(), clavepriv);
        System.out.println("Puedes mandar tu primer mensaje:");
        String cad = "";
        while (!cad.equals("fin")) {
            System.out.print("Escribe: ");
            cad = sc.nextLine();
            Mensaje msg=new Mensaje(cad);
            msg.firmar(clavepriv);
            oos.writeObject(Seguridad.cifrarObjetoSimetric(msg,claveSimetrica));            
            msg=(Mensaje) Seguridad.desencriptarObjetoSimetric((SealedObject)ois.readObject(),claveSimetrica);            
            cad=msg.getMsg();
            byte[]firma=msg.getFirma();              
            System.out.println("Mensaje recibido: " + cad);           
        }
        servidor.close();
    }

}
