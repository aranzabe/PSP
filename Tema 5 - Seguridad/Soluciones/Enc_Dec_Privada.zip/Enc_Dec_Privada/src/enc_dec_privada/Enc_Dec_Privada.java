/*
 * Encriptar y desencriptar con clave privada.
 */
package enc_dec_privada;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;

/**
 *
 * @author faranzabe
 */
public class Enc_Dec_Privada {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException {
        //En primer lugar creamos la clave secreta usando el algoritmo AES (también
        //podríamos haber usado DES) y definimos un tamaño de clave de 128 bits.
        KeyGenerator kg = KeyGenerator.getInstance("AES");
        kg.init(128);
        SecretKey clave = kg.generateKey();
        System.out.println("Clave utilizada: " + clave.getEncoded());
        
        //A continuación generamos un objeto Cipher con el algoritmo AES/ECB/PKCS5Padding
        //Los algoritmos que podemos elegir son:
        //    AES/CBC/NoPadding (128)
        //    AES/CBC/PKCS5Padding (128)
        //    AES/ECB/NoPadding (128)
        //    AES/ECB/PKCS5Padding (128)
        //    DES/CBC/NoPadding (56)
        //    DES/CBC/PKCS5Padding (56)
        //    DES/ECB/NoPadding (56)
        //    DES/ECB/PKCS5Padding (56)
        //    DESede/CBC/NoPadding (168)
        //    DESede/CBC/PKCS5Padding (168)
        //    DESede/ECB/NoPadding (168)
        //    DESede/ECB/PKCS5Padding (168)
        //    RSA/ECB/PKCS1Padding (1024, 2048)
        //    RSA/ECB/OAEPWithSHA-1AndMGF1Padding (1024, 2048)
        //    RSA/ECB/OAEPWithSHA-256AndMGF1Padding (1024, 2048)
        //    Más información: https://en.wikipedia.org/wiki/Block_cipher_mode_of_operation
        
        Cipher c = Cipher.getInstance("AES/ECB/PKCS5Padding");
        c.init(Cipher.ENCRYPT_MODE, clave);
        
        //Realizamos el cifrado de la información con el método doFinal().
        //Cifraremos el siguiente texto plano:
        byte []TextoPlano = "Esto es texto plano".getBytes();
        byte []TextoCifrado = c.doFinal(TextoPlano);
        System.out.println("Encriptado: " + new String(TextoCifrado));
        
        //Configuramos el objeto Cipher con la clave anterior para desencriptar.
        c.init(Cipher.DECRYPT_MODE, clave);
        byte []Desencriptado = c.doFinal(TextoCifrado);
        System.out.println("Desencriptado: " + new String(Desencriptado));
        
        
        /*
        Muchos modos de algoritmos (por ejemplo CBC) requieren un vector de 
        inicialización que se especifica cuando se inicia el objeto.
        Ejemplo de inicialización de un objeto Cipher creado con el algoritmo
        DES/CBC/PKCS5Padding:
        */
//        KeyGenerator kg2 = KeyGenerator.getInstance("DES");
//        Cipher c2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
//        Key clave2 = kg2.generateKey();
//        //Devuelve el vector IV inicializado en un nuevo buffer.
//        byte iv[] = c.getIV();
//        IvParameterSpec dps = new IvParameterSpec(iv);
//        c.init(Cipher.DECRYPT_MODE, clave2, dps);

    }
    
}
