/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seguridad;

import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;

/**
 *
 * @author jorge
 */
public class Seguridad {
    
    public static byte[] firmar(String msg, PrivateKey clavePrivada) throws Exception {        
        Signature dsa = Signature.getInstance("SHA1withDSA");
        dsa.initSign(clavePrivada);
        dsa.update(msg.getBytes());
        return dsa.sign(); //Mensaje firmado.
    }

    public static boolean verifica(String msg, PublicKey clavePublica, byte[] firma) throws Exception {
        Signature verifica_dsa = Signature.getInstance("SHA1withDSA");
        verifica_dsa.initVerify(clavePublica);

        //msg = "Otra cosa";
        verifica_dsa.update(msg.getBytes());
        return verifica_dsa.verify(firma);
    }

    public static byte[] cifrarSimetrico(String msg,SecretKey clave) throws Exception {
        Cipher c = Cipher.getInstance("AES/ECB/PKCS5Padding");
        c.init(Cipher.ENCRYPT_MODE, clave);

        byte[] TextoPlano = msg.getBytes();
        byte[] cifrado = c.doFinal(TextoPlano);
        return cifrado;
    }
    public static String desencriptarSimetrico(byte[] cifrado,SecretKey clave) throws Exception {
        Cipher c = Cipher.getInstance("AES/ECB/PKCS5Padding");
        c.init(Cipher.DECRYPT_MODE, clave);
        byte[] desencriptado=c.doFinal(cifrado);
        return new String(desencriptado);
    }
    
    public static byte[] cifrarAsimetrico(String msg, PublicKey clave) throws Exception{
        Cipher c = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        c.init(Cipher.ENCRYPT_MODE, clave);
        byte[] TextoPlano = msg.getBytes();
        byte[] cifrado = c.doFinal(TextoPlano);
        return cifrado;
    }
    
    public static String desencriptarAsimetrico(byte[] cifrado,PrivateKey clave) throws Exception {
        Cipher c = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        c.init(Cipher.DECRYPT_MODE, clave);
        byte[] desencriptado=c.doFinal(cifrado);
        return new String(desencriptado);
    }
}
