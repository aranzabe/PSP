/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Scanner;
import seguridad.Seguridad;

/**
 *
 * @author jorge
 */
public class Cliente {

    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) throws Exception {
        //Establecemos la conexion
        InetAddress dir = InetAddress.getLocalHost();
        Socket servidor = new Socket(dir, 9000);
        ObjectOutputStream oos = new ObjectOutputStream(servidor.getOutputStream());
        ObjectInputStream ois = new ObjectInputStream(servidor.getInputStream());

        //Generamos ambas claves        
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        keyGen.initialize(1024);
        KeyPair par = keyGen.generateKeyPair();
        PrivateKey clavepriv = par.getPrivate();
        PublicKey clavepubl = par.getPublic();

        //Mandamos la clave publica al otro extremo
        oos.writeObject(clavepubl);
        //Recibimos la clave del otro extremo
        PublicKey claveCifrar = (PublicKey) ois.readObject();

        System.out.println("Puedes mandar tu primer mensaje:");
        String msg = "";
        while (!msg.equals("fin")) {
            System.out.print("Escribe: ");
            msg = sc.nextLine();            
            oos.writeObject(Seguridad.cifrarAsimetrico(msg, claveCifrar));
            msg=Seguridad.desencriptarAsimetrico((byte[]) ois.readObject(), clavepriv);
            System.out.println("Mensaje recibido: "+msg);
        }
        servidor.close();
    }

}
