/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Scanner;
import seguridad.Seguridad;

/**
 *
 * @author jorge
 */
public class Servidor {

    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) throws Exception {
        //Establecemos la conexion
        ServerSocket servidor = new ServerSocket(9000);
        Socket cliente;
        System.out.println("Esperando conexion");
        cliente = servidor.accept();
        System.out.println("Cliente conectado");
        ObjectOutputStream oos = new ObjectOutputStream(cliente.getOutputStream());
        ObjectInputStream ois = new ObjectInputStream(cliente.getInputStream());

        //Generamos ambas claves
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        keyGen.initialize(1024);
        KeyPair par = keyGen.generateKeyPair();
        PrivateKey clavepriv = par.getPrivate();
        PublicKey clavepubl = par.getPublic();

        //Recibimos la clave del otro extremo
        PublicKey claveCifrar = (PublicKey) ois.readObject();
        //Mandamos la clave publica al otro extremo
        oos.writeObject(clavepubl);
        try {
            String msg = "";
            while (!msg.equals("fin")) {
                msg = Seguridad.desencriptarAsimetrico((byte[]) ois.readObject(), clavepriv);
                System.out.println("Mensaje recibido: " + msg);
                System.out.print("Escribe:");
                msg = sc.nextLine();
                oos.writeObject(Seguridad.cifrarAsimetrico(msg, claveCifrar));
            }
        } catch (SocketException se) {
            System.out.println("El cliente se ha desconectado");
        } finally {
            cliente.close();
        }
    }

}
