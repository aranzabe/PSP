/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package msg_digest_1;

import java.security.*;
/**
 * Una función de resumen de mensaje es una marca digital de un bloque de datos.
 * Existen un gran número de algoritmos diseñados para procesar estos messages
 * digest, los dos más populares son SHA1-SHA2 y MD5.
 * @author faranzabe
 */
public class MSG_DIGEST_1 {

    static String Hexadecimal(byte []resumen){
        String hex="";
        for (int i=0;i<resumen.length;i++){
            String h = Integer.toHexString(resumen[i] & 0xFF);
            if (h.length() == 1) hex+=0;
            hex+=h;
        }
        return hex;
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws NoSuchAlgorithmException {
        // TODO code application logic here
        //MessageDigest md = MessageDigest.getInstance("SHA");
        MessageDigest md = MessageDigest.getInstance("SHA1");
        //MessageDigest md = MessageDigest.getInstance("MD5");
        String texto = "1234";
        byte datos[] = texto.getBytes(); //Texto en bytes
        md.update(datos);                //Se introduce el texto en bytes a resumir
        byte resumen1[] = md.digest();    //Se calcula el resumen
        
        System.out.println("Mensaje original: " + texto);
        System.out.println("Número de bytes del resumen: " + md.getDigestLength());
        System.out.println("Algoritmo: " + md.getAlgorithm());
        System.out.println("Mesaje resumen: " + new String(resumen1));
        System.out.println("Mensaje en hexadecimal: " + Hexadecimal(resumen1));
        
        String texto2 = "1234";
        datos = texto2.getBytes(); //Texto en bytes
        md.update(datos);                //Se introduce el texto en bytes a resumir
        byte resumen2[] = md.digest();    //Se calcula el resumen
        
        System.out.println("Mensaje original: " + texto2);
        System.out.println("Número de bytes del resumen: " + md.getDigestLength());
        System.out.println("Algoritmo: " + md.getAlgorithm());
        System.out.println("Mesaje resumen: " + new String(resumen2));
        System.out.println("Mensaje en hexadecimal: " + Hexadecimal(resumen2));
        
        
        Provider proveedor = md.getProvider();
        System.out.println("Proveedor: " + proveedor.toString());
        
        boolean iguales = (MessageDigest.isEqual(resumen1, resumen2));
        if (iguales){
            System.out.println("Cadenas originales iguales");
        }
        else {
            System.out.println("Cadenas originales distintas.");
        }
    }
    
}
