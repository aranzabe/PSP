/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clienteudp_examenfebrero_jaime_juarez_notario;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author examen
 */
public class Hilo_confirmacion extends Thread{
    private boolean ack;
    private int puerto;
    

    Hilo_confirmacion(int puerto,boolean ack) {
        this.puerto=puerto;
        this.ack=ack;
    }
    
    @Override
    public void run(){
        try {
        byte[] buffer=null;
        int longitud;
        InetAddress dir;
        String mensaje;
        
        DatagramSocket s;
        
        s = new DatagramSocket(puerto);
        

        while(!ack){
            DatagramPacket p=null;
            s.receive(p);
        
            buffer=p.getData(); 
            longitud=p.getLength(); 
            
            //se contruye el mensaje
            mensaje=new String(buffer,0,longitud); 
            
            if(mensaje.equalsIgnoreCase("#OK")){
                ack=true;
            }
            
        }
        } catch (SocketException ex) {
            Logger.getLogger(Hilo_confirmacion.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Hilo_confirmacion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
