/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clienteudp_examenfebrero_jaime_juarez_notario;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

/**
 *
 * @author examen
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
       byte[] buffer=null;
        int puerto=9999;
        InetAddress dir;
        String mensaje;
        boolean ack=false;
        
        DatagramSocket s=new DatagramSocket();

        DatagramPacket p=null;
        
        //elijo el 9999 como el puerto que esperará la respuesta del servidor 
        //y paso por referencia un booleano que cambiará a true cuando reciba respuesta
        Hilo_confirmacion hilo=new Hilo_confirmacion(puerto,ack);
        hilo.start();
        
        
        mensaje="#BORRAR#"+puerto;
        buffer= mensaje.getBytes();
                
        p=new DatagramPacket(buffer, mensaje.length(), InetAddress.getLocalHost(), 6300);
                  
        while(!ack){      
            s.send(p);
        }    
              
        }
    
}
