/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Modelos;

import java.sql.Timestamp;
/**
 *
 * @author examen
 */
public class Registro {
    private int personasSuben;
    private int personasBajan;
    private String estacion;
    private int linea;
    private Timestamp fecha;

    public Registro(int personasSuben, int personasBajan, String estacion, int linea, Timestamp fecha) {
        this.personasSuben = personasSuben;
        this.personasBajan = personasBajan;
        this.estacion = estacion;
        this.linea = linea;
        this.fecha = fecha;
    }

    public int getPersonasSuben() {
        return personasSuben;
    }

    public void setPersonasSuben(int personasSuben) {
        this.personasSuben = personasSuben;
    }

    public int getPersonasBajan() {
        return personasBajan;
    }

    public void setPersonasBajan(int personasBajan) {
        this.personasBajan = personasBajan;
    }

    public String getEstacion() {
        return estacion;
    }

    public void setEstacion(String estacion) {
        this.estacion = estacion;
    }

    public int getLinea() {
        return linea;
    }

    public void setLinea(int linea) {
        this.linea = linea;
    }

    public Timestamp getFecha() {
        return fecha;
    }

    public void setFecha(Timestamp fecha) {
        this.fecha = fecha;
    }
    
    
}
