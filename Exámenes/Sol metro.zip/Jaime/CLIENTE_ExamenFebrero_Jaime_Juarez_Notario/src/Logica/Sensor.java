/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

/**
 *
 * @author examen
 */
public class Sensor {
    private int personasBajan;
    private int personasSuben;

    public Sensor() {
        personasBajan=0;
        personasSuben=0;
    }
    
    public void capturarPersonas(){
        personasBajan=((int)Math.random()%100)+100;
        personasSuben=((int)Math.random()%100)+100;
    }

    public int getPersonasBajan() {
        return personasBajan;
    }

    public void setPersonasBajan(int personasBajan) {
        this.personasBajan = personasBajan;
    }

    public int getPersonasSuben() {
        return personasSuben;
    }

    public void setPersonasSuben(int personasSuben) {
        this.personasSuben = personasSuben;
    }
    
    
    
}
