/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author examen
 */
public class Estacion {

    private String nombre;
    private Semaphore cruce;

    public Estacion(String nombre) {
        this.nombre = nombre;
        cruce = null;
    }

    public Estacion(String nombre, Semaphore cruce) {
        this.nombre = nombre;
        this.cruce = cruce;
    }

    public synchronized boolean esAccesible() {
        boolean flag = true;

        try {
            //        if(cruce!=null){
//            if(cruce.tryAcquire()){
//                flag=true;
//            }
//        }
//        else{
//            flag=true;
//        }
            if (cruce != null) {
                this.cruce.acquire();
            }
        } catch (InterruptedException ex) {
            Logger.getLogger(Estacion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }

    public synchronized void dejarEstancion() {
        if (cruce != null) {
            cruce.release();
        }
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Semaphore getCruce() {
        return cruce;
    }

    public void setCruce(Semaphore cruce) {
        this.cruce = cruce;
    }

    public void salirEstacion() {
        if (cruce != null) {
            this.cruce.release();
        }
    }

}
