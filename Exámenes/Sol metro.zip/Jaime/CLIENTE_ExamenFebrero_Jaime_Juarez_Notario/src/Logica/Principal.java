/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

import java.util.LinkedList;
import java.util.concurrent.Semaphore;

/**
 *
 * @author examen
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        LinkedList<Estacion> ruta1=new LinkedList<Estacion>();
        LinkedList<Estacion> ruta2=new LinkedList<Estacion>();
        LinkedList<Estacion> ruta3=new LinkedList<Estacion>();
        
        //cruces
        Semaphore cruce1=new Semaphore(1);
        Semaphore cruce2=new Semaphore(1);
        Semaphore cruce3=new Semaphore(1);
        
        //estaciones
        Estacion arrakis=new Estacion("Arrakis");
        Estacion harkonnen=new Estacion("Harkonnen");
        Estacion dune=new Estacion("Dune",cruce1);
        Estacion skywalker=new Estacion("Skywalker",cruce3); 
        Estacion atreides=new Estacion("Atreides");
        Estacion muadib=new Estacion("Muadib");
       
        Estacion yoda=new Estacion("Yoda");
        Estacion padawan=new Estacion("Padawan");
        Estacion kirk=new Estacion("Kirk",cruce2);
        Estacion vader=new Estacion("Vader");
        Estacion obiwan=new Estacion("Obiwan");
        
        Estacion spock=new Estacion("Spock");
        Estacion enterprise=new Estacion("Enterprise");
        Estacion uhura=new Estacion("Uhura");
        Estacion vulcano=new Estacion("Vulcano");
        
        //rutas
        ruta1.add(arrakis);
        ruta1.add(harkonnen);
        ruta1.add(dune);
        ruta1.add(skywalker);
        ruta1.add(atreides);
        ruta1.add(muadib);
        
        ruta2.add(yoda);
        ruta2.add(padawan);
        ruta2.add(kirk);
        ruta2.add(skywalker);
        ruta2.add(vader);
        ruta2.add(obiwan);
        
        ruta3.add(spock);
        ruta3.add(enterprise);
        ruta3.add(dune);
        ruta3.add(kirk);
        ruta3.add(uhura);
        ruta3.add(vulcano);
        
        //lineas
        Tren linea1=new Tren(1,ruta1);
        Tren linea2=new Tren(2,ruta2);
        Tren linea3=new Tren(3,ruta3);
        
        //que comiencen los viajes
        linea1.start();
        linea2.start();
        linea3.start();
    }
}
