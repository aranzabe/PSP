/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

import java.sql.Timestamp;
import java.util.Date;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author examen
 */
public class Tren extends Thread{
    private int id;
    private Sensor sensor;
    private LinkedList<Estacion> ruta;
    private int posicionDeruta;
    public boolean IdaOvuelta; //true para ida, false para vuelta
    

    public Tren(int id, LinkedList<Estacion> ruta) {
        this.id = id;
        sensor=new Sensor();
        this.ruta = ruta;
        this.IdaOvuelta=true;
    }
    
    @Override
    public void run(){
        try {
            System.out.println("¡¡¡¡¡Empieza el viaje del tren/linea "+id+"!!!!!");
            this.posicionDeruta=0;


            while(true){
                //estamos en la estación
                System.out.println("Nos encontramos en la estación " +ruta.get(this.posicionDeruta)+"vayan cogiendo asiento el viaje empezará en breves...");
               
                //se pone en funcionamiento el sensor
                sensor.capturarPersonas();
                
                //Esperamos entre 1 y 3 segundos....
                Thread.sleep(((int)Math.random()/3)+1);
                
                //Dejamos la estación
                System.out.println("Empieza el viaje, abrochense los cinturones de seguridad...");
                ruta.get(this.posicionDeruta).dejarEstancion();
                
                //mandamos los datos obtenidos por el sensor al servidor...
                new Hilo_comunicadorTCP(sensor.getPersonasBajan(),sensor.getPersonasSuben(),id,ruta.get(this.posicionDeruta).getNombre(),new Timestamp((new Date()).getTime())).start();

                //va a empezar el viaje, movemos posicion a siguiente estancion...
                if(this.IdaOvuelta){
                    posicionDeruta++;
                }else{
                    posicionDeruta--;
                }
                
                //informamos de proxima estación
                System.out.println("Estamos camino de la próxima estación: "+ruta.get(posicionDeruta)+" tengan paciencia...");
                
                //intentamos acceder a la siguiente estación
                while(!ruta.get(this.posicionDeruta).esAccesible()){
                    Thread.sleep(1000);
                    System.out.println("Estamos esperando a que la proxima estación sea accesible, mantengan la calma...");
                }
                this.ruta.get(this.posicionDeruta).salirEstacion();
                
                //si es el final de la ruta, empieza la vuelta
                if(posicionDeruta==ruta.size()){
                    IdaOvuelta= (!IdaOvuelta);
                }


            }
        } catch (InterruptedException ex) {
                Logger.getLogger(Tren.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    

    public int getIdTren() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Sensor getSensor() {
        return sensor;
    }

    public void setSensor(Sensor sensor) {
        this.sensor = sensor;
    }

    public LinkedList<Estacion> getRuta() {
        return ruta;
    }

    public void setRuta(LinkedList<Estacion> ruta) {
        this.ruta = ruta;
    }
    
    
    
    
    
    
    
    
    
}
