/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

import Modelos.Registro;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.sql.Timestamp;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author examen
 */
public class Hilo_comunicadorTCP extends Thread{
    private Registro r;

    public Hilo_comunicadorTCP(int personasBajan, int personasSuben, int id, String nombre, Timestamp fecha) {
        r=new Registro(personasSuben,personasBajan,nombre,id,fecha);
    }
    
    private void enviarDatos(Socket servidor) throws IOException{
        ObjectOutputStream oos=new ObjectOutputStream(servidor.getOutputStream());
        oos.writeObject(r);
    }
    
    @Override
    public void run(){
        try {
            Socket servidor=new Socket("localhost",5400);
            
            
            enviarDatos(servidor);
            
            
        } catch (UnknownHostException ex) {
            Logger.getLogger(Hilo_comunicadorTCP.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Hilo_comunicadorTCP.class.getName()).log(Level.SEVERE, null, ex);
        }
        
}
    
}
