/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

import Modelos.Registro;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedList;

/**
 *
 * @author examen
 */
public class ServidorWEB {
    private LinkedList<Registro> INFO;

    public ServidorWEB(LinkedList<Registro> INFO) {
        this.INFO = INFO;
    }
    
    public void arrancarServidorWEB() throws IOException{
        ServerSocket servidor=new ServerSocket(7200);
        Socket cliente=null;
        while(true){
            cliente=servidor.accept();
            new Hilo_WEB(cliente,INFO).start();
        }
        
    }
}
