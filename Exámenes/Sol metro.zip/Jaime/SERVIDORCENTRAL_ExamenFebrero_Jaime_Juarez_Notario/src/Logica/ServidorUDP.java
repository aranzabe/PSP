/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

import Modelos.Registro;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.LinkedList;
import java.util.StringTokenizer;
import java.util.concurrent.Semaphore;

/**
 *
 * @author examen
 */
public class ServidorUDP {
    private Semaphore sem;
    private LinkedList<Registro> INFO;
    
    public ServidorUDP(Semaphore sem,LinkedList<Registro> INFO) {
        this.sem = sem;
        this.INFO=INFO;
    }
    private boolean borrarDatos(){
        boolean flag=false;
        
        if(sem.tryAcquire()){
            INFO.clear();
            sem.release();
        }
        return flag;
    }
    
    public void arrancarServidorUDP() throws IOException{
        //en este servidor no se crearan hilos, ya que si un cliente está interactuando para borrar, 
        //no habrá otro que puda borrar hasta que se haya borrado por completo.
        byte[] buffer=null;
        int puerto,longitud;
        InetAddress dir;
        String mensaje,accion;
        
        DatagramSocket s=new DatagramSocket(6300);

        while(true){
            DatagramPacket p=null;
            s.receive(p);
        
            buffer=p.getData();  
            dir=p.getAddress(); 
            longitud=p.getLength(); 
            
            //se contruye el mensaje
            mensaje=new String(buffer,0,longitud); 
            
            //cojo las 2 partes del mensaje enviado
            StringTokenizer st=new StringTokenizer(mensaje,"#");
            //lo primero seria la accion
            accion=st.nextToken();
            //lo segundo el puerto de escucha del cliente
            puerto=Integer.parseInt(st.nextToken());
            
            if(mensaje.equalsIgnoreCase("#BORRAR")){
                //se intenta borrar hasta que se borre
                while(!borrarDatos());
                
                //ya se ha borrado
                mensaje="#OK";
                buffer= mensaje.getBytes();
                
                p=new DatagramPacket(buffer, mensaje.length(), dir, puerto);
                
                s.send(p);
            }
            
        }
        
    }
}
