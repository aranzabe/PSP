/*
 * RECOLECTOR DE BASURA
 */
package Logica;

import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * RECOLECTOR DE BASURA
 */
public class GarbageCollector extends Thread{
    private LinkedList<Hilo_TCP> hilos;

    public GarbageCollector(LinkedList<Hilo_TCP> hilos) {
        this.hilos = hilos;
    }
    
    public void run(){
        int i=0;
        try {
            while(hilos!=null){
                if(i>=hilos.size()){
                    i=0;

                        Thread.sleep(2000);

                }

                if(!hilos.get(i).isAlive()){
                    hilos.remove(i);
                }
                i++;
            }
        } catch (InterruptedException ex) {
                    Logger.getLogger(GarbageCollector.class.getName()).log(Level.SEVERE, null, ex);
                }
    }
    
}
