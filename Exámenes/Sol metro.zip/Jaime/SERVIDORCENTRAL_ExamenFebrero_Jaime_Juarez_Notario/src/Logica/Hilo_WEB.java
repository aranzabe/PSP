/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

import Modelos.Registro;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.util.Date;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author examen
 */
public class Hilo_WEB extends Thread{
    private Socket cliente;
    private LinkedList<Registro> INFO;

    public Hilo_WEB(Socket cliente, LinkedList<Registro> INFO) {
        this.cliente = cliente;
        this.INFO = INFO;
    }
    
    @Override
    public void run(){
            PrintWriter out;
        try {
            
            out = new PrintWriter(new OutputStreamWriter(cliente.getOutputStream(),"8859_1") ,true);
            out.println("HTTP/1.1 200 ok");
            out.println("Server: DAM2/1.0");
            out.println("Date: "+new Date()+"");
            out.println("Content-Type: text/html");
            out.println("");
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println(" <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
            out.println("<title>Lineas de trenes</title>");
            out.println("</head>");
            out.println("<body>");
            out.println(infoTrenes());
            out.println("<body>");
            out.println("</html>");   
            
            
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(Hilo_WEB.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Hilo_WEB.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }

    private String infoTrenes() {
        String cadena = "";
        LinkedList<Registro> trenesAUX=new LinkedList<Registro>();
        boolean flag=false;
        if(INFO.size()>0){
            //empezamos buscando por el final porque al final estarán las mas actuales, 
            //tambien podriamos comparar por timestamp
            
            for(int i=INFO.size()-1;i>0;i--){
                if(trenesAUX.size()!=0){
                    //si ya hemos almacenado al menos un registro de tren
                    for(int j=0;j<trenesAUX.size();j++){
                        //comparamos si ya tenemos un registro de ese tren guardado 
                        if(trenesAUX.get(j).getLinea()==INFO.get(i).getLinea()){
                            flag=true;
                        }
                    }
                    //si no ha habido coincidencias de ese tren/linea con alguno d elos que ya hemos almacenado lo guardamos
                    if(!flag){
                        trenesAUX.add(INFO.get(i));
                    }
                }
                //si no hemos almacenado anteriormente ningun tren almacenamos el registro directamente
                else{
                    trenesAUX.add(INFO.get(i));
                }
            }//fin del for
            
            cadena=construirCadena(trenesAUX);
            
        }
        else{
            cadena="No han circulado trenes recientemente";
        }
            
        
        
        return cadena;
    }

    private String construirCadena(LinkedList<Registro> trenes) {
        String cadena="";
       
        for(int i=0;i<trenes.size();i++){
            cadena="<p>Linea: "+trenes.get(i).getLinea()+" Parada: "+trenes.get(i).getEstacion()+"</p>";
        }
        
        return cadena; 
    }
}
