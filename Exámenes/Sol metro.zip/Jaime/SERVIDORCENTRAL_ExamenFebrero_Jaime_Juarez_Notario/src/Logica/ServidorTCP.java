/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

import Modelos.Registro;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedList;
import java.util.concurrent.Semaphore;

/**
 *
 * @author examen
 */
public class ServidorTCP {
    private LinkedList<Registro> INFO;
    private Semaphore sem;
    public ServidorTCP(LinkedList<Registro> INFO,Semaphore sem) {
        this.INFO = INFO;
        this.sem=sem;
    }
    
    public void arrancarServidorTCP() throws IOException{
        ServerSocket servidor=new ServerSocket(5400);
        Socket cliente=null;
        LinkedList<Hilo_TCP> hilos=new LinkedList<Hilo_TCP>();
        
        //recolector de hilos muertos
        GarbageCollector recolectorBasura=new GarbageCollector(hilos);
        recolectorBasura.start();
        
        
        while(true){
            //esperamos cliente nuevo
            cliente=servidor.accept();
            
            //se le asigna un hilo a ese cliente y se inicia
            Hilo_TCP hilo=new Hilo_TCP(cliente,INFO,sem);
            hilo.start();
            
            //guardamos el hilo por si debemos eliminarlo posteriormente
            hilos.add(hilo);
            
        }
        
    }
}
