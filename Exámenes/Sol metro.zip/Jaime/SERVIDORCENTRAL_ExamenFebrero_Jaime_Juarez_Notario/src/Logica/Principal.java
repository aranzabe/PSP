/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

import Modelos.Registro;
import java.io.IOException;
import java.util.LinkedList;
import java.util.concurrent.Semaphore;

/**
 *
 * @author examen
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        LinkedList<Registro> INFO=new LinkedList<Registro>();
        
        //semaforo necesario para guardar y borrar los datos con integridad
        Semaphore sem=new Semaphore(1);
        
        //iniciamos servidor TCP
        ServidorTCP TCP=new ServidorTCP(INFO,sem);
        TCP.arrancarServidorTCP();
        
        //iniciamos servidorUDP
        ServidorUDP UDP=new ServidorUDP(sem,INFO);
        UDP.arrancarServidorUDP();
        
        //iniciamos servidorWEB
        ServidorWEB WEB=new ServidorWEB(INFO);
        WEB.arrancarServidorWEB();
        
        
        
    }
}
