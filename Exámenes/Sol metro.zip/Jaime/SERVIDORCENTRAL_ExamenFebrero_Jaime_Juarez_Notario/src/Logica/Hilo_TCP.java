/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

import Modelos.Registro;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;
import java.util.LinkedList;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author examen
 */
public class Hilo_TCP extends Thread{
    private Socket cliente;
    private Registro r;
    private LinkedList<Registro> INFO;
    private Semaphore sem;
    
    Hilo_TCP(Socket cliente,LinkedList<Registro> INFO,Semaphore sem) {
       this.cliente=cliente;
       r=null;
       this.sem=sem;
       this.INFO=INFO;
    }
    
    public void recibirDatos() throws IOException, ClassNotFoundException{
        ObjectInputStream ois=new ObjectInputStream(cliente.getInputStream());
        r=(Registro) ois.readObject();
    }
    public synchronized boolean guardarDatos(){
        boolean flag=false;
        if(sem.tryAcquire()){
            INFO.add(r);
            flag=true;
            sem.release();
        }
        return flag;
    }
    
    @Override
    public void run()
    {
        try {
            //espero para recibir datos
            recibirDatos();
            
            //intento guardar los datos hasta que pueda
            while(!guardarDatos());
            
            //si se han guardado los datos se acaba el hilo
            
        } catch (IOException ex) {
            Logger.getLogger(Hilo_TCP.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Hilo_TCP.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    
}
