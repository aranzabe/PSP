/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidorweb;

import clases.Mapa;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.util.Date;
import javax.crypto.Cipher;
import javax.crypto.SealedObject;

/**
 *
 * @author examen
 */
public class HiloComunicacion extends Thread {

    private Socket cliente;
    private PublicKey clavepubl;
    private PrivateKey claveprv;

    public HiloComunicacion(Socket cliente) {
        this.cliente = cliente;
    }

    @Override
    public void run() {
        try {

            generarClaves();

            //Conectamos con Hogwarts
            Socket recibirMapa = new Socket("localhost", 5000);
            ObjectOutputStream flujoS = new ObjectOutputStream(recibirMapa.getOutputStream());
            flujoS.writeObject("MAPA");
            flujoS.writeObject(this.clavepubl);

            ObjectInputStream flujoE = new ObjectInputStream(recibirMapa.getInputStream());
            SealedObject cifrado = (SealedObject) flujoE.readObject();

            Cipher c = c = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            c.init(Cipher.DECRYPT_MODE, claveprv);

            Mapa mapa = (Mapa) cifrado.getObject(c);

            mostrarMapa(mapa);
        } catch (Exception ex) {

        }
    }
    /**
     * Procedimiento que genera las claves
     * @throws NoSuchAlgorithmException 
     */
    private void generarClaves() throws NoSuchAlgorithmException {
        //Generamos las claves publica y privada
        KeyPairGenerator KeyGen = KeyPairGenerator.getInstance("RSA");
        KeyGen.initialize(2048);
        KeyPair par = KeyGen.generateKeyPair();
        claveprv = par.getPrivate();
        clavepubl = par.getPublic();
    }
    /**
     * Procedimiento que muestra el mapa en la página web
     * @param mapa 
     */
    private void mostrarMapa(Mapa mapa) {
        try {
            PrintWriter out = new PrintWriter(new OutputStreamWriter(cliente.getOutputStream(), "8859_1"), true);
            out.println("HTTP/1.1 200 ok");
            out.println("Server: DAM2/1.0");
            out.println("Date: " + new Date() + "");
            out.println("Content-Type: text/html");
            out.println("");
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println(" <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
            out.println("<title>No encontrada.</title>");
            out.println("</head>");

            for (int i = 0; i < mapa.getHabitaciones().length; i++) {
                for (int j = 0; j < mapa.getHabitaciones()[i].length; j++) {
                    if (mapa.getHabitaciones()[i][j].getPersonaje() != null) {
                        out.println("En la habitación: " + i + " - " + j + " está: " + mapa.getHabitaciones()[i][j].getPersonaje().getNombre());
                    }
                }
            }
            
            for(int i=0; i<mapa.getEscaleras().size();i++){
                out.println("La escalera: "+(i+1)+" Se encuentra en origen en la habitación de: "+mapa.getEscaleras().get(i).getOrigen().getPersonaje().getNombre());
                out.println("La escalera: "+(i+1)+" Se encuentra en destino en la habitación de: "+mapa.getEscaleras().get(i).getDestino().getPersonaje().getNombre());
            }

            out.println("</html>");
        } catch (Exception ex) {

        }
    }

}
