/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.util.Objects;

/**
 *
 * @author examen
 */
public class Personaje implements java.io.Serializable {

    private String nombre;
    private String cargo;

    public Personaje() {
    }

    public Personaje(String nombre, String cargo) {
        this.nombre = nombre;
        this.cargo = cargo;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the cargo
     */
    public String getCargo() {
        return cargo;
    }

    /**
     * @param cargo the cargo to set
     */
    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public byte[] getBytes() {
        byte[] bytes = new byte[this.nombre.getBytes().length + this.cargo.getBytes().length];
        for (int i = 0; i < this.nombre.getBytes().length; i++) {
            bytes[i] = this.nombre.getBytes()[i];
        }

        for (int i = this.nombre.getBytes().length; i < this.cargo.getBytes().length; i++) {
            bytes[i] = this.cargo.getBytes()[i];
        }

        return bytes;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Personaje other = (Personaje) obj;
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        if (!Objects.equals(this.cargo, other.cargo)) {
            return false;
        }
        return true;
    }

}
