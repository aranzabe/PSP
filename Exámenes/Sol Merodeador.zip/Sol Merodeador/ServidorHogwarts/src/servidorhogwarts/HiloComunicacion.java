/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidorhogwarts;

import clases.Mapa;
import clases.Personaje;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.security.PublicKey;
import javax.crypto.Cipher;
import javax.crypto.SealedObject;
import javax.crypto.SecretKey;

/**
 *
 * @author examen
 */
public class HiloComunicacion extends Thread {

    private Socket cliente;
    private Colegio colegio;

    public HiloComunicacion(Socket cliente, Colegio colegio) {
        this.cliente = cliente;
        this.colegio = colegio;
    }

    @Override
    public void run() {
        boolean desconectado = false;
        while (!desconectado) {
            try {
                ObjectInputStream flujoE = new ObjectInputStream(cliente.getInputStream());
                String opcion = (String) flujoE.readObject();
                
                switch (opcion){
                    case "COMPROBAR_PERSONAJE":
                        Personaje p = (Personaje)flujoE.readObject();
                        comprobarPersonaje(p);
                        break;
                    case "REGISTRAR":
                        SealedObject cifrado = (SealedObject)flujoE.readObject();
                        byte[]firma = (byte[])flujoE.readObject();
                        SecretKey clave = (SecretKey)flujoE.readObject();
                        PublicKey publica = (PublicKey)flujoE.readObject();
                        registrarPersonaje(cifrado,firma,clave,publica);
                        break;
                    case "DESCONECTAR":
                        desconectado = true;
                        cliente.close();
                        break;
                    case "MAPA":
                        PublicKey clavePublica = (PublicKey)flujoE.readObject();
                        enviarMapa(clavePublica);
                        break;
                }
                
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
    /**.
     * Procedimiento que comprueba si existe un personaje en el colegio y, según
     * lo que le diga el colegio, lo manda al cliente
     * @param p personaje que se va a comprobar
     */
    private void comprobarPersonaje(Personaje p){
        try{
            boolean existe = this.colegio.comprobarPersonaje(p);
            
            ObjectOutputStream flujoS = new ObjectOutputStream(cliente.getOutputStream());
            flujoS.writeObject(existe);
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
    /**
     * Procedimiento que se encarga de registrar un personaje en el colegio
     * @param cifrado objeto cifrado que contiene al personaje
     * @param firma firma
     * @param clave clave para descifrar el personaje
     * @param publica clave publica para comprobar la firma
     */
    private void registrarPersonaje(SealedObject cifrado, byte[]firma,SecretKey clave, PublicKey publica){
        try{
            Cipher c = Cipher.getInstance("AES/ECB/PKCS5Padding");
            c.init(Cipher.DECRYPT_MODE, clave);
            
            Personaje p = (Personaje)cifrado.getObject(c);
            
            boolean metido = this.colegio.meterPersonaje(p);
            
            ObjectOutputStream flujoS = new ObjectOutputStream(cliente.getOutputStream());
            flujoS.writeObject(metido);
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
    
    private void enviarMapa(PublicKey publica){
        try{
            Cipher c = c = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            c.init(Cipher.ENCRYPT_MODE, publica);
            
            Mapa m = new Mapa(this.colegio.getMapa(), this.colegio.getEscaleras());
            
            SealedObject sealedObject = new SealedObject(m,c);
            
            ObjectOutputStream flujoS = new ObjectOutputStream(cliente.getOutputStream());
            flujoS.writeObject(sealedObject);
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
    
}
