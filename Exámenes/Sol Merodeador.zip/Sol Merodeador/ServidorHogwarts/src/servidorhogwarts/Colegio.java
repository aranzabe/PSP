/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidorhogwarts;

import clases.Escalera;
import clases.Habitacion;
import clases.Personaje;
import java.util.ArrayList;

/**
 *
 * @author examen
 */
public class Colegio {

    private Habitacion[][] cole = new Habitacion[6][5];

    private ArrayList<Escalera> escaleras = new ArrayList<Escalera>();

    public Colegio() {
        ponerHabitaciones();
        ponerEscaleras();
    }

    private void ponerHabitaciones() {
        for (int i = 0; i < cole.length; i++) {
            for (int j = 0; j < cole[i].length; j++) {
                cole[i][j] = new Habitacion();
            }
        }
    }

    private void ponerEscaleras() {
        //Establecemos origen y destino
        escaleras.add(new Escalera(cole[0][1], cole[1][1]));
        //Ponemos que están ocupadas esas ya
        cole[0][1].setSeleccionada(true);
        cole[1][1].setSeleccionada(true);

        escaleras.add(new Escalera(cole[0][3], cole[0][4]));
        //Ponemos que están ocupadas esas ya
        cole[0][3].setSeleccionada(true);
        cole[0][4].setSeleccionada(true);

        escaleras.add(new Escalera(cole[2][3], cole[3][3]));
        //Ponemos que están ocupadas esas ya
        cole[2][3].setSeleccionada(true);
        cole[3][3].setSeleccionada(true);

        escaleras.add(new Escalera(cole[3][0], cole[3][1]));
        //Ponemos que están ocupadas esas ya
        cole[3][0].setSeleccionada(true);
        cole[3][1].setSeleccionada(true);

        escaleras.add(new Escalera(cole[4][1], cole[5][1]));
        //Ponemos que están ocupadas esas ya
        cole[4][1].setSeleccionada(true);
        cole[5][1].setSeleccionada(true);

        escaleras.add(new Escalera(cole[5][2], cole[5][3]));
        //Ponemos que están ocupadas esas ya
        cole[5][2].setSeleccionada(true);
        cole[5][3].setSeleccionada(true);
    }

    /**
     * Función que devuelve true o false dependiendo de si un personaje existe
     * ya en el colegio o no
     *
     * @param p
     * @return
     */
    public synchronized boolean comprobarPersonaje(Personaje p) {
        boolean valido = true;
        for (int i = 0; i < cole.length; i++) {
            for (int j = 0; j < cole[i].length; j++) {
                if (cole[i][j].getPersonaje() != null) {
                    //Si hay uno igual dejamos de buscar
                    if (cole[i][j].getPersonaje().equals(p)) {
                        return false;
                    }
                }
            }
        }
        return valido;
    }

    /**
     * Función que mete un personaje en el colegio, comprobando en habitaciones
     * aleatorias, una que esté vacía
     *
     * @param p personaje que se quiere meter en el colegio
     * @return true para que se verifique que se ha metido en el colegio
     */
    public synchronized boolean meterPersonaje(Personaje p) {
        int fila = (int) (Math.random() * cole.length);
        int columna = (int) (Math.random() * cole[fila].length);

        while (cole[fila][columna].getPersonaje() != null) {
            fila = (int) (Math.random() * cole.length);
            columna = (int) (Math.random() * cole[fila].length);
        }
        cole[fila][columna].setPersonaje(p);
        System.out.println("Se ha registrado un personaje en la habitación: " + fila + " - " + columna + "\nSus datos son: " + p.getNombre() + " - " + p.getCargo());
        return true;
    }
    /**
     * Procedimiento que se encarga de mover una escalera de una posición a otra
     * @param escalera 
     */
    public synchronized void moverEscalera(int escalera) {
        Escalera e = escaleras.get((escalera == 0) ? 0 : escalera - 1);
        e.getOrigen().setSeleccionada(false);
        e.getDestino().setSeleccionada(false);
        //Sacamos una posiicón al azar
        int fila = (int) (Math.random() * cole.length);
        int columna = (int) (Math.random() * cole[fila].length);
        //Miramos que esa posición no esté ya seleccionada por otra escalera
        while (cole[fila][columna].getSeleccionada()) {
            fila = (int) (Math.random() * cole.length);
            columna = (int) (Math.random() * cole[fila].length);
        }
        //Establecemos como origen de la escalera la habitación al azar sorteada anteriormente
        e.setOrigen(cole[fila][columna]);
        
        int filaDestino = (int) (Math.random() * cole.length);
        int columnaDestino = (int) (Math.random() * cole[fila].length);
        
        
        
        //Volvemos a sortear, mientras que esté ya seleccionada una habitación, o no sea la adyacente
        while ((cole[filaDestino][columnaDestino].getSeleccionada())&&((fila-filaDestino == 1 || fila-filaDestino == 1 || fila-filaDestino==0)&&(columna-columnaDestino == 1 || columna-columnaDestino == 1 || columna-columnaDestino==0))) {
            fila = (int) (Math.random() * cole.length);
            columna = (int) (Math.random() * cole[fila].length);
        }
        
        e.setDestino(cole[filaDestino][columnaDestino]);
        cole[filaDestino][columnaDestino].setSeleccionada(true);
        cole[fila][columna].setSeleccionada(true);
        
        System.out.println("La escalera nº: "+(escalera-1)+" se ha movido a la posición: "+fila+" - "+columna+"    -    "+filaDestino+" - "+columnaDestino);
        
        //Comprobamos si hay personajes en las habitciones o si sólo hay uno
        if(cole[fila][columna].getPersonaje()!=null && cole[filaDestino][columnaDestino].getPersonaje()!=null){
            //Si hay personajes en ambas habitaciones, se intercambian las habitaciones
            Personaje origen = cole[fila][columna].getPersonaje();
            cole[fila][columna].setPersonaje(cole[filaDestino][columnaDestino].getPersonaje());
            cole[filaDestino][columnaDestino].setPersonaje(origen);
        }else{
            //Si sólo hay uno, miramos dónde está y le cambiamos de habitación
            if(cole[fila][columna].getPersonaje()!=null){
                cole[filaDestino][columnaDestino].setPersonaje(cole[fila][columna].getPersonaje());
            }else{
                cole[fila][columna].setPersonaje(cole[filaDestino][columnaDestino].getPersonaje());
            }
        }
    }
    
    public synchronized Habitacion[][] getMapa(){
        return this.cole;
    }
    
    public synchronized ArrayList<Escalera> getEscaleras(){
        return this.escaleras;
    }

}
