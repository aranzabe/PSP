/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidorhogwarts;

/**
 *
 * @author examen
 */
public class CambiarEscaleras extends Thread{
    private Colegio cole;
    
    public CambiarEscaleras(Colegio cole){
        this.cole = cole;
    }
    
    @Override
    public void run(){
        while(true){
            try{
                int escalera = (int)(Math.random()*6);
                cole.moverEscalera(escalera);
                
                Thread.sleep((long)(Math.random()*100000));
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }
    
}
