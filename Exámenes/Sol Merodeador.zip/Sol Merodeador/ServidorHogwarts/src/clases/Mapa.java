/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.util.ArrayList;

/**
 *
 * @author examen
 */
public class Mapa implements java.io.Serializable{
    
    private Habitacion[][] habitaciones;
    private ArrayList<Escalera> escaleras;
    
    public Mapa(){}

    public Habitacion[][] getHabitaciones() {
        return habitaciones;
    }

    public void setHabitaciones(Habitacion[][] habitaciones) {
        this.habitaciones = habitaciones;
    }

    public ArrayList<Escalera> getEscaleras() {
        return escaleras;
    }

    public void setEscaleras(ArrayList<Escalera> escaleras) {
        this.escaleras = escaleras;
    }

    public Mapa(Habitacion[][] habitaciones, ArrayList<Escalera> escaleras) {
        this.habitaciones = habitaciones;
        this.escaleras = escaleras;
    }
    
    
    
}
