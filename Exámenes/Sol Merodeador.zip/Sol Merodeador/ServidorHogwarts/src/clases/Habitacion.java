/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.util.concurrent.Semaphore;

/**
 *
 * @author examen
 */
public class Habitacion implements java.io.Serializable {

    private Personaje personaje;
    private boolean seleccionada;

    public Habitacion() {
    }

    public Habitacion(Personaje personaje) {
        this.personaje = personaje;
    }

    /**
     * @return the personaje
     */
    public Personaje getPersonaje() {
        return personaje;
    }

    /**
     * @param personaje the personaje to set
     */
    public void setPersonaje(Personaje personaje) {
        this.personaje = personaje;
    }

    public boolean getSeleccionada() {
        return seleccionada;
    }

    public void setSeleccionada(boolean seleccionada) {
        this.seleccionada = seleccionada;
    }

}
