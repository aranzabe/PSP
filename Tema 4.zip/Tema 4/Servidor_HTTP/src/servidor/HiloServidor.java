/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Fernando
 */
public class HiloServidor extends Thread {

    private Socket scliente;

    public HiloServidor(Socket cliente) {
        scliente = cliente;
    }

    @Override
    public void run() {
        String leido, nombre_fichero = "index.htm";
        PrintWriter out = null;
        File f = null;

        try {
            out = new PrintWriter(new OutputStreamWriter(scliente.getOutputStream(), "8859_1"), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(scliente.getInputStream()));
            leido = in.readLine();

//Comentar desde aquí     
            out.println("HTTP/1.1 200 ok");
            out.println("Server: DAM2/1.0");
            out.println("Date: " + new Date() + "");
            out.println("Content-Type: text/html");
            out.println("");
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");

            out.println(" <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
            out.println("<title>DAM2 2016 2017</title>");
            out.println("</head>");

            for (int i = 0; i < 10; i++) {
                out.print("7 x " + i + " = " + 7 * i + "<br>");
            }

            out.println("<p>Otra cosa para que veais que es esto");
            out.println("</html>");

            //Comentar desde aquí
            //Con este bloque veremos si en la barra del navegador se ha solicitado algún archivo concreto.
//            while (leido != null && leido.length() > 0) {
//                if (leido.startsWith("GET")) {
//                    nombre_fichero = leido.substring(5, leido.indexOf("HTTP"));
//                    nombre_fichero = nombre_fichero.trim();
//                }
//                System.out.println(leido);//Esto se puede comentar luego, es solo para ver lo que el navegador envía.
//                leido = in.readLine();
//            }
//
//            //Si se ha solicitado un archivo concreto se abre en modo texto y se lanza línea a línea al navegador
//            //a través del socket.
//            if (nombre_fichero.length() == 0) {
//                nombre_fichero = "index.htm"; //Si no se ha puesto nombre de fichero
//            }                                                                        //por ejemplo: http://localhost:9000;
//            //se carga el fichero index.htm
//            f = new File(nombre_fichero);
//            //Si el fichero existe, se lee línea a línea.
//            if (f.exists()) {
//                //System.out.println("\nFichero existe\n");
//                //FileInputStream fd = new FileInputStream("index.txt");
//                //FileInputStream fd = new FileInputStream("index.htm");
//                //FileInputStream fd = new FileInputStream("formulario.htm");
//                FileInputStream fd = new FileInputStream(nombre_fichero);
//                BufferedReader bf = new BufferedReader(new InputStreamReader(fd));
//
//                //Este bloque de instrucciones debe ir el primero para indicar al navegador 
//                //que la página se ha encontrado y se va a proceder a mandarle texto html.
//                out.println("HTTP/1.1 200 ok");
//                out.println("Server: DAM2/1.0");
//                out.println("Date: " + new Date() + "");
//                out.println("Content-Type: text/html");
//                out.println("");
//
//                //Se lee línea a línea el texto plano del fichero htm y se lanza a través del socket 
//                //al navegador.
//                leido = bf.readLine();
//                while (leido != null) {
//                    out.println(leido);
//                    leido = bf.readLine();
//                }
//
//                bf.close();
//            }//Si el fichero no existe carga una página de error estándar.
//            else {
//                //System.out.println("\nFichero no existe\n");
//                out.println("HTTP/1.1 404 Not Found");
//                out.println("Server: DAM2/1.0");
//                out.println("Date: " + new Date() + "");
//                out.println("Content-Type: text/html");
//                out.println("");
//                out.println("<!DOCTYPE html>");
//                out.println("<html>");
//                out.println("<head>");
//                out.println(" <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
//                out.println("<title>No encontrada.</title>");
//                out.println("</head>");
//                out.println("Pagina no encontrada.");
//                out.println("</html>");
//            }

            //
            out.close();

        } catch (IOException ex) {
            Logger.getLogger(HiloServidor.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
