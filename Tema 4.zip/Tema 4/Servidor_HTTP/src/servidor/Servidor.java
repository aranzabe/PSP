
package servidor;

import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *  ServerSocket (9000)
 * Socket, es el navegador web
 * Crear
 * Mandar al navegador:
 * A. texto plano 
 * B. Cabeceras (Texto html)
 * C. Servir un archivo
 */
public class Servidor {

    
    public static void main(String[] args) {
        ServerSocket servidor;
        Socket cliente;        
        int PUERTO = 9000;
        HiloServidor h1;

        try {
            servidor = new ServerSocket(PUERTO);
            System.out.println("Servidor arrancado");
            System.out.println("Esperando llamada");
            
        do {
            cliente = servidor.accept();
            System.out.println("Nueva petición");
            h1= new HiloServidor(cliente);
            h1.start();
        } while (true);
        }
            catch (Exception e)
        {
            e.printStackTrace();
        }
        }
}
