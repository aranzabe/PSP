/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor_http_tablamultiplicar;

import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author iveen
 */
public class Servidor extends Thread{

    ServerSocket servidor;
    Socket cliente;
    int PUERTO;
    Hilo_Server h1;

    public Servidor(int puerto) {
        this.PUERTO = puerto;
    }

    public void run() {
        try {
            servidor = new ServerSocket(PUERTO);
            System.out.println("Servidor arrancado");
            System.out.println("Esperando llamada");

            do {
                cliente = servidor.accept();
                System.out.println("Nueva petición");
                h1 = new Hilo_Server(cliente);
                h1.start();
            } while (true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
