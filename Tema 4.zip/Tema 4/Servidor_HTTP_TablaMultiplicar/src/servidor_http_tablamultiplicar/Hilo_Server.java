/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor_http_tablamultiplicar;

import static com.sun.corba.se.spi.presentation.rmi.StubAdapter.request;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author iveen
 */
public class Hilo_Server extends Thread {
    
    private Socket scliente;
    private PrintWriter out;
    
    public Hilo_Server(Socket cliente) {
        scliente = cliente;
    }
    
    @Override
    public void run() {
        String leido, nombre_fichero = "";
        PrintWriter out = null;
        File f = null;
        boolean isPost = false;
        
        try {
            out = new PrintWriter(new OutputStreamWriter(scliente.getOutputStream(), "8859_1"), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(scliente.getInputStream()));
            leido = in.readLine();
            
            int postDataI = -1;
            //Comentar desde aquí
            //Con este bloque veremos si en la barra del navegador se ha solicitado algún archivo concreto.
            while (leido != null && leido.trim().length() > 0) {
                if (leido.startsWith("GET")) {
                    nombre_fichero = leido.substring(5, leido.indexOf("HTTP"));
                    nombre_fichero = nombre_fichero.trim();
                    System.out.println(nombre_fichero);
                }
                
                if (leido.startsWith("POST")) {
                    isPost = true;
                }
                
                if (leido.startsWith("Content-Length:")) {
                    postDataI = new Integer(leido.trim().substring(leido.indexOf("Content-Length:") + 16, leido.length())).intValue();
                    System.out.println(postDataI);
                }
                
                System.out.println(leido);//Esto se puede comentar luego, es solo para ver lo que el navegador envía.
                leido = in.readLine();
            }
            
            String postData = "";
            
            if (isPost) {
                for (int i = 0; i < postDataI; i++) {
                    int intParser = in.read();
                    postData += (char) intParser;
                }
                
                postData = postData.substring(7, postData.length());
                
                System.out.println("Numero Pedido: " + postData);
            }

            //Si se ha solicitado un archivo concreto se abre en modo texto y se lanza línea a línea al navegador
            //a través del socket.
            if (nombre_fichero.length() == 0) {
                nombre_fichero = "index.html"; //Si no se ha puesto nombre de fichero
            }                                                                        //por ejemplo: http://localhost:9000;
            //se carga el fichero index.htm
            f = new File(nombre_fichero);
            //Si el fichero existe, se lee línea a línea.

            if (isPost) {
                int numero = Integer.parseInt(postData);
                out.println("HTTP/1.1 200 ok");
                out.println("Server: DAM2/1.0");
                out.println("Date: " + new Date() + "");
                out.println("Content-Type: text/html");
                out.println("");
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                
                out.println(" <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
                out.println("<title>Tabla de multiplicar to wapa</title>");
                out.println("</head>");
                out.print("<body>");
                
                out.print("<h1>El numero pedido es: " + numero + "</h1>");
                
                for (int i = 0; i < 10; i++) {
                    out.print(numero + " x " + i + " = " + numero * i + "<br>");
                }
                
                out.print("</body>");
                out.println("</html>");
            } else {
                if (f.exists()) {
                    //System.out.println("\nFichero existe\n");
                    //FileInputStream fd = new FileInputStream("index.txt");
                    //FileInputStream fd = new FileInputStream("index.htm");
                    //FileInputStream fd = new FileInputStream("formulario.htm");
                    FileInputStream fd = new FileInputStream(nombre_fichero);
                    BufferedReader bf = new BufferedReader(new InputStreamReader(fd));

                    //Este bloque de instrucciones debe ir el primero para indicar al navegador 
                    //que la página se ha encontrado y se va a proceder a mandarle texto html.
                    out.println("HTTP/1.1 200 ok");
                    out.println("Server: DAM2/1.0");
                    out.println("Date: " + new Date() + "");
                    out.println("Content-Type: text/html");
                    out.println("");

                    //Se lee línea a línea el texto plano del fichero htm y se lanza a través del socket 
                    //al navegador.
                    leido = bf.readLine();
                    while (leido != null) {
                        out.println(leido);
                        leido = bf.readLine();
                    }
                    
                    bf.close();
                    
                }//Si el fichero no existe carga una página de error estándar.
                else {
                    //System.out.println("\nFichero no existe\n");
                    out.println("HTTP/1.1 404 Not Found");
                    out.println("Server: DAM2/1.0");
                    out.println("Date: " + new Date() + "");
                    out.println("Content-Type: text/html");
                    out.println("");
                    out.println("<!DOCTYPE html>");
                    out.println("<html>");
                    out.println("<head>");
                    out.println(" <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
                    out.println("<title>No encontrada.</title>");
                    out.println("</head>");
                    out.println("Pagina no encontrada.");
                    out.println("</html>");
                }
            }
            
            out.flush();
            
        } catch (IOException ex) {
            Logger.getLogger(Hilo_Server.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}
