/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente_ftp;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.commons.net.ftp.*;

/**
 *
 * @author faranzabe
 */
public class Cliente_FTP {

    /**
     * @param args the command line arguments
     */
    
    public static void Listar_Archivos(FTPFile archs[]){
        String tipos[]={"Fichero","Directorio","Enlace simb."};
        
        for(int i=0;i<archs.length;i++){
                System.out.println("\t" + archs[i].getName()+"=>"+tipos[archs[i].getType()]);
            }
    }
    
    public static void main(String[] args) throws IOException {
        FTPClient cliente = new FTPClient();
//        String servFTP = "ftp.rediris.es";
//        String usuario = "anonymous";
//        String clave = "anonymous";
        String servFTP = "172.17.209.232";
        String usuario = "otro";
        String clave = "Chubaca2019";
        
        //Auxiliares
        FTPFile archs[];
        boolean login, logout;
        String nombrefichero;
        BufferedInputStream in;
        BufferedOutputStream out;
        
        System.out.println("Conectando al servidor " + servFTP);
        cliente.connect(servFTP);
        login = cliente.login(usuario, clave);
        
        if (login){
            System.out.println("Login correcto");
            
            //Respondiendo el servidor
            System.out.println(cliente.getReplyString());
            //Código de respuesta
            System.out.println(cliente.getReplyCode());
            
            System.out.println("Directorio actual " + cliente.printWorkingDirectory());
            archs = cliente.listFiles();
            System.out.println("Ficheros en el directorio actual: " + archs.length);
            Listar_Archivos(archs);
            
            //Subiendo un fichero
            nombrefichero = "ejemplo.txt";
            System.out.println("Subiendo el archivo '" + nombrefichero + "'");
            cliente.setFileType(FTP.BINARY_FILE_TYPE);//Modo habitual de fichero para la transferencia.
            in = new BufferedInputStream(new FileInputStream(nombrefichero));
            cliente.storeFile("ejemplo.txt", in);
            System.out.println("'" + nombrefichero + "' subido");
            in.close();
            
            
            //Descargando un fichero
            if (cliente.changeWorkingDirectory(cliente.printWorkingDirectory()+"docs")){
                System.out.println("Directorio cambiado.");
                System.out.println("Directorio actual " + cliente.printWorkingDirectory());
                archs = cliente.listFiles();
                System.out.println("Ficheros en el directorio actual: " + archs.length);
                Listar_Archivos(archs);
            }
            else {
                System.out.println("Error al cambiar de directorio");
            }
            nombrefichero = "spock.jpg";
            out = new BufferedOutputStream(new FileOutputStream(nombrefichero));
            if (cliente.retrieveFile(nombrefichero, out)){
                System.out.println("Fichero recuperado correctamente.");
            }
            else {
                System.out.println("No se ha podido descargar.");
            }
            
            //Haciendo logout y desconectando del servidor
            logout = cliente.logout();
            if (logout){
                System.out.println("Logout del servidor FTP.");
            }
            else
                System.out.println("Error al hacer logout");
            
            cliente.disconnect();
            System.out.println("Desconectado...");

//            int respuesta = cliente.getReplyCode();
//            if (!FTPReply.isPositiveCompletion(respuesta)){
//                cliente.disconnect();
//                System.out.println("Conexión rechazada");
//            }
//            else {
//                cliente.disconnect();
//                System.out.println("Conexión finalizada normalmente");
//            }
            
        }
        else {
            System.out.println("Login incorrecto");
            cliente.disconnect();
        }
        
        
    }
    
}
