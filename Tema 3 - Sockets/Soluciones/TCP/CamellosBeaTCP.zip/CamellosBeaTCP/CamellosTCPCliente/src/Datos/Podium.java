/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

/**
 *
 * @author faranzabe
 */
public class Podium {

    public int podio[] = new int[4];

    public void addFinalizado(int dorsal) {
        int i = 0;
        boolean colocado = false;
        while (i < this.podio.length && !colocado) {
            if (this.podio[i] == 0) {
                this.podio[i] = dorsal;
                colocado = true;
            } else {
                i++;
            }
        }
    }

    public void mostrarPodium() {
        for (int i = 0; i < this.podio.length; i++) {
            System.out.print(this.podio[i] + " ");
        }
        System.out.println("");
    }

}
