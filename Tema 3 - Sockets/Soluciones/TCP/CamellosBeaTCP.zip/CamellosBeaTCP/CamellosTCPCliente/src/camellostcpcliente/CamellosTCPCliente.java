/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package camellostcpcliente;

import Datos.Podium;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Usuario
 */
public class CamellosTCPCliente {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            InetAddress dir;
            Socket servidor = null;
            int puerto = 5000;
            String mensaje;
            boolean primeraVez = true;
            Podium pod = null;

            dir = InetAddress.getLocalHost(); // dirección local
            servidor = new Socket(dir, puerto);//Petición para el accept
            DataOutputStream enviar = new DataOutputStream(servidor.getOutputStream());
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            DataInputStream recibir = new DataInputStream(servidor.getInputStream());
            ObjectInputStream entrSoc = new ObjectInputStream(servidor.getInputStream());

            System.out.println("¿Cuál es tú nombre?");
            enviar.writeUTF(br.readLine());
            do {

                //Recibimos mensaje 
                mensaje = recibir.readUTF();
                System.out.println(mensaje);

            } while (!mensaje.equals("Fin !!!!!"));

            try {
                pod = (Podium) entrSoc.readObject();
            } catch (ClassNotFoundException ex) {
            }
            pod.mostrarPodium();

            servidor.close();
        } catch (SocketException ex) {

        } catch (UnknownHostException ex) {
            Logger.getLogger(CamellosTCPCliente.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(CamellosTCPCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
