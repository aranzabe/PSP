/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package camellostcpservidor;

import Datos.Podium;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Usuario
 */
public class CamellosTCPServidor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        try {
            ServerSocket ss = new ServerSocket(5000);;
            Socket s;
            Podium pod = new Podium();
            int cantCamellos = 4;
            int cont = 0;
            Hilo camello[] = new Hilo[cantCamellos];

            while (cont < cantCamellos) {
                s = ss.accept();
                camello[cont] = new Hilo(s, pod);
                cont++;
            }

            for (int i = 0; i < camello.length; i++) {
                camello[i].start();
            }

            for (int i = 0; i < camello.length; i++) {
                try {
                    camello[i].join();
                } catch (InterruptedException ex) {
                }
            }

            for (int i = 0; i < camello.length; i++) {
                camello[i].enviarPodium();
            }
        } catch (IOException ex) {

        }

    }

}
