/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package camellostcpservidor;

import Datos.Podium;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Usuario
 */
public class Hilo extends Thread {

    Socket cliente;
    DataOutputStream enviar;
    DataInputStream recibir;
    private String nombre;
    private static int dorsal = 0;
    private static int ganador = 0;
    Podium pod;

    public Hilo(Socket cliente, Podium pod) throws IOException {
        this.dorsal++;
        this.cliente = cliente;
        this.pod = pod;
        enviar = new DataOutputStream(cliente.getOutputStream());
        recibir = new DataInputStream(cliente.getInputStream());

        this.setNombre(recibir.readUTF());

        enviar.writeUTF("Hola " + this.getNombre() + " con dorsal: " + this.getDorsal() + " va a comenzar la carrera... YA!!!!");

    }

    @Override
    public void run() {
        try {
            int avance;
            int pos = 0;
            String mensaje;
            boolean continuar = true;

            while (continuar) {

                //Creamos el porcentaje 
                avance = (int) Math.floor(Math.random() * 100 + 1);

                if (avance < 40) {//Si el avance es menor a 40 
                    if (pos < 3) {//y la posicion menor a 3
                        pos++;//aumentamos posicion

                        mensaje = (this.getNombre() + " en posicion: " + pos);

                        enviar.writeUTF(mensaje);

                    }
                }
                if (avance < 30) {//Si el avance es menor a 30
                    if (pos < 7) {//Y la posicion menor a 7
                        pos++;//aumentamos posicion

                        mensaje = (this.getNombre() + " en posicion: " + pos);
                        enviar.writeUTF(mensaje);

                    }
                }
                if (avance < 20) {//Si el avance es menor a 20
                    if (pos < 9) {//y la posicion menor a 9
                        pos++;//aumentamos posicion

                        mensaje = (this.getNombre() + " en posicion: " + pos);
                        enviar.writeUTF(mensaje);

                    }
                }
                if (avance < 10) {//Si el avance es menor a 10
                    if (pos < 10) {//Y la posicion menor a 10

                        pos++;//Aumentamos posicion

                        mensaje = (this.getNombre() + " en posicion: " + pos);
                        enviar.writeUTF(mensaje);

                    }
                    if (pos == 10) {
                        mensaje = podio();
                        continuar = false;
                        enviar.writeUTF(mensaje);

                        mensaje = "Fin !!!!!";
                        enviar.writeUTF(mensaje);

                    }
                }

                Thread.sleep(1000);

            }

            cliente.close();

        } catch (IOException ex) {
            Logger.getLogger(Hilo.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InterruptedException ex) {
            Logger.getLogger(Hilo.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private synchronized String podio() {
        this.pod.addFinalizado(this.getDorsal());//Asignamos el camello en su posicion del podio
        String mensaje = ("\n" + this.getNombre() + " con dorsal: " + this.getDorsal() + " ha llegado a la meta!!!!!\n"
                + "Y se coloca en el podio en la posición: " + (ganador + 1) + "º  ");
        ganador++;//sumamos uno para que vaya aumentando en el array del podio

        return mensaje;

    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getDorsal() {
        return dorsal;
    }

    public void setDorsal(int dorsal) {
        this.dorsal = dorsal;
    }

    public void enviarPodium() {
        try {
            ObjectOutputStream oos = new ObjectOutputStream(this.cliente.getOutputStream());
            oos.writeObject(this.pod);
        } catch (IOException ex) {
        }

    }

}
