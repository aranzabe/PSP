package cliente;

import java.io.IOException;

public class ClienteEjecutable {
    public static void main(String[] args) throws IOException {
        Cliente cliente = new Cliente();
        cliente.arrancar();
    }
}
