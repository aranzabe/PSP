package cliente;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Scanner;

public class Cliente {

    private final int puerto;

    public Cliente() {
        this.puerto = 20000;
    }

    public void arrancar() throws IOException {

        Scanner teclado = new Scanner(System.in);
        InetAddress dir = InetAddress.getLocalHost();

        Socket servidor = new Socket(dir, puerto);

        int opcion, cantidad;

        // creamos el canal de entrada y salida de información sobre la opción
        DataOutputStream dosOpcion = new DataOutputStream(servidor.getOutputStream());
        DataInputStream disOpcion = new DataInputStream(servidor.getInputStream());

        // creamos el canal de entrada y salida de información sobre la cantidad
        DataOutputStream dosCantidad = new DataOutputStream(servidor.getOutputStream());
        DataInputStream disCantidad = new DataInputStream(servidor.getInputStream());
        do {

            //leemos el mensaje que nos envía el servidor, lo que nos envía en este caso, son las opciones del menú
            System.out.println(disOpcion.readUTF());
            opcion = teclado.nextInt();
            dosOpcion.writeInt(opcion);
            
            switch (opcion){
                case 1:
                    System.out.println(disCantidad.readUTF());
                    cantidad = teclado.nextInt();
                    dosCantidad.writeInt(cantidad);
                    System.out.println(disCantidad.readUTF());
                    break;
                case 2:
                    System.out.println(disCantidad.readUTF());
                    cantidad = teclado.nextInt();
                    dosCantidad.writeInt(cantidad);
                    System.out.println(disCantidad.readUTF());
                    break;
                case 3:
                    System.out.println(disCantidad.readUTF());
                    break;
                case 4:
                    System.out.println(disCantidad.readUTF());
                    break;
                    
            }

        } while (opcion != 4);

    }
}
