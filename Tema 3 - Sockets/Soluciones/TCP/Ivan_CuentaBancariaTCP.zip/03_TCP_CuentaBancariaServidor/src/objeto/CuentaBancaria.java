package objeto;

public class CuentaBancaria {

    private int dineroCuenta;

    public CuentaBancaria(int dinero) {
        this.dineroCuenta = dinero;
    }

    public int getDineroCuenta() {
        return dineroCuenta;
    }
    public void setDineroCuenta(int dineroCuenta) {
        this.dineroCuenta = dineroCuenta;
    }

    public synchronized void ingresar(int cantidad) {
        this.dineroCuenta = dineroCuenta + cantidad;
    }
    public synchronized void retirar(int cantidad) {
        this.dineroCuenta = dineroCuenta - cantidad;
    }
    public synchronized int consultarDinero() {
        return dineroCuenta;
    }
}
