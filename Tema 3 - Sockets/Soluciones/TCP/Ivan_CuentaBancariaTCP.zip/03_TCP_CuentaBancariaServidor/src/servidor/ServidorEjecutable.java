package servidor;

import objeto.CuentaBancaria;

import java.io.IOException;

public class ServidorEjecutable {
    public static void main(String[] args) throws IOException {
        CuentaBancaria cb = new CuentaBancaria(1400);
        Servidor servidor = new Servidor(cb);
        servidor.arrancar();
    }
}
