package servidor;

import objeto.CuentaBancaria;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {

    private CuentaBancaria cb = new CuentaBancaria(4300);
    private ServerSocket servidor;
    int PUERTO = 20000;
    private HiloServidor h;

    public Servidor(CuentaBancaria cb) throws IOException {
        this.cb = cb;
        this.servidor = new ServerSocket(PUERTO);
    }

    public void arrancar() throws IOException {
        System.out.println("INICIANDO EL SERVIDOR....");
        while (true) {
            Socket cliente = servidor.accept();
            h = new HiloServidor(cliente, cb);
            h.start();
        }
    }
}
