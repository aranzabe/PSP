package servidor;

import objeto.CuentaBancaria;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;

public class HiloServidor extends Thread {

    private final Socket cliente;
    private final CuentaBancaria cb;

    public HiloServidor(Socket cliente, CuentaBancaria cb) {
        this.cliente = cliente;
        this.cb = cb;
    }

    @Override
    public void run() {
        int opcion, cantidad;
        DataInputStream disOpcion, disCantidad;

        System.out.println("LLEGA EL CLIENTE --> "+cliente.getPort());

        try {

            while (cb.consultarDinero() > 0) {

                disOpcion = new DataInputStream(cliente.getInputStream());
                disCantidad = new DataInputStream(cliente.getInputStream());
                DataOutputStream dos = new DataOutputStream(cliente.getOutputStream());

                //enviamos el mensaje al cliente
                dos.writeUTF("1.INGRESAR DINERO\n2. RETIRAR DINERO\n3. CONSULTAR DINERO\n4. SALIR\nopcion --> ");
                //desde el cliente introducimos el valor de la opción
                opcion = disOpcion.readInt();
                //para asegurarnos que hemos recibido bien el valor lo vamos a imprimir en la consola del servidor
                System.out.println("("+ cliente.getPort()+ ") HA ELEGIDO LA OPCIÓN --> "+ opcion);

                //ahora, viendo la opción introducida desde el cliente, vamos  ver que opción va a elegir el cliente
                switch (opcion) {
                    case 1://INGRESO

                        dos.writeUTF("TOTAL A INGRESAR: ");
                        cantidad = disCantidad.readInt();
                        System.out.println("("+ cliente.getPort()+ ") VA A INGRESAR --> "+ cantidad+ "€");
                        cb.ingresar(cantidad);
                        dos.writeUTF("DINERO EN LA CUENTA: "+cb.consultarDinero()+ "€");
                        System.out.println("DINERO EN LA CUENTA: "+ cb.consultarDinero()+ "€");
                        dos.flush();
                        break;

                    case 2://RETIRADA

                        dos.writeUTF("TOTAL A EXTRAER: ");
                        cantidad = disCantidad.readInt();
                        if (cantidad > cb.consultarDinero()) {
                            dos.writeUTF("NO TIENES TANTO DINERO, SALDO ACTUAL --> "+ cb.consultarDinero());
                        }else{
                            System.out.println("("+ cliente.getPort()+ ") VA A RETIRAR --> "+ cantidad+ "€");
                            cb.retirar(cantidad);
                            dos.writeUTF("DINERO EN LA CUENTA: "+cb.consultarDinero()+ "€");
                            System.out.println("DINERO EN LA CUENTA: "+ cb.consultarDinero()+ "€");
                        }
                        dos.flush();
                        break;

                    case 3://CONSULTA

                        System.out.println("("+ cliente.getPort()+ ") VA A CONSULTAR LA CANTIDAD DE DINERO DE LA CUENTA");
                        System.out.println("DINERO EN LA CUENTA: "+ cb.consultarDinero()+ "€");
                        dos.writeUTF("DINERO EN LA CUENTA: "+cb.consultarDinero()+ "€");
                        dos.flush();
                        break;

                    case 4:

                        System.out.println("("+ cliente.getPort()+ ") SE VA");
                        dos.writeUTF("ADIÓS");
                        cliente.close();
                        dos.flush();
                        break;
                }
            }
        } catch (IOException ignored) {
        }
    }
}
