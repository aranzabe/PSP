package main;

import java.io.IOException;
import servidor.*;

/**
 * @author Ricardo
 */
public class Main {

    public static void main(String[] args) {

        try {
            Dispensador d = new Dispensador(50);
            Servidor s = new Servidor(d);
            s.arrancar();
        } catch (IOException ex) {
        }
    }

}
