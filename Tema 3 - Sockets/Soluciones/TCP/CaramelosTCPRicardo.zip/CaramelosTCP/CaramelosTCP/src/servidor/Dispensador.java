package servidor;

/**
 * @author Ricardo
 */
public class Dispensador {

    private int caramelo;

    public Dispensador(int caramelo) {
        this.caramelo = caramelo;
    }

    public boolean hayCaramelo() {
        boolean quedan = true;
        if (caramelo <= 0) {
            quedan = false;
        }
        return quedan;
    }

    public int mirarCaramelo() {
        return caramelo;
    }

    public synchronized int cogerCaramelo(int caramelo) {
        if (caramelo > this.caramelo) {
            caramelo = this.caramelo;
            this.caramelo = 0;
        } else {
            this.caramelo -= caramelo;
        }
        return caramelo;
    }

    public synchronized int darCaramelo(int caramelo) {
        this.caramelo += caramelo;
        return this.caramelo;
    }

}
