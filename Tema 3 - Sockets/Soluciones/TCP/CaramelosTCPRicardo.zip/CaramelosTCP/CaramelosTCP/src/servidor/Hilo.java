package servidor;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * @author Ricardo
 */
public class Hilo extends Thread {

    private Socket cliente;
    private Dispensador d;
    private PrintStream ps;
    private DataInputStream datos;
    private DataOutputStream dos;

    public Hilo(Socket cliente, Dispensador d) throws IOException {
        this.cliente = cliente;
        this.d = d;
    }

    @Override
    public void run() {
        int caramelo;
        boolean manda = false;
        try {
            System.out.println("Llega el cliente " + cliente.getPort());
            ps = new PrintStream(cliente.getOutputStream());

            while (d.hayCaramelo()) {
                manda = false;
                ps.println("Cuantos caramelos quiere? ");
                datos = new DataInputStream(cliente.getInputStream());
                caramelo = datos.read();
                System.out.println("El cliente quiere " + caramelo + " caramelos");
                d.cogerCaramelo(caramelo);
                dos = new DataOutputStream(cliente.getOutputStream());
                
                //si hay caramelos manda 1 si coge pero agota manda 2 si no quedan manda 3
                if (d.hayCaramelo()) {
                    dos.write(1);
                    System.out.println("Servidor manda 1");
                    dos.write(d.mirarCaramelo());
                } else {
                    dos.write(2);
                    System.out.println("Servidor manda 3");
                    manda = true;
                }
            }
            if (!manda) {
                dos.write(3);
                System.out.println("Servidor manda 2");
            }
            cliente.close();
        } catch (Exception e) {
        } finally {
            try {
                cliente.close();
            } catch (IOException ex) {
            }
        }

    }

}
