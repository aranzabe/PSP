package servidor;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * @author Ricardo
 */
public class Servidor {

    private Dispensador d;
    private Hilo h;
    private ServerSocket servidor;
    int PUERTO = 2000, caramelo;
    private PrintStream ps;
    private DataInputStream datos;
    private DataOutputStream dos;

    public Servidor(Dispensador d) throws IOException {
        this.d = d;
        servidor = new ServerSocket(PUERTO);
    }

    public void arrancar() throws IOException {
        System.out.println("Arranca el servidor");
        boolean manda = false, primero = true;
        try {
            do {
                Socket cliente = servidor.accept();//espera para abrir un canal
                h = new Hilo(cliente, d);
                h.start();
            } while (true);
        } catch (IOException ioe) {
            System.out.println("Error de E/S:" + ioe.getMessage());
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

    }

}
