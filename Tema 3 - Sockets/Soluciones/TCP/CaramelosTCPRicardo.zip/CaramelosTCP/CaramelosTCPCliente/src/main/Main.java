package main;
import cliente.*;
/**
 * @author Ricardo
 */
public class Main {

    public static void main(String[] args) {
        Cliente c = new Cliente();
        c.arrancar();
    }

}
