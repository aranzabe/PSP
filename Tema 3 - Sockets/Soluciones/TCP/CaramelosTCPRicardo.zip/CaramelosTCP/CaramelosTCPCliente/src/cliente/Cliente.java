package cliente;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Scanner;

/**
 * @author Ricardo
 */
public class Cliente {

    private InetAddress dir;
    private Socket servidor;
    private int puerto;
    private int caramelo;

    public Cliente() {
        puerto = 2000;
    }

    public void arrancar() {

        try {
            Scanner teclado = new Scanner(System.in);
            dir = InetAddress.getLocalHost(); // direcci�n local
            servidor = new Socket(dir, puerto);//Petici�n para el accept
            DataOutputStream dos = new DataOutputStream(servidor.getOutputStream());
            do {
                DataInputStream dis = new DataInputStream(servidor.getInputStream());
                System.out.print(dis.readLine());
                dos.write(teclado.nextInt());
                Thread.sleep(200);
                caramelo = dis.read();
                switch (caramelo) {
                    case 1:
                        System.out.print("Has cogido los caramelos, ");
                        System.out.println("Quedan " + dis.read() + " caramelos");
                        break;
                    case 2:
                        System.out.println("Has cogido todos los caramelos que quedaban");
                        break;
                    case 3:
                        System.out.println("Ya no quedan caramelos...");
                        break;
                    default:
                        break;
                }
                Thread.sleep(200);
            } while (caramelo != 2 && caramelo != 3);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            try {
                servidor.close();
            } catch (Exception e) {
            }
        }

    }

}
