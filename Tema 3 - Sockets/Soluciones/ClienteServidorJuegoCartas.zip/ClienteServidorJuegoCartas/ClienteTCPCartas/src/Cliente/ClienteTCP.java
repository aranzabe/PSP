package Cliente;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Diego
 */
public class ClienteTCP {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        InetAddress dir;
        Socket servidor;
        DataInputStream dis;
        DataOutputStream dos;
        ObjectInputStream ois;
        Ventana ventana;
        
        try {
            dir = InetAddress.getLocalHost();
            servidor = new Socket(dir, 34215);
            dis = new DataInputStream(servidor.getInputStream());
            dos = new DataOutputStream(servidor.getOutputStream());
            ois = new ObjectInputStream(servidor.getInputStream());
            ventana = new Ventana(servidor, ois, dos);
            ventana.setVisible(true);
        } catch (IOException ex) {
            Logger.getLogger(ClienteTCP.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
