/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cliente;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author fernando
 */
public class HiloCliente extends Thread {

    private Socket serv;
    private Ventana v;
    

    public HiloCliente(Socket servidor, Ventana ventana) {
        this.serv = servidor;
        this.v = ventana;
    }

    @Override
    public void run() {
        try {
            DataInputStream dis = new DataInputStream(this.serv.getInputStream());
            while(!this.v.isMePlanto()){
                boolean meToca = dis.readBoolean();
                this.v.habilitarBotonJugar();
            }
        } catch (IOException ex) {
        }
    }
    
    
    
    
    
    
}
