
package Datos;

import java.io.Serializable;

/**
 *
 * @author diego
 */
public class Carta implements Serializable{
    
    private int palo;
    private int valor;
    
    public static final String[] PALOS = {"ESPADAS", "OROS", "COPAS", "BASTOS"};
    public static final int LIMITE_CARTA_PALO = 12;
    
    public Carta (int numero, int palo){
        
        this.valor = numero;
        this.palo = palo;
        
    }

    public int getPalo() {
        return palo;
    }

    public int getValor() {
        return valor;
    }

    @Override
    public String toString() {
        return "Carta{" + "palo=" + palo + ", valor=" + valor + '}';
    }  
    
}
