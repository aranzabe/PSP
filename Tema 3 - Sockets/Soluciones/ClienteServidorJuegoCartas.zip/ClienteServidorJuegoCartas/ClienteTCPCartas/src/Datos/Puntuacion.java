
package Datos;

import java.io.Serializable;

/**
 *
 * @author diego
 */
public class Puntuacion implements Serializable{
    
    private float cantidad;
    
    public Puntuacion(){
        
        this.cantidad = 0;
        
    }
    
    public void modificarPuntuacion(int num){
        
        if (num < 10) {
            
            this.cantidad += num ;
            
        }else{
            
            this.cantidad += 0.5;
            
        }
        
    }
    
    public float devolverPuntuacion(){
        
        return this.cantidad;
        
    }
    
}
