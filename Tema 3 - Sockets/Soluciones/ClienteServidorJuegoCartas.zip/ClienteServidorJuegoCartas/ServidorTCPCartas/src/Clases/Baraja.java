package Clases;

import Datos.Carta;

/**
 *
 * @author diego
 */
public class Baraja {

    private Carta cartas[];
    private int posSiguienteCarta;
    private static int turnoJu;

    private final int NUM_CARTAS = 40;
    
    static {
        turnoJu = 1;
    }
    
    public Baraja() {

        this.cartas = new Carta[NUM_CARTAS];
        this.posSiguienteCarta = 0;
        crearBaraja();

    }

    private void crearBaraja() {

        String[] palos = Carta.PALOS;

        for (int i = 0; i < palos.length; i++) {

            for (int j = 0; j < Carta.LIMITE_CARTA_PALO; j++) {

                if (!(j == 7 || j == 8)) {
                    if (j >= 9) {

                        cartas[((i * (Carta.LIMITE_CARTA_PALO - 2)) + (j - 2))] = new Carta(j + 1, i);

                    } else {

                        cartas[((i * (Carta.LIMITE_CARTA_PALO - 2)) + j)] = new Carta(j + 1, i);

                    }

                }

            }

        }

    }

    public void barajar() {

        int posAlea = 0;
        Carta c;

        for (int i = 0; i < cartas.length; i++) {

            posAlea = (int) (Math.random() * NUM_CARTAS);

            c = cartas[i];
            cartas[i] = cartas[posAlea];
            cartas[posAlea] = c;

        }

        this.posSiguienteCarta = 0;

    }

    public synchronized Carta siguienteCarta(int turno) {

        Carta c = null;

        if (turno == turnoJu) {
            
            if (posSiguienteCarta == NUM_CARTAS) {
                System.out.println("Ya no quedan cartas");
            } else {
                c = cartas[posSiguienteCarta++];
            }
            turnoJu++;
            if (turnoJu > 2) {
                turnoJu = 1;
            }
        }

        return c;

    }

    @Override
    public String toString() {
        return "Baraja{" + "cartas=" + cartas.length + '}';
    }

}
