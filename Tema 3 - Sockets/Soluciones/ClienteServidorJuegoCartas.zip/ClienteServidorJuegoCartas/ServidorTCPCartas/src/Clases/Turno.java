package Clases;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author diego
 */
public class Turno {
    
    private int MAXJUG = 2;
    private static int turnoJugador = 1;

    public synchronized boolean cogerTestigo(int turno) {
        
        boolean meToca = false;

        if (turno == turnoJugador) {
            meToca = true;

        } else {

            try {
                wait();
            } catch (InterruptedException ex) {
                Logger.getLogger(Turno.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        return meToca;

    }

    public synchronized void dejarTestigo() {

        turnoJugador++;
        if (turnoJugador == MAXJUG + 1) {

            turnoJugador = 1;

        }

        notifyAll();

    }

}
