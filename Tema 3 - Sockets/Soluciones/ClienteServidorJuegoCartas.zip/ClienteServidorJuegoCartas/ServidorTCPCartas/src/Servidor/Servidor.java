package Servidor;

import Clases.Baraja;
import Datos.Podium;
import Clases.Turno;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author diego
 */
public class Servidor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        ServerSocket servidor;
        Socket cliente;
        Baraja barajaEsp = new Baraja();
        int cont = 0;
        int jugadores = 2;
        Hilo listaJugadores[] = new Hilo[jugadores];        
        Podium pod = new Podium(jugadores);
        Turno turno = new Turno();

        try {

            servidor = new ServerSocket(34215);
            barajaEsp.barajar();
            
            //cliente = servidor.accept();
            //Hilo hilo = new Hilo(barajaEsp, cliente, pod);
            //hilo.start();
            //hilo.join();
            //hilo.enviarPodium();
            
            while (cont < jugadores){
                
                System.out.println("Esperando...");
                cliente = servidor.accept();
                listaJugadores[cont] = new Hilo(barajaEsp, cliente, pod, (cont+1), turno);
                cont++;
                
            }
            
            for (int i = 0; i < listaJugadores.length; i++) {
                listaJugadores[i].start();
            }

            for (int i = 0; i < listaJugadores.length; i++) {
                try {
                    listaJugadores[i].join();
                } catch (InterruptedException ex) {
                }
            }

            for (int i = 0; i < listaJugadores.length; i++) {
                listaJugadores[i].enviarPodium();
            }
           

        } catch (IOException ex) {
            Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
        } 

    }

}
