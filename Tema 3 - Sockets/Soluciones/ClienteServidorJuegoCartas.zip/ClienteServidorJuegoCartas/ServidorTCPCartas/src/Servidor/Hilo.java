package Servidor;

import Clases.Baraja;
import Clases.Turno;
import Datos.Podium;
import Datos.Puntuacion;
import Datos.Carta;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author diego
 */
public class Hilo extends Thread {

    private Baraja baraja;
    private Socket cliente;
    private DataInputStream dis;
    private DataOutputStream dos;
    private ObjectOutputStream oos;
    private Carta carta;
    private Carta[] cartasJugador;
    private Puntuacion puntuacion;
    private Podium podium;
    private float puntu;
    private int turnoJu;
    private Turno turnoJugadores;
    private static int jugadores;

    public Hilo(Baraja baraja, Socket cliente, Podium pod, int turno, Turno turnoJugadores) {

        this.baraja = baraja;
        this.cliente = cliente;
        this.cartasJugador = new Carta[40];
        this.puntuacion = new Puntuacion();
        this.podium = pod;
        this.turnoJu = turno;
        this.turnoJugadores = turnoJugadores;
        jugadores = 2;

    }

    public void enviarPodium() {
        try {
            this.oos.writeObject(this.podium);

            cliente.close();
        } catch (IOException ex) {
        }

    }

    @Override
    public void run() {

        try {

            this.dis = new DataInputStream(cliente.getInputStream());
            this.dos = new DataOutputStream(cliente.getOutputStream());
            this.oos = new ObjectOutputStream(cliente.getOutputStream());
            int opcion, posi = 0, posiActu = 0;

            this.dos.writeInt(this.turnoJu);
            //this.oos.writeObject(this.turnoJugadores);

            do {

                if (jugadores == 2) {
                    boolean meToca = false;
                    while (!meToca) {
                        meToca = turnoJugadores.cogerTestigo(turnoJu);
                    }
                    this.dos.writeBoolean(true);
                } 
//                else {
//
//                    this.dos.writeBoolean(true);
//
//                }

                opcion = dis.readInt();

                switch (opcion) {

                    case 1:
                        this.carta = this.baraja.siguienteCarta(this.turnoJu);
                        this.cartasJugador[posi] = this.carta;
                        posi++;
                        this.oos.writeObject(this.carta);
                        this.puntuacion.modificarPuntuacion(this.carta.getValor());
                        //this.oos.writeObject(this.puntuacion);
                        this.puntu = this.puntuacion.devolverPuntuacion();
                        this.dos.writeFloat(puntu);
                        //this.turnoJugadores.modificarTurno();
                        break;

                }

                this.turnoJugadores.dejarTestigo();

            } while (this.puntu > 7.5 && opcion != 0);
            this.podium.addFinalizado(this.puntu, this.turnoJu);
            jugadores = 1;
            //enviarPodium();

        } catch (IOException ex) {
            Logger.getLogger(Hilo.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
