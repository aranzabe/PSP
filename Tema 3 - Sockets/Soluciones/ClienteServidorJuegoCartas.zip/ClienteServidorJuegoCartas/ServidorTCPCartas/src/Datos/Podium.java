package Datos;

import java.io.Serializable;

/**
 *
 * @author diego
 */
public class Podium implements Serializable {

    private float podio[];

    public Podium(int jugadores) {

        this.podio = new float[jugadores];

    }

    public synchronized void addFinalizado(float puntuacion, int num) {

        boolean colocado = false;

        while (!colocado) {

            this.podio[num - 1] = puntuacion;
            colocado = true;
        }
    }

    public synchronized float[] mostrarPodium() {

        return podio;
    }

}
