/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sol_examennov2020;

import Factorias.FactoriaCrucero;
import Factorias.FactoriaCuadrante;
import Imperio.Crucero;
import OtrosHilos.Aturdidor;
import OtrosHilos.Refuerzo;
import OtrosHilos.Simulacion;
import Planeta.Cuadrante;

/**
 *
 * @author fernando
 */
public class Sol_ExamenNov2020 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Simulacion sim = new Simulacion(4);
        Cuadrante c = FactoriaCuadrante.generarCuadrante();
        Crucero cru = FactoriaCrucero.generarCrucero();
        Aturdidor a1 = new Aturdidor(1, c);
        Aturdidor a2 = new Aturdidor(2, c);
        Aturdidor a3 = new Aturdidor(3, c);
        Refuerzo ref = new Refuerzo(c);

        //c.mostrarCuadrante();
        //System.out.println("");
        //cru.mostrarInfoCrucero();
        System.out.println("************* Arrancando la simulación ***************");
        sim.start();
        System.out.println("************* Enviando sondas *****************");
        cru.enviarSondasCuadrante(c);
        System.out.println("************* Enviando aturdidores ****************");
        a1.start();a2.start();a3.start();
        System.out.println("************* Esperando el final de la simulación ******************");
        cru.esperarFinInspeccion();
        System.out.println("************* Emitiendo informe ******************");
        cru.emitirInformeFinal();
        System.out.println("************* Fin de la simulación *****************");
    }

}
