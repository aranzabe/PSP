/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Imperio;

import Factorias.FactoriaSonda;
import Planeta.Cuadrante;
import java.util.LinkedList;

/**
 *
 * @author fernando
 */
public class Crucero {
    private Sonda sondas[];
    private LinkedList informes;

    public Crucero() {
//        sondas = new Sonda[20];
//        for (int i = 0; i < sondas.length; i++) {
//            sondas[i] = FactoriaSonda.generarSonda(this);
//        }
        informes = new LinkedList();
    }
    
    public void mostrarInfoCrucero(){
        for (int i = 0; i < sondas.length; i++) {
            System.out.print(sondas[i] + "||");
        }
        System.out.println("");
    }

    public void enviarSondasCuadrante(Cuadrante c) {
        for (int i = 0; i < sondas.length; i++) {
            sondas[i].lanzarCuadrante(c);
            sondas[i].start();
        }
    }

    public void emitirInformeFinal() {
        for (int i = 0; i < informes.size(); i++) {
            System.out.println(informes.get(i));
        }
    }

    public void esperarFinInspeccion() {
        for (int i = 0; i < sondas.length; i++) {
            try {
                sondas[i].join();
            } catch (InterruptedException ex) {
            }
        }
    }
    
    public void addInforme(Informe inf){
        this.informes.add(inf);
    }

    public void setSondas(Sonda[] sondas) {
        this.sondas = sondas;
    }
    
}
