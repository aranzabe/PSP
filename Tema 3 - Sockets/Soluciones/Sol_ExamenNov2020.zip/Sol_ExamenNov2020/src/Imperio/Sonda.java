/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Imperio;

import OtrosHilos.Simulacion;
import Planeta.Cuadrante;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author fernando
 */
public class Sonda extends Thread {

    private int id;
    private String tipoSonda;
    private Cuadrante c;
    private Crucero cru;

//    public Sonda(Crucero cru) {
////        id = (int) (Math.random() * 100);
////        int alea = (int) (Math.random() * 2);
////        if (alea == 0) {
////            tipoSonda = "t";
////        } else {
////            tipoSonda = "b";
////        }
////        this.cru = cru; //Crucero al que pertenece para enviarle informes.
//          
//    }

    public Sonda() {
    }

    @Override
    public void run() {
        while (!Simulacion.simulacionFinalizada()) {
            try {
                this.c.accederCuadrante();
                System.out.println("Sonda " + this.id + " accediendo al cuadrante");
                Informe inf = c.accederSectorAleatorio(id, tipoSonda);
                if (inf != null) {
                    System.out.println(inf + " enviado al crucero.");
                    this.cru.addInforme(inf);
                }
                this.c.salirCuadrante();
                Thread.currentThread().sleep(1000);
            } catch (InterruptedException ex) {
            }
        }

    }

    public String getTipoSonda() {
        return tipoSonda;
    }

    @Override
    public String toString() {
        return "Sonda{" + "id=" + id + ", tipoSonda=" + tipoSonda + '}';
    }

    public void lanzarCuadrante(Cuadrante c) {
        this.c = c;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setTipoSonda(String tipoSonda) {
        this.tipoSonda = tipoSonda;
    }

    public void setC(Cuadrante c) {
        this.c = c;
    }

    public void setCru(Crucero cru) {
        this.cru = cru;
    }

    
    
}
