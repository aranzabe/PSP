/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Imperio;

/**
 *
 * @author fernando
 */
public class Informe {
    private int[] posicion;
    private String descripcion;

    public Informe() {
        posicion = new int[2]; //Posición del sector del informe.
        descripcion = "";
    }
    
    public void addInforme(int f, int c, String desc){
        posicion[0] = f;
        posicion[1] = c;
        this.descripcion = desc;
    }
    
    public void mostrarInforme(){
        System.out.println("Sector: " + this.posicion[0] + ", " + this.posicion[1]);
        System.out.println(this.descripcion);
    }

    @Override
    public String toString() {
        return "Informe{" + "posicion=" + posicion[0] + ", " + posicion[1] + "  descripcion='" + descripcion + "'}";
    }
    
    
}
