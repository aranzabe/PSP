/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OtrosHilos;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author fernando
 */
public class Simulacion extends Thread {
    private int tiempo;
    private int tiempoFinal;
    private static boolean finalSimulacion;

    public Simulacion(int tiempoFinal) {
        this.tiempoFinal = tiempoFinal;
        finalSimulacion = false;
    }

    @Override
    public void run() {
        tiempo = 1;
        while(tiempo <= tiempoFinal){
            try {
                Thread.currentThread().sleep(1000);
            } catch (InterruptedException ex) {
            }
            tiempo++;
        }
        finalSimulacion = true;
    }
    
    public static boolean simulacionFinalizada(){
        return finalSimulacion;
    }
    
    
    
}
