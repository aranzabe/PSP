/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OtrosHilos;

import Planeta.Cuadrante;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author fernando
 */
public class Refuerzo extends Thread {

    private Cuadrante c;

    public Refuerzo(Cuadrante c) {
        this.c = c;
    }

    @Override
    public void run() {
        while(!Simulacion.simulacionFinalizada()){
            try {
                Thread.currentThread().sleep(10000); //Cada 10 segundos llegan refuerzos.
                System.out.println("--- Reforzando las tropas ---");
                this.c.reforzarTropas();
            } catch (InterruptedException ex) {
            }
        }
    }
    
    

}
