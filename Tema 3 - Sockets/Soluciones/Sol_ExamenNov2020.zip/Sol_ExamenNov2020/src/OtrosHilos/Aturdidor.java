/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OtrosHilos;

import Planeta.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author fernando
 */
public class Aturdidor extends Thread {

    private int ide;
    private Cuadrante c;

    public Aturdidor(int ide, Cuadrante c) {
        this.ide = ide;
        this.c = c;
    }

    @Override
    public void run() {
        int fil, col;
        while (!Simulacion.simulacionFinalizada()) {
            try {
                do {
                    fil = (int) (Math.random() * c.filasCuadrante());
                    col = (int) (Math.random() * c.colsCuadrante());
                } while (!c.aturdirCuadrante(fil, col));
                Thread.currentThread().sleep(20000); //Se queda 20 segundos en el sector
                c.liberarAturdidorCuadrante(fil, col);
            } catch (InterruptedException ex) {
            }

        }
    }

}
