/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Planeta;

/**
 *
 * @author fernando
 */
public class Tropa {

    private int cod;
    private String capitan;
    private int numTropas;

    public Tropa() {
//        cod = (int) (Math.random() * 1000);
//        int alea = (int) (Math.random() * 3);
//        switch (alea) {
//            case 0:
//                capitan = "Luke";
//                break;
//            case 1:
//                capitan = "Leia";
//                break;
//            case 2:
//                capitan = "Obiwan";
//        }
//        numTropas = (int) (Math.random() * 100);
    }

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public String getCapitan() {
        return capitan;
    }

    public void setCapitan(String capitan) {
        this.capitan = capitan;
    }

    public int getNumTropas() {
        return numTropas;
    }

    public void setNumTropas(int numTropas) {
        this.numTropas = numTropas;
    }

    @Override
    public String toString() {
        return "Tropa{" + "cod=" + cod + ", capitan=" + capitan + ", numTropas=" + numTropas + "}  ";
    }

}
