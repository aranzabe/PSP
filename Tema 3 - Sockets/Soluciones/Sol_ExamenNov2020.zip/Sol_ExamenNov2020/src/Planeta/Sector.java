/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Planeta;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author fernando
 */
public class Sector {

    private Base b;
    private Tropa t;
    private boolean sectorOcupado;
    private boolean ocupadoPorAturdidor;

    public Sector() {
//        int alea = (int) (Math.random() * 2);
//        if (alea == 0) {
//            b = new Base();
//        }
//        alea = (int) (Math.random() * 3);
//        if (alea == 0) {
//            t = new Tropa();
//        }
//        sectorOcupado = false;
    }

    public Base getB() {
        return b;
    }

    public Tropa getT() {
        return t;
    }

    @Override
    public String toString() {
        String dev = "Sector: [";
        if (b != null) {
            dev += b;
        }
        if (t != null) {
            dev += t;
        }
        return dev + "]";
    }

    public synchronized boolean accederSector() {
        boolean accesoConcedido = false;
        if (ocupadoPorAturdidor) {
            try {
                System.out.println("Sonda aturdida.");
                wait();
            } catch (InterruptedException ex) {
            }
        } else {
            if (this.sectorOcupado) {
                try {
                    wait();
                } catch (InterruptedException ex) {
                }
            } else {
                this.sectorOcupado = true;
                accesoConcedido = true;
            }
        }
        return accesoConcedido;
    }

    public synchronized void salirSector() {
        this.sectorOcupado = false;
        notifyAll();
    }

    public synchronized boolean aturdirSector() {
        if (!ocupadoPorAturdidor){
            ocupadoPorAturdidor = true;
        }
        return ocupadoPorAturdidor;
    }

    public synchronized void liberarAturdirSector() {
        this.ocupadoPorAturdidor = false;
        notifyAll();
    }

    public void setB(Base b) {
        this.b = b;
    }

    public void setT(Tropa t) {
        this.t = t;
    }

    public void setSectorOcupado(boolean sectorOcupado) {
        this.sectorOcupado = sectorOcupado;
    }

    
    
}
