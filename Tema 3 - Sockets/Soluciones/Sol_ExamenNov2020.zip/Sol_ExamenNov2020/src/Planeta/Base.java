/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Planeta;

/**
 *
 * @author fernando
 */
public class Base {

    private int cod;
    private String descripcion;
    private String tipo;

    public Base() {
//        cod = (int) (Math.random() * 1000);
//        descripcion = "Base";
//        int alea = (int) (Math.random() * 3);
//        switch (alea) {
//            case 0:
//                tipo = "Militar";
//                break;
//            case 1:
//                tipo = "Médica";
//                break;
//            case 2:
//                tipo = "Científica";
//        }
    }

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Base{" + "cod=" + cod + ", descripcion=" + descripcion + ", tipo=" + tipo + "}  ";
    }

}
