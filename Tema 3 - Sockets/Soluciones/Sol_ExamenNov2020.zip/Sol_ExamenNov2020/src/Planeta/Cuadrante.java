/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Planeta;

import Factorias.FactoriaPlaneta;
import Imperio.Informe;
import OtrosHilos.Aturdidor;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author fernando
 */
public class Cuadrante {

    private Sector sectores[][];
    private Semaphore semCuadrante;

    public Cuadrante() {
//        sectores = new Sector[4][4];
//        for (int i = 0; i < sectores.length; i++) {
//            for (int j = 0; j < sectores[i].length; j++) {
//                sectores[i][j] = FactoriaPlaneta.generaSector();
//            }
//        }
        semCuadrante = new Semaphore(10);
    }

    public void mostrarCuadrante() {
        for (int i = 0; i < sectores.length; i++) {
            for (int j = 0; j < sectores[i].length; j++) {
                System.out.print(i + "," + j + ": " + sectores[i][j] + "|");
            }
            System.out.println("");
        }
    }

    public void accederCuadrante() {
        try {
            semCuadrante.acquire();
        } catch (InterruptedException ex) {
        }
    }

    public void salirCuadrante() {
        semCuadrante.release();
    }

    public Informe accederSectorAleatorio(int id, String tipoSonda) {
        Informe inf = null;
        int f = (int) (Math.random() * this.sectores.length);
        int c = (int) (Math.random() * this.sectores[0].length);
        boolean acceso = false;
        while (!acceso) {
            acceso = this.sectores[f][c].accederSector();
        }
        System.out.println("Sonda: " + id + " accediendo al sector [" + f + ", " + c + "]");
        if (tipoSonda.equals("t") && this.sectores[f][c].getT() != null) {
            inf = new Informe();
            inf.addInforme(f, c, "Tropa encontrada: " + this.sectores[f][c].getT().toString());
        }
        if (tipoSonda.equals("b") && this.sectores[f][c].getB() != null) {
            inf = new Informe();
            inf.addInforme(f, c, "Base encontrada: " + this.sectores[f][c].getB().toString());
        }
        System.out.println("Sonda: " + id + " saliendo del sector [" + f + ", " + c + "]");
        this.sectores[f][c].salirSector();
        return inf;
    }

    public int filasCuadrante() {
        return this.sectores.length;
    }

    public int colsCuadrante() {
        return this.sectores[0].length;
    }

    public boolean aturdirCuadrante(int fil, int col) {
        boolean aturdido = this.sectores[fil][col].aturdirSector();
        if (aturdido) {
            System.out.println("Aturdiendo el sector: " + fil + ", " + col);
        }
        return aturdido;
    }

    public void liberarAturdidorCuadrante(int fil, int col) {
        System.out.println("Liberando el sector " + fil + ", " + col + " del aturdidor.");
        this.sectores[fil][col].liberarAturdirSector();
    }

    public void reforzarTropas() {
        for (int i = 0; i < this.sectores.length; i++) {
            for (int j = 0; j < this.sectores[0].length; j++) {
                if (this.sectores[i][j].getT()!=null){
                    Tropa t = this.sectores[i][j].getT();
                    t.setNumTropas((int) (t.getNumTropas() * 1.05));  //Se refuerza con el 5%.
                }
            }
        }
    }

   
    public void setSectores(Sector[][] sectores) {
        this.sectores = sectores;
    }
}