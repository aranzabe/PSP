/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Factorias;

import Imperio.Crucero;
import Imperio.Sonda;

/**
 *
 * @author fernando
 */
public class FactoriaSonda {
    public static Sonda generarSonda(Crucero c){
        Sonda s = new Sonda();
        s.setId((int) (Math.random() * 100));
        int alea = (int) (Math.random() * 2);
        if (alea == 0) {
            s.setTipoSonda("t");
        } else {
            s.setTipoSonda("b");
        }
        s.setCru(c);
        return s;
    }
}
