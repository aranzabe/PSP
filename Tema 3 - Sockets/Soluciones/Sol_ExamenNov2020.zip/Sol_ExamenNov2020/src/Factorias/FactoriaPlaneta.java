/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Factorias;

import Planeta.Base;
import Planeta.Sector;
import Planeta.Tropa;

/**
 *
 * @author fernando
 */
public class FactoriaPlaneta {

    public static Sector generaSector() {
        Sector s = new Sector();
        int alea = (int) (Math.random() * 2);
        if (alea == 0) {
            s.setB(FactoriaPlaneta.generaBase());
        }
        alea = (int) (Math.random() * 3);
        if (alea == 0) {
            s.setT(FactoriaPlaneta.generaTropa());
        }
        
        s.setSectorOcupado(false);
        return s;
    }
    
    public static Base generaBase(){
        Base b = new Base();
        b.setCod((int) (Math.random() * 1000));
        b.setDescripcion("Base");
        int alea = (int) (Math.random() * 3);
        switch (alea) {
            case 0:
                b.setTipo("Militar");
                break;
            case 1:
                b.setTipo("Médica");
                break;
            case 2:
                b.setTipo("Científica");
        }
        return b;
    }
    
    public static Tropa generaTropa(){
        Tropa t = new Tropa();
        t.setCod((int) (Math.random() * 1000));
        int alea = (int) (Math.random() * 3);
        switch (alea) {
            case 0:
                t.setCapitan("Luke");
                break;
            case 1:
                t.setCapitan("Leia");
                break;
            case 2:
                t.setCapitan("Obiwan");
        }
        t.setNumTropas((int) (Math.random() * 100));
        return t;
    }
    
    
}
