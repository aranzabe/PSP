/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Factorias;

import Planeta.Cuadrante;
import Planeta.Sector;

/**
 *
 * @author fernando
 */
public class FactoriaCuadrante {
    
    public static Cuadrante generarCuadrante(){
        Cuadrante cu = new Cuadrante();
        Sector sectores[][] = new Sector[4][4];
        for (int i = 0; i < sectores.length; i++) {
            for (int j = 0; j < sectores[i].length; j++) {
                sectores[i][j] = FactoriaPlaneta.generaSector();
            }
        }
        cu.setSectores(sectores);
        return cu;
    }
}
