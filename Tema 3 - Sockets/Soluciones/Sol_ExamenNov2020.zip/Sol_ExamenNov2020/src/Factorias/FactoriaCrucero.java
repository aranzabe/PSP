/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Factorias;

import Imperio.Crucero;
import Imperio.Sonda;

/**
 *
 * @author fernando
 */
public class FactoriaCrucero {

    public static Crucero generarCrucero() {
        Crucero cru = new Crucero();
        Sonda sondas[] = new Sonda[20];
        for (int i = 0; i < sondas.length; i++) {
            sondas[i] = FactoriaSonda.generarSonda(cru);
        }
        cru.setSondas(sondas);
        return cru;
    }
    
}
