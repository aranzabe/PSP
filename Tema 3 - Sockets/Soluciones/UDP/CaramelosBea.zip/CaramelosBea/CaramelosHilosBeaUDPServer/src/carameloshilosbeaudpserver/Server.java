/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carameloshilosbeaudpserver;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

/**
 *
 * @author Usuario
 */
public class Server {
    public void Ejecuta_Servidor() {
        
        try {
            byte[] buffer = new byte[256];
            DatagramSocket s = new DatagramSocket(1050); // puerto de eco
            DatagramPacket p;

            System.out.println("Comienza la ejecucion del servidor ...");
            while (Caramelos.getCaramelos()> 0) {
                
                p = new DatagramPacket(buffer, 256);
                s.receive(p); //espero un datagrama, se queda esperando hasta que llega un datagrama.
                Hilo hilo = new Hilo(p);
                hilo.start();
                
                
            }
        } catch (SocketException e) {
            System.out.println(e.toString());
        } catch (IOException e) {
            System.out.println(e.toString());
        }
    }

}
