/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carameloshilosbeaudpserver;

/**
 *
 * @author Usuario
 */
public class Caramelos {

    public static int caramelos = 100;

    public static int getCaramelos() {
        return caramelos;
    }

    public static void setCaramelos(int caramelos) {
        Caramelos.caramelos = caramelos;
    }

}
