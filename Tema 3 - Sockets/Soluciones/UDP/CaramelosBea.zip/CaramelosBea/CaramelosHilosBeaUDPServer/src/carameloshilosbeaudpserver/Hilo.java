/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carameloshilosbeaudpserver;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.logging.Level;
import java.util.logging.Logger;
import static jdk.nashorn.internal.objects.ArrayBufferView.buffer;

/**
 *
 * @author Usuario
 */
public class Hilo extends Thread {

    private byte[] buffer = new byte[256];
    private byte[] buffer2 = new byte[256];
    private DatagramSocket s;
    private DatagramPacket p;
    private DatagramPacket p2;
    private int puerto, longitud;
    private InetAddress dir;
    private String mensaje;

    public Hilo(DatagramPacket p) {
        this.p = p;
        try {
            s = new DatagramSocket();
        } catch (SocketException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void run() {
        try {
            boolean primeraVez = true;
            int numCaramelos;
            do {
                if (!primeraVez) {
                    s.receive(p);
                }
                else {
                    primeraVez = false;
                }

                buffer = p.getData(); //obtengo datos
                puerto = p.getPort(); //obtengo puerto origen
                dir = p.getAddress(); //obtengo dir IP
                longitud = p.getLength(); //longitud del mensaje
                mensaje = new String(buffer, 0, longitud); //texto del mensaje

                numCaramelos = Integer.parseInt(mensaje);
                if (numCaramelos > 0) {
                    if (Caramelos.getCaramelos() > 0 && Caramelos.getCaramelos() >= numCaramelos) {
                        mensaje = "Aquí tienes tus " + numCaramelos + " caramelos";
                        cogerCaramelos(numCaramelos);
                    } else {
                        if (Caramelos.getCaramelos() <= 0) {
                            mensaje = "No quedan caramelos";
                        } else {
                            mensaje = (Caramelos.getCaramelos() + "Has pedido demasiados caramelos" + numCaramelos);
                        }
                    }
                } else {
                    mensaje = "Adios";
                }
                //Lanzo acuse de recibo
                // lo convierte a vector de bytes
                buffer2 = mensaje.getBytes();
                //ahora construyo el paquete, especifico destino
                //Ahora creamos el datagrama que será enviado por el socket 's'.
                p2 = new DatagramPacket(buffer2, mensaje.length(), dir, puerto);
                System.out.println("Lanzamos al cliente " + dir.getHostAddress() + " una confirmación.");
                s.send(p2); //envio datagrama
                System.out.println("Me quedan " + Caramelos.getCaramelos() + " caramelos");

            } while (numCaramelos > 0 && Caramelos.getCaramelos() > 0);

        } catch (IOException ex) {
            Logger.getLogger(Hilo.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("Soy el hilo " + this.getName() + " he terminado de atender.");
    }

    public synchronized void cogerCaramelos(int n) {
        Caramelos.setCaramelos((Caramelos.getCaramelos() - n));

    }
}
