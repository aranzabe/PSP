/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Personas;

import java.io.Serializable;

/**
 *
 * @author faranzabe
 */
public class Clase_Ejemplo implements Serializable { //La clase que vamos a enviar por el socket tendremos que
                                                     //serializarla, por lo tanto tenemos que porner este implements.
    
    private String cad;
    private int n;
    
    public Clase_Ejemplo(){
        cad="hola";
        n=9;
    }

    @Override
    public String toString() {
        return "Clase_Ejemplo{" + "cad=" + cad + ", n=" + n + '}';
    }
    
    
    
    public void mostrar(){
        System.out.println("Cadena: " + cad);
        System.out.println("Número: " + n);
    }
}