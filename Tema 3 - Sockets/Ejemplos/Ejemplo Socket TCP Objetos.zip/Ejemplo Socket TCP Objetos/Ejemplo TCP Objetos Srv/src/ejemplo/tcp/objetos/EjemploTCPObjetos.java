/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo.tcp.objetos;
import Personas.Clase_Ejemplo;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
/**
 *
 * @author faranzabe
 */
public class EjemploTCPObjetos {

/**
 *
 * @author fernando
 */

  
    public static void main(String[] args) throws IOException {
        // Se crea un socket servidor atendiendo a un determinado puerto.
            // Por ejemplo, el 35557.
            ServerSocket socket = new ServerSocket (35557);
            Socket cliente = null;
            boolean salir=false;
            
            while(!salir){
            // Se acepata una conexion con un cliente. Esta llamada se queda
            // bloqueada hasta que se arranque el cliente.
            System.out.println ("Esperando cliente");
            cliente = socket.accept();

            System.out.println ("Conectado con cliente de " + cliente.getInetAddress());
            // setSoLinger() a true hace que el cierre del socket espere a que
            // el cliente lea los datos, hasta un máximo de 10 segundos de espera.
            // Si no ponemos esto, el socket se cierra inmediatamente y si el 
            // cliente no ha tenido tiempo de leerlos, los datos se pierden.
            //cliente.setSoLinger (true, 10);
            
            // Se prepara un flujo de salida para objetos y un objeto para enviar*/
            Clase_Ejemplo dato = new Clase_Ejemplo();
            ObjectOutputStream bufferObjetos = new ObjectOutputStream (cliente.getOutputStream());
            
            // Se envia el objeto 
            bufferObjetos.writeObject(dato);
                System.out.println ("Enviado '" + dato.toString()+"'");
            }
            
            // Se cierra el socket con el cliente.
            // La llamada anterior a setSoLinger() hará
            // que estos cierres esperen a que el cliente retire los datos.
            cliente.close();
            
            // Se cierra el socket encargado de aceptar clientes. Ya no
            // queremos más.
            socket.close();
    }
}