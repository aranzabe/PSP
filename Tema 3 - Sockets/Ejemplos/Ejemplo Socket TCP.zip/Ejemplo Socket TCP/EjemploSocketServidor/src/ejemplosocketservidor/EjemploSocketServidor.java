package ejemplosocketservidor;

// servidor
import java.io.*;
import java.net.*;

public class EjemploSocketServidor {


public static void main(String argv[])
{
    ServerSocket servidor;
    Socket cliente;
    int numCliente = 0;
    int PUERTO = 5000;
    
    System.out.println("Servidor arrancado");
   
    try {
        servidor = new ServerSocket(PUERTO);
    do {
        System.out.println("Esperando...");
        cliente = servidor.accept();
        numCliente++;
        System.out.println("Llega el cliente "+numCliente);
        
        //Si queremos escribir cadenas en el socket, es aconsejable usar PrintStream.
        PrintStream ps = new PrintStream(cliente.getOutputStream());
        ps.println("Usted es mi cliente "+numCliente);
        ps.println("Otra cosa");
        //Si queremos escribir valores con formato en el socket, es aconsejable usar DataOutputStream.
        //DataOutputStream ps = new DataOutputStream(cliente.getOutputStream());
        //ps.writeUTF("Usted es mi cliente "+numCliente);
        
        cliente.close();
    } while (true);
    }
        catch (Exception e)
    {
        e.printStackTrace();
    }
}
}
