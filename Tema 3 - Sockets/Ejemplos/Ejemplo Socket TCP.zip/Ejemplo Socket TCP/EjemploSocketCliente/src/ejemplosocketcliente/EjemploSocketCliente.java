package ejemplosocketcliente;

// cliente:
import java.io.*;
import java.net.*;

public class EjemploSocketCliente {


    public static void main(String argv[])
    {
        InetAddress direccion;
        Socket servidor;
        int numCliente = 0;
        int PUERTO = 5000;

        try {
            direccion = InetAddress.getLocalHost(); // dirección local
            servidor = new Socket(direccion, PUERTO);//Petición para el accept
            DataInputStream datos = new DataInputStream(servidor.getInputStream());
            System.out.println(datos.readLine());
            System.out.println(datos.readLine());
            servidor.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}
