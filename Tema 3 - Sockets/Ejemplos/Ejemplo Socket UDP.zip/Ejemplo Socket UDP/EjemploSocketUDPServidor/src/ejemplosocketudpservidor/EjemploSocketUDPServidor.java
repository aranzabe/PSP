/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ejemplosocketudpservidor;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

/**
 *
 * @author fernando
 */
public class EjemploSocketUDPServidor {
        public void Ejecuta_Servidor(){
        try{ 
             
            byte[] buffer=new byte[256], buffer2=new byte[256];
            DatagramSocket s=new DatagramSocket(1050); // puerto de eco
            DatagramPacket p, p2;
            int puerto,longitud;
            InetAddress dir;
            String mensaje;
        
        
            System.out.println("Comienza la ejecucion del servidor ...");
            while (true) {
                p=new DatagramPacket(buffer,256);
                s.receive(p); //espero un datagrama, se queda esperando hasta que llega un datagrama.
                buffer=p.getData(); //obtengo datos
                puerto=p.getPort(); //obtengo puerto origen
                dir=p.getAddress(); //obtengo dir IP
                longitud=p.getLength(); //longitud del mensaje
                mensaje=new String(buffer,0,longitud); //texto del mensaje
                System.out.println("Eco recibido:"+dir+":"+puerto+" > "+mensaje);
                
                //Lanzo acuse de recibo
                mensaje="Mensaje recibido";
                // lo convierte a vector de bytes
                buffer2= mensaje.getBytes();
                //ahora construyo el paquete, especifico destino
                //Ahora creamos el datagrama que será enviado por el socket 's'.
                p2=new DatagramPacket(buffer2, mensaje.length(), dir, puerto);
                //DatagramPacket p=new DatagramPacket(buffer, mensaje.length(), InetAddress.getByAddress(buffer), 1050);
                //DatagramPacket p=new DatagramPacket(buffer, mensaje.length(), InetAddress.getByName("192.168.1.10"), 1050);
                //DatagramPacket p=new DatagramPacket(buffer, mensaje.length(), InetAddress.getByName("fernando-Toshiba"),1050);
                System.out.println("Lanzamos al cliente " + dir.getHostAddress() + " una confirmación.");
                s.send(p2); //envio datagrama
            }
        }
            catch(SocketException e) {System.out.println(e.toString());}
            catch(IOException e) {System.out.println(e.toString());}
        }    
    
}
