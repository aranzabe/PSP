/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ejemplosocketudpcliente;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

/**
 *
 * @author fernando
 */
public class EjemploSocketUDPCliente {

    public void Ejecuta_cliente() throws SocketException, IOException, UnknownHostException {//en este método hemos optado por no tratar las excepciones
        String mensaje;
        BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));

        //puerto origen del socket: el que encuentre libre.
        DatagramSocket s=new DatagramSocket();
        DatagramPacket p,p2;
        byte []buffer2 = new byte[256];
        
        System.out.println("Puerto de origen reservado por el cliente: " + s.getLocalPort());
        do {
            System.out.print("Dame una cadena para mandar al servidor: ");
            mensaje=teclado.readLine();
            // lo convierte a vector de bytes
            byte[] buffer= mensaje.getBytes();
            //ahora construyo el paquete, especifico destino
            //Ahora creamos el datagrama que será enviado por el socket 's'.
            p=new DatagramPacket(buffer, mensaje.length(), InetAddress.getLocalHost(), 1050);
            //p=new DatagramPacket(buffer, mensaje.length(), InetAddress.getByName("172.17.203.34"), 1050);
           // p=new DatagramPacket(buffer, mensaje.length(), InetAddress.getByName("172.17.209.120"), 1050);
            //p=new DatagramPacket(buffer, mensaje.length(), InetAddress.getByName("fernando-Toshiba"),1050);
            s.send(p); //envio datagrama

            //Acuse de recibo
            int puerto,longitud;
            InetAddress dir;
            p2=new DatagramPacket(buffer2,256);
            s.receive(p2);
            buffer2=p2.getData(); //obtengo datos
            puerto=p2.getPort(); //obtengo puerto origen
            dir=p2.getAddress(); //obtengo dir IP
            longitud=p2.getLength(); //longitud del mensaje
            mensaje=new String(buffer2,0,longitud); //texto del mensaje
            System.out.println("El servidor:"+dir+":"+puerto+" >  ha confirmado el mensaje anterior con el mensaje: "+ mensaje);
        } while (mensaje != null);
    }
    
}
