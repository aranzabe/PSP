/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package camellosudpserver;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Usuario
 */
public class Hilo extends Thread {

    private String nombre;
    private int dorsal;

    private static int ganador = 0;
    public static int podio[] = new int[4];
    private DatagramPacket p;
    private DatagramSocket s;
    private int puerto;
    private InetAddress dir;

    public Hilo(int dorsal, DatagramPacket p) {

        this.dorsal = dorsal;
        this.p = p;
        int longitud;
        String mensaje;
        byte[] buffer = new byte[2048];

        try {
            s = new DatagramSocket();
            buffer = p.getData();
            this.puerto = p.getPort();
            this.dir = p.getAddress();
            longitud = p.getLength();
            mensaje = new String(buffer, 0, longitud);
            this.setNombre(mensaje);
            DatagramPacket paquete2;

            //Mandamos un saludo al jugador y le avisamos de que la carrera va a dar comienzo
            mensaje = "Hola " + this.getNombre() + " con dorsal: " + this.getDorsal() + " va a comenzar la carrera... YA!!!!";
            buffer = mensaje.getBytes();
            paquete2 = new DatagramPacket(buffer, mensaje.length(), this.dir, this.puerto);
            System.out.println("Lanzamos al cliente " + dir.getHostAddress() + " una confirmación.");
            s.send(paquete2);
        } catch (SocketException ex) {
            System.out.println(ex.getMessage());
        } catch (IOException ex) {
            Logger.getLogger(Hilo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getDorsal() {
        return dorsal;
    }

    public void setDorsal(int dorsal) {
        this.dorsal = dorsal;
    }

    public static int getGanador() {
        return ganador;
    }

    public static void setGanador(int ganador) {
        Hilo.ganador = ganador;
    }

    @Override
    public void run() {

        try {
            int avance;
            int pos = 0;
            int longitud;
            String mensaje;
            byte[] buffer = new byte[2048];
            DatagramPacket paquete2;
            boolean primeraVez = true;
            boolean continuar = true;

            while (continuar) {
                if (primeraVez) {
                    buffer = p.getData();
                    this.puerto = p.getPort();
                    this.dir = p.getAddress();
                    longitud = p.getLength();
                    mensaje = new String(buffer, 0, longitud);
                    this.setNombre(mensaje);
                    primeraVez = false;

                    //Mandamos un saludo al jugador y le avisamos de que la carrera va a dar comienzo
                    mensaje = "Hola " + this.getNombre() + " con dorsal: " + this.getDorsal() + " va a comenzar la carrera... YA!!!!";
                    buffer = mensaje.getBytes();
                    paquete2 = new DatagramPacket(buffer, mensaje.length(), this.dir, this.puerto);
                    System.out.println("Lanzamos al cliente " + dir.getHostAddress() + " una confirmación.");
                    s.send(paquete2);
                }

                //Creamos el porcentaje 
                avance = (int) Math.floor(Math.random() * 100 + 1);

                if (avance < 40) {//Si el avance es menor a 40 
                    if (pos < 3) {//y la posicion menor a 3
                        pos++;//aumentamos posicion

                        mensaje = (this.getNombre() + " en posicion: " + pos);

                        buffer = mensaje.getBytes();
                        paquete2 = new DatagramPacket(buffer, mensaje.length(), this.dir, this.puerto);
                        System.out.println("Lanzamos al cliente " + dir.getHostAddress() + " una confirmación.");
                        s.send(paquete2);

                    }
                }
                if (avance < 30) {//Si el avance es menor a 30
                    if (pos < 7) {//Y la posicion menor a 7
                        pos++;//aumentamos posicion

                        mensaje = (this.getNombre() + " en posicion: " + pos);

                        buffer = mensaje.getBytes();
                        paquete2 = new DatagramPacket(buffer, mensaje.length(), this.dir, this.puerto);
                        System.out.println("Lanzamos al cliente " + dir.getHostAddress() + " una confirmación.");
                        s.send(paquete2);

                    }
                }
                if (avance < 20) {//Si el avance es menor a 20
                    if (pos < 9) {//y la posicion menor a 9
                        pos++;//aumentamos posicion

                        mensaje = (this.getNombre() + " en posicion: " + pos);

                        buffer = mensaje.getBytes();
                        paquete2 = new DatagramPacket(buffer, mensaje.length(), this.dir, this.puerto);
                        System.out.println("Lanzamos al cliente " + dir.getHostAddress() + " una confirmación.");
                        s.send(paquete2);

                    }
                }
                if (avance < 10) {//Si el avance es menor a 10
                    if (pos < 10) {//Y la posicion menor a 10

                        pos++;//Aumentamos posicion

                        mensaje = (this.getNombre() + " en posicion: " + pos);

                        buffer = mensaje.getBytes();
                        paquete2 = new DatagramPacket(buffer, mensaje.length(), this.dir, this.puerto);
                        System.out.println("Lanzamos al cliente " + dir.getHostAddress() + " una confirmación.");
                        s.send(paquete2);

                    }
                    if (pos == 10) {
                        mensaje = podio();
                        continuar = false;
                        buffer = mensaje.getBytes();
                        paquete2 = new DatagramPacket(buffer, mensaje.length(), this.dir, this.puerto);
                        System.out.println("Lanzamos al cliente " + dir.getHostAddress() + " una confirmación.");
                        s.send(paquete2);

                        mensaje = "Fin !!!!!";
                        buffer = mensaje.getBytes();
                        paquete2 = new DatagramPacket(buffer, mensaje.length(), this.dir, this.puerto);
                        System.out.println("Lanzamos al cliente " + dir.getHostAddress() + " una confirmación.");
                        s.send(paquete2);

                    }
                }

                Thread.sleep(1000);

            }

        } catch (IOException ex) {
            Logger.getLogger(Hilo.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InterruptedException ex) {
            Logger.getLogger(Hilo.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private synchronized String podio() {
        podio[ganador] = this.getDorsal();//Asignamos el camello en su posicion del podio
        String mensaje = ("\n" + this.getNombre() + " con dorsal: " + this.getDorsal() + " ha llegado a la meta!!!!!\n"
                + "Y se coloca en el podio en la posición: " + (ganador + 1) + "º  ");
        ganador++;//sumamos uno para que vaya aumentando en el array del podio

        return mensaje;

    }
}
