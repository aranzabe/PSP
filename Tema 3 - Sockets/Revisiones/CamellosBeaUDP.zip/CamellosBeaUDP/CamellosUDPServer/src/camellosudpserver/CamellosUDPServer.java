/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package camellosudpserver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Usuario
 */
public class CamellosUDPServer {

    public static int camellos = 0;
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
         try {
           
            byte[] buffer = new byte[2048];
            DatagramSocket s = new DatagramSocket(1050); // puerto de eco
            DatagramPacket p;
            int cantCamellos = 4;

            
            System.out.println("Va a comenzar la carrera de Camellos...");
            
            Hilo camello[] = new Hilo[cantCamellos];
            
            while (camellos < cantCamellos) {
                
                //RECIBO EL NOMBRE DEL JUGADOR
                p = new DatagramPacket(buffer, 2048);
                s.receive(p); //espero un datagrama, se queda esperando hasta que llega un datagrama.
                

                camello[camellos] = new Hilo(camellos, p);
                
                camellos++;
                
            }
            
            if(camellos == cantCamellos){//CUANDO YA ESTAN TODOS LOS JUGADORES ARRANCAMOS LA CARRERA
                for (int i = 0; i < camello.length; i++) {
                    camello[i].start();
                }
            }
        } catch (SocketException e) {
            System.out.println(e.toString());
        } catch (IOException e) {
            System.out.println(e.toString());
        }
    
    }
    
}
