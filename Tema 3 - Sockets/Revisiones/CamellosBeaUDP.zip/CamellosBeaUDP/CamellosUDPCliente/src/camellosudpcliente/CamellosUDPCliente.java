/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package camellosudpcliente;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Usuario
 */
public class CamellosUDPCliente {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        
         try {
            DatagramSocket socket = new DatagramSocket();
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            DatagramPacket paquete; 
            byte[] buffer = new byte[2048]; 
            String mensaje; 
            int longitud, puerto;
            InetAddress dir;
            boolean primeraVez = true;
            
                    
            do{
                if (primeraVez) {//Si este bloque lo hacemos en el constructor no hace falta aquí.
                    System.out.println("¿Cuál es tú nombre?");
                    mensaje = br.readLine(); 
                    buffer = mensaje.getBytes();
                    paquete = new DatagramPacket(buffer,mensaje.length(), InetAddress.getLocalHost(),1050);
                    socket.send(paquete);
                    primeraVez = false;
                }
                
            
                //Recibimos mensaje 
                buffer = new byte[2048];
                paquete = new DatagramPacket(buffer,2048);
                socket.receive(paquete);
                buffer = paquete.getData();
                puerto = paquete.getPort();
                dir = paquete.getAddress();
                longitud = paquete.getLength();
                mensaje = new String(buffer,0,longitud);
                System.out.println(mensaje);
            
            
            }while(!mensaje.equals("Fin !!!!!")) ;
            
        } catch (SocketException ex) {
           
        }
    
    }
    
}
