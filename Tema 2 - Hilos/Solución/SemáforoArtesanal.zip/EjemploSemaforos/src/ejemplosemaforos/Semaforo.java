/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplosemaforos;

/**
 *
 * @author faranzabe
 */
public class Semaforo {

    private int num;

    public Semaforo(int num) {
        this.num = num;
    }

    public synchronized void adquirir() throws InterruptedException {
        boolean adquirido = false;
        while (!adquirido) {
            if (num > 0) {
                num--;
                adquirido = true;
            } else {
                wait();
            }
        }   
    }

    public synchronized void liberar() {
        num++;
        notifyAll();
    }

    public synchronized boolean intentarAdquirir() {
        if (num > 0) {
            num--;
            return true;
        } else {
            return false;
        }
    }
}
