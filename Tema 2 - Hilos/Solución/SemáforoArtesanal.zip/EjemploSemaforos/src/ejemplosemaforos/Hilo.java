/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplosemaforos;

import java.util.concurrent.Semaphore;

/**
 *
 * @author fernando
 */
public class Hilo extends Thread {

    //Opción a)
    private static Semaphore sem = new Semaphore(2);
    private static Semaforo semArtesano = new Semaforo(1);
    //O también
    //Opción b)
    //private Semaphore sem;

    public Hilo() {

    }

//    @Override private Semaphore sem;
//
//    public Hilo(Semaphore sem) {
//        this.sem = sem;
//    }
    public void run() {
        int espera = 0;

        try {
            semArtesano.adquirir();
            //sem.acquire();
            //if (sem.tryAcquire()) {
            //if (semArtesano.intentarAdquirir()){
            //if (sem.tryAcquire(10, TimeUnit.SECONDS)){
            System.out.println("Semáforo adquirido por " + this.getName());
            espera = (int) (Math.random() * 2000 + 500);
            System.out.println(this.getName() + " esperando " + espera);
            System.out.println("Semáforo liberado por " + this.getName());
            sleep(espera);
            semArtesano.liberar();
            //sem.release();
//                } else {
//                    System.out.println("No lo pillo " + this.getName());
//                }
            espera = (int) (Math.random() * 500);
            sleep(espera);

        } catch (InterruptedException ex) {
        }

    }

}
