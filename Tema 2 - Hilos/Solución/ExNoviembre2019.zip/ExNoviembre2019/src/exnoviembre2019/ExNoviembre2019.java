/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exnoviembre2019;

import Clases.Civilizacion;
import Clases.Edificio;
import Clases.Reponedor;

/**
 *
 * @author fernando
 */
public class ExNoviembre2019 {

    public static Civilizacion esp = new Civilizacion("Españoles");
    public static Civilizacion vik = new Civilizacion("Vikingos");
    public static Edificio mina = new Edificio(10, 7, "Oro", 2000);
    public static Edificio carpinteria = new Edificio(16, 9, "Madera", 2500);
    public static boolean finalSimulacion = false;
    public static boolean estamosEnGuerra = false;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int tiempoBatalla = 5;
        int t = 1;
        Reponedor r = new Reponedor();

        esp.start();
        vik.start();

        r.start();

        while (esp.getVictorias() != 5 && vik.getVictorias() != 5 && t <= 10) {

            if (t % tiempoBatalla == 0) {
                int alea = (int) (Math.random() * 2);
                HiloBatalla hb = null;
                if (alea == 0) {
                    hb = new HiloBatalla(mina);
                } else {
                    hb = new HiloBatalla(carpinteria);
                }
                hb.start();
            }
            //Espera un segundo.
            try {
                Thread.currentThread().sleep(1000);
            } catch (InterruptedException ex) {
            }
            t++;
        }
        
        finalSimulacion = true; //Para parar los hilos que están pendientes de esta bandera.
        
        System.out.println("Todo ha finalizado.");
        System.out.println("Estado final de las civilizaciones.");
        esp.mostrarInfo();
        vik.mostrarInfo();
    }
}
