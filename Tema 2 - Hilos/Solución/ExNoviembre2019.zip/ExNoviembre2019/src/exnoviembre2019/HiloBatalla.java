/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exnoviembre2019;

import Clases.Edificio;

/**
 *
 * @author fernando
 */
class HiloBatalla extends Thread {

    private Edificio ed;

    public HiloBatalla(Edificio ed) {
        this.ed = ed;
    }

    @Override
    public void run() {

        System.out.println("Ha estallado un conflicto en: " + ed);
        ExNoviembre2019.esp.setEdEnGuerra(ed);
        ExNoviembre2019.vik.setEdEnGuerra(ed);
        ExNoviembre2019.estamosEnGuerra=true;
        
        /*
        Falta por realizar el rellenado del edificio en guerra con caballeros y 
        después ver qué pasa en la batalla, sumando victorias a la civilziación que gana
        y eliminando de aldeanos el edificio de la que pierde.
        */
        
        ExNoviembre2019.esp.setEdEnGuerra(null);
        ExNoviembre2019.vik.setEdEnGuerra(null);
        ExNoviembre2019.estamosEnGuerra=false;
    }

}
