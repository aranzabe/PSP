/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import Personajes.*;
import java.util.concurrent.Semaphore;

/**
 *
 * @author fernando
 */
public class Edificio {

    protected Aldeano aldeanos[];
    protected Caballero caballeros[];
    protected String desc;
    protected int items;
    //protected Semaphore sa;
    protected static MonitorAldeanos accesosAldeanos; //Lo he realizado con un monitor para que tengáis un ejemplo de cada uno.
    protected static Semaphore sc;

    public Edificio() {
        desc = "";
    }
    
    static {
        accesosAldeanos = new MonitorAldeanos(10);
        sc = new Semaphore(6);
        //sa = new Semaphore(aldeanos.length);
    }

    public Edificio(int tamAldeanos, int tamCaballeros, String desc, int it) {
        aldeanos = new Aldeano[tamAldeanos];
        caballeros = new Caballero[tamCaballeros];
        this.desc = desc;
        this.items = it;
    }

    public void addAldeano(Aldeano a) {
        accesosAldeanos.acceder();
        int i = 0;
        boolean colocado = false;
        while (i < aldeanos.length && !colocado) {
            if (aldeanos[i] == null) {
                aldeanos[i] = a;
                colocado = true;
            }
            i++;
        }
    }

    public void eliminarAldeanos(Civilizacion c) {
        for (int i = 0; i < aldeanos.length; i++) {
            if (aldeanos[i].getC().getDesc().equals(c.getDesc())) {
                accesosAldeanos.liberar();
            }
        }
    }

    public boolean addCaballero(Caballero c) {
        boolean conseguido = false;
        if (sc.tryAcquire()) {
            conseguido = true;
            int i = 0;
            boolean colocado = false;
            while (i < caballeros.length && !colocado) {
                if (caballeros[i] == null) {
                    caballeros[i] = c;
                    colocado = true;
                }
                i++;
            }
        }
        return conseguido;
    }

    public void mostrarInfo() {
        System.out.println("Descripción del edificio: " + this.desc);
        System.out.println("Items que tiene: " + this.items);
        System.out.println("Aldeanos trabajando actualmente.");
        for (int i = 0; i < this.aldeanos.length; i++) {
            System.out.println(this.aldeanos[i]);
        }
    }


    public synchronized boolean caballerosLleno() {
        boolean todoLleno = true;
        int i = 0;
        while (i < this.caballeros.length && todoLleno) {
            if (this.caballeros[i] == null) {
                todoLleno = false;
            }
            i++;
        }
        return todoLleno;
    }

    public int resultadoLucha() {
        int ataqueEsp = 0;
        int ataqueVik = 0;
        int resultado = 0;

        for (int i = 0; i < this.caballeros.length; i++) {
            if (this.caballeros[i].getC().getDesc().equals("Españoles")) {
                ataqueEsp += this.caballeros[i].getAtaque();
            }
            if (this.caballeros[i].getC().getDesc().equals("Vikingos")) {
                ataqueVik += this.caballeros[i].getAtaque();
            }
        }
        if (ataqueEsp > ataqueVik) {
            resultado = 1;
        }
        if (ataqueEsp < ataqueVik) {
            resultado = 2;
        }
        return resultado;
    }

    @Override
    public String toString() {
        return "Edificio{" + "desc=" + desc + ", items=" + items + '}';
    }

    public void salirCaballeroEdificio() {
        sc.release();
    }

    public void setItems(int items) {
        this.items = items;
    }

    public int getItems() {
        return items;
    }

    public void despertarTodos() {
        accesosAldeanos.liberar();
    }
    
    

}
