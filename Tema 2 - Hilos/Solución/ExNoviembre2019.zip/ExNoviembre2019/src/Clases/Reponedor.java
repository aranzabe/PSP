/*
 * 
 */
package Clases;

import exnoviembre2019.ExNoviembre2019;


/**
 *
 * @author fernando
 */
public class Reponedor extends Thread {

    @Override
    public void run() {
        while(!ExNoviembre2019.finalSimulacion){
            try {
                Thread.sleep(20000);
                System.out.println("El hilo reponedor rellena los edificios.");
                exnoviembre2019.ExNoviembre2019.carpinteria.setItems(2500);
                exnoviembre2019.ExNoviembre2019.mina.setItems(2000);
            } catch (InterruptedException ex) {
            }
            
        }
    }
    
    
}
