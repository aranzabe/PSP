/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import Personajes.*;
import exnoviembre2019.ExNoviembre2019;

/**
 *
 * @author fernando
 */
public class Civilizacion extends Thread {

    private int oro;
    private int madera;
    private Aldeano alds[];
    private Caballero cabs[];
    private String desc;
    private int victorias;
    private boolean estoyEnGuerra;
    private Edificio edEnGuerra;

    public Civilizacion() {
        this.oro = 0;
        this.madera = 0;
        this.victorias = 0;
        this.estoyEnGuerra = false;
    }

    public Civilizacion(String d) {
        this.oro = 0;
        this.madera = 0;
        this.desc = d;
        this.victorias = 0;
        this.estoyEnGuerra = false;
    }

    private void iniciarAldeanos() {
        alds = new Aldeano[50];
        for (int i = 0; i < alds.length; i++) {
            alds[i] = new Aldeano((int) (Math.random() * 10) + 1, (int) (Math.random() * 50) + 1, this);
            alds[i].start();
        }
    }

    private void iniciarCaballeros(Edificio ed) {
        cabs = new Caballero[100];
        System.out.println("INICIANDO CABs");
        for (int i = 0; i < cabs.length; i++) {
            cabs[i] = new Caballero((int) (Math.random() * 30) + 30, (int) (Math.random() * 30) + 20, this, ed);
            cabs[i].start();
        }
    }

    public int getOro() {
        return oro;
    }

    public void setOro(int oro) {
        this.oro = oro;
    }

    public int getMadera() {
        return madera;
    }

    public void setMadera(int madera) {
        this.madera = madera;
    }

    public String getDesc() {
        return desc;
    }

    public void mostrarInfo() {
        System.out.println("--------------------------------");
        System.out.println(this.desc);
        System.out.println("Oro recogido: " + this.oro);
        System.out.println("Madera recogida: " + this.madera);
        System.out.println("Victorias: " + this.victorias);
        for (int i = 0; i < alds.length; i++) {
            System.out.println(alds[i]);
        }
        System.out.println("--------------------------------");
    }

    public int getVictorias() {
        return victorias;
    }

    public void setVictorias(int victorias) {
        this.victorias = victorias;
    }

    @Override
    public void run() {
        this.iniciarAldeanos();
        boolean tropasEnviadas = false;

        while (!ExNoviembre2019.finalSimulacion) {
            if (ExNoviembre2019.estamosEnGuerra && !tropasEnviadas) {
               /*
                Falta por hacer.
                */
            }
        }
    }

    public synchronized void addOro(int capacidad) {
        this.oro += capacidad;
        ExNoviembre2019.mina.setItems(ExNoviembre2019.mina.getItems() - capacidad);
    }

    public synchronized void addMadera(int capacidad) {
        this.madera += capacidad;
        ExNoviembre2019.carpinteria.setItems(ExNoviembre2019.carpinteria.getItems() - capacidad);
    }

    public boolean isEstoyEnGuerra() {
        return estoyEnGuerra;
    }

    public void setEstoyEnGuerra(boolean estoyEnGuerra) {
        this.estoyEnGuerra = estoyEnGuerra;
    }

    public Edificio getEdEnGuerra() {
        return edEnGuerra;
    }

    public void setEdEnGuerra(Edificio edEnGuerra) {
        this.edEnGuerra = edEnGuerra;
    }

}
