/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Personajes;


/**
 *
 * @author fernando
 */
public class MonitorAldeanos {
    private int accesosAldeanosMax;

    public MonitorAldeanos(int accesosAldeanosMax) {
        this.accesosAldeanosMax = accesosAldeanosMax;
    }
    

    public synchronized void acceder() {
        if (accesosAldeanosMax>0){
            accesosAldeanosMax--;
        }
        else {
            try {
                wait(); //El aldeano que no consigue acceder se quedará en wait.
            } catch (InterruptedException ex) {
            }
        }
    }

    public synchronized void liberar() {
        accesosAldeanosMax++;
        notifyAll();
    }
    
    
}
