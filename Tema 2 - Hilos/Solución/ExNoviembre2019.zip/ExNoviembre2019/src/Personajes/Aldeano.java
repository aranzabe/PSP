/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Personajes;

import Clases.Civilizacion;
import exnoviembre2019.ExNoviembre2019;

/**
 *
 * @author fernando
 */
public class Aldeano extends Personaje implements Runnable {

    private int capacidad;
    private Thread hilo;
    private static int turnoGeneral = 1;
    private int miTurno;

    public Aldeano() {
    }

    public Aldeano(int capacidad, int vida, Civilizacion c) {
        super(vida, c);
        this.capacidad = capacidad;
        hilo = new Thread(this);
        this.miTurno = turnoGeneral;
        turnoGeneral++;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    @Override
    public String toString() {
        return "Aldeano{" + "capacidad=" + capacidad + super.toString();
    }

    @Override
    public void run() {
        while (!ExNoviembre2019.finalSimulacion) {
            int alea = (int) (Math.random() * 2);
            if (alea == 0 && !ExNoviembre2019.finalSimulacion) {
                ExNoviembre2019.carpinteria.addAldeano(this);
                System.out.println(this + " trabajando en la mina.");
                this.c.addOro(this.capacidad);
                try {
                    Thread.currentThread().sleep(1000);
                } catch (InterruptedException ex) {
                }
            }
            if (alea == 1 && !ExNoviembre2019.finalSimulacion) {
                ExNoviembre2019.mina.addAldeano(this);
                System.out.println(this + " trabajando en la carpintería.");
                this.c.addMadera(this.capacidad);
                try {
                    Thread.currentThread().sleep(1000);
                } catch (InterruptedException ex) {
                }
            }
        }
        ExNoviembre2019.carpinteria.despertarTodos();
        ExNoviembre2019.mina.despertarTodos();
    }

    public void start() {
        this.hilo.start();
    }

}
