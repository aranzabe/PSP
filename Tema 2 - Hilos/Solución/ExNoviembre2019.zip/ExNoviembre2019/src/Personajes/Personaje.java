/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Personajes;

import Clases.Civilizacion;

/**
 *
 * @author fernando
 */
public class Personaje {

    protected int vida;
    protected Civilizacion c;

    public Personaje(int vida, Civilizacion c) {
        this.vida = vida;
        this.c = c;
    }

    public Personaje() {
    }

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    public Civilizacion getC() {
        return c;
    }

    public void setC(Civilizacion c) {
        this.c = c;
    }

    @Override
    public String toString() {
        return " vida=" + vida + " " + this.c.getDesc() + '}';
    }

}
