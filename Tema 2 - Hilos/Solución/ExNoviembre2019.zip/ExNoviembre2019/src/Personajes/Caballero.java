/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Personajes;

import Clases.Civilizacion;
import Clases.Edificio;
import exnoviembre2019.ExNoviembre2019;

/**
 *
 * @author fernando
 */
public class Caballero extends Personaje implements Runnable {

    private int ataque;
    private Thread hilo;
    private Edificio ed;

    public Caballero() {
    }

    public Caballero(int ataque, int vida, Civilizacion c) {
        super(vida, c);
        this.ataque = ataque;
        hilo = new Thread(this);
    }

    public Caballero(int ataque, int vida, Civilizacion c, Edificio ed) {
        super(vida, c);
        this.ataque = ataque;
        hilo = new Thread(this);
        this.ed = ed;
    }

    public int getAtaque() {
        return ataque;
    }

    public void setAtaque(int ataque) {
        this.ataque = ataque;
    }

    @Override
    public String toString() {
        return "Caballero{" + "ataque=" + ataque + super.toString();
    }

    @Override
    public void run() {
        
    }

    public void start() {
        this.hilo.start();
    }

}
