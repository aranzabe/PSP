/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es;

import java.util.ArrayList;
import java.util.concurrent.Semaphore;
import javax.swing.JOptionPane;

/**
 *
 * @author jorge
 */
public class Parking extends Thread {

    private Planta[] plantas;
    private Semaphore plazas;
    private ArrayList<Coche> coches;
    private frmEntornoGrafico entorno;

    public Parking(int plantas, int filas, int columnas) {
        int suma = 0;
        this.plantas = new Planta[plantas];
        for (int i = 0; i < plantas; i++) {
            this.plantas[i] = new Planta((i + 1), filas, columnas);
            suma += (filas * columnas);
        }
        this.plazas = new Semaphore(suma);
        this.coches = new ArrayList<>();
        this.entorno = new frmEntornoGrafico(filas * columnas);
        this.entorno.show();

    }

    
  
    public boolean intentaEntrar(){
        return this.plazas.tryAcquire();
    }

    @Override
    public void run() {
        try {
            int i = 0, timer = 0;
            boolean error = false;
            Coche c;
            while (!error && !finApp(timer, 60)) {
                if ((int) (Math.random() * 100) <= 1) {
                    System.out.println("*********************************************************");
                    System.out.println("HA OCURRIDO UN ERROR EN EL PARKING Y NO SE ADMITIRA LA\nENTRADA DE MAS COCHES, SIN EMBARGO PUEDEN ABANDONAR EL \nGARAJE LOS QUE YA SE ENCUENTRAN DENTRO");
                    System.out.println("*********************************************************");
                            JOptionPane.showMessageDialog(null, "HA OCURRIDO UN ERROR\nQUEDA CERRADO EL ACCESO AL PARKING","ADVERTENCIA", JOptionPane.INFORMATION_MESSAGE);
                    error = true;
                } else {
                    c = new Coche(this);
                    c.start();
                    coches.add(c);
                    sleep(1000);
                }
                timer++;
                if (finApp(timer, 60)) {
                    System.out.println("\n***************************************");
                    System.out.println("Tiempo agotado, No entrarán mas coches.");
                    System.out.println("***************************************\n");
                    JOptionPane.showMessageDialog(null, "TIEMPO AGOTADO\nNO ENTRARÁN MAS COCHES.", "ADVERTENCIA", JOptionPane.INFORMATION_MESSAGE);
                }
            }
            for (Coche coche : coches) {
                coche.join();
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public boolean finApp(int timer, double segundos) {
        return !(timer < segundos);
    }

    public frmEntornoGrafico getEntorno() {
        return entorno;
    }

    boolean intentarAparcarEnPlanta(int i) {
        return this.plantas[i].intentarEntrarEnPlanta();
    }

    int cantPlantas() {
        return this.plantas.length;
    }

    void salirPlanta() {
        this.plazas.release();
    }

    void salirParking() {
        this.plazas.release();
    }

}
