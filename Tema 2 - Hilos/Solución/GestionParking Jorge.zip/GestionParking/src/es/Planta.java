/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es;

import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author jorge
 */
public class Planta {

    //private Semaphore plazasLibres;
    int cantPlazas;

    public Planta(int numero, int filas, int columnas) {
        //this.plazasLibres = new Semaphore(filas * columnas);
        this.cantPlazas = filas * columnas;
    }

    synchronized boolean intentarEntrarEnPlanta() {
        boolean conseguido=false;
        if (cantPlazas==0){
            try {
                wait();
            } catch (InterruptedException ex) {
                Logger.getLogger(Planta.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else {
            this.cantPlazas--;
        }
        return conseguido;
        //return plazasLibres.tryAcquire();
    }

    
}
