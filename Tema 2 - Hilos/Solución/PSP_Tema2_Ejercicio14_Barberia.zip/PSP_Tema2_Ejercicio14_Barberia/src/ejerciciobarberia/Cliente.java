package ejerciciobarberia;

import java.util.concurrent.Semaphore;

/**
 *
 * @author ivanc
 */
public class Cliente extends Thread {

    // dentro de la barbería hay 4 asientos de espera solo
    private static final Semaphore asientosLibres = new Semaphore(4);
    private static final Semaphore barberos = new Semaphore(2);

    public Cliente(String name) {
        super(name);
    }

    @Override
    public void run() {
        //Barberos barberos = new Barberos(this.getName());
        int espera;
        try {
            if (asientosLibres.tryAcquire()) {
                barberos.acquire();
                System.out.println(this.getName() + " HA COGIDO ASIENTO EN LA BARBERÍA.");
                espera = (int) (Math.random() * 5000 + 2000);
                sleep(espera);
                //barberos.join(); versión COVID-19 aforo máximo de 4 CLIENTES XD
                System.out.println(this.getName() + " VA A CORTARSE EL PELO.");
                barberos.release();
                espera = (int) (Math.random() * 500);
                sleep(espera);
                asientosLibres.release();
            }
            else {
                System.out.println("El cliente " + Thread.currentThread().getName() + " se va sin entrar");
            }
        } catch (InterruptedException ie) {
        }
    }
}
