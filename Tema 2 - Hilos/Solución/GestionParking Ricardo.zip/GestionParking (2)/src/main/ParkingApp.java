package main;

import parking.Parking;
import static java.lang.Thread.sleep;
import java.util.ArrayList;
import vehiculo.Coche;

/**
 * @author Ricardo
 */
public class ParkingApp {

    public static void main(String[] args) throws InterruptedException {
        Parking p = new Parking(3);
        int time = 0;
        ArrayList<Coche> coche = new ArrayList<>();
        Coche c;

        while (!p.cierra() && time <= 30) {
                c = new Coche(p);
                coche.add(c);
                c.start();
            sleep(1000);
            time++;
        }
        //espera a todos los coches salgan
        for (Coche coche1 : coche) {
            coche1.join();
        }
        System.out.println("Numero total de coches en circulacion: "+coche.size());
    }

}
