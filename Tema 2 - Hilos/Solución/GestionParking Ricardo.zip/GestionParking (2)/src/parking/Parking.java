package parking;

/**
 * @author Ricardo
 */
public class Parking {

    private Planta[] plantas;
    private int error;

    public Parking(int noPlantas) {
        error = 1;
        plantas = new Planta[noPlantas];
        for (int i = 0; i < plantas.length; i++) {
            plantas[i] = new Planta(i);
        }
    }

    /**
     * Ir� de planta en planta intentando buscar una plaza
     *
     * @param matricula
     */
    public void entrarParking(int matricula) {
        boolean ocupaPlaza = false;
        for (int i = 0; i < plantas.length && !ocupaPlaza; i++) {
            ocupaPlaza = plantas[i].entraCoche(matricula);
        }
        if (!ocupaPlaza) {
            System.out.println("El coche de matricula " + matricula + " no ha encontrado sitio, igual que viene se va");
        }
    }

    /**
     * Ir� de planta en planta buscando si coincide matricula
     *
     * @param matricula
     */
    public void salirParking(int matricula) {
        boolean salePlaza = false;
        for (int i = 0; i < plantas.length && !salePlaza; i++) {
            salePlaza = plantas[i].saleCoche(matricula);
        }
    }

    /**
     * Si el porcentaje de error es menor que el numero dado de forma aleatoria
     *
     * @return devuelve si se cierra el parking o no
     */
    public boolean cierra() {

        if (error > (int) (Math.random() * 100)) {
            System.out.println("");
            System.out.println("HA OCURRIDO UN INCONVENIENTE, EL PARKING DEBE CERRAR");
            return true;
        }
        return false;
    }
}
