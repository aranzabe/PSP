package parking;

/**
 * @author Ricardo
 */
public class Planta {

    private int[][] apar;
    private int noPlanta;

    public Planta(int noPlanta) {
        this.noPlanta = noPlanta;
        this.apar = new int[2][2];
    }

    /**
     * Si hay alg�n lugar vac�o(0) entonces ocupa la plaza, lo har�n de forma
     * sincronizada
     *
     * @param matricula numero de matricula del coche
     * @return devuelve si el coche ha ocupado un sitio o no
     */
    public synchronized boolean entraCoche(int matricula) {

        boolean ocupaPlaza = false;
        for (int i = 0; i < apar.length && !ocupaPlaza; i++) {
            for (int j = 0; j < apar[0].length && !ocupaPlaza; j++) {
                if (apar[i][j] == 0) {
                    apar[i][j] = matricula;
                    ocupaPlaza = true;
                    System.out.println("El coche de matricula " + matricula + " APARCA en P" + noPlanta + "(" + i + "-" + j + ")");
                }
            }
        }
        return ocupaPlaza;
    }

    /**
     * Si la matricula es igual que la dada por parametro sale del aparcamiento
     *
     * @param matricula numero de matricula del coche
     * @return devuelve si un coche ha salido o no
     */
    public boolean saleCoche(int matricula) {
        boolean salePlaza = false;
        for (int i = 0; i < apar.length && !salePlaza; i++) {
            for (int j = 0; j < apar[0].length && !salePlaza; j++) {
                if (apar[i][j] == matricula) {
                    apar[i][j] = 0;
                    salePlaza = true;
                    System.out.println("El coche de matricula " + matricula + " SALE de P" + noPlanta + "(" + i + "-" + j + ")");
                }
            }
        }
        return salePlaza;
    }

}
