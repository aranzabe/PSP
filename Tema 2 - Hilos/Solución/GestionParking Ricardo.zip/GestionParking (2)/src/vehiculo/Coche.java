package vehiculo;
import parking.*;

/**
 * @author Ricardo
 */
public class Coche extends Thread {

    private int matricula;
    private Parking p;
    

    public Coche(Parking p) {
        this.p = p;
        this.matricula = ((int) (Math.random() * (9999 - 1000 + 1) + 1000));
    }

    @Override
    public void run() {
       p.entrarParking(this.matricula);
       //espera un tiempo entre 10 y 15s
       int espera = (int) (Math.random() * (15000-10000+1) + 10000);
        try {
            sleep(espera);
        } catch (InterruptedException ex) {
        }
       p.salirParking(matricula);
    }

    @Override
    public String toString() {
        return "matricula: "+matricula+" "; 
    }
    
    

}
