/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carreradecamellos;

/**
 *
 * @author ivanc
 */
public class CarreraCamellosApp {
    
    public static void main(String[] args) {
    
        System.out.println("\t***********************************************************");
        System.out.println("\t\t************CARRERA DE CAMELLOS************");
        System.out.println("\t***********************************************************");
        System.out.println();
        
        Hilo camello1 = new Hilo ("CAMELLO #32");
        
        Hilo camello2 = new Hilo ("CAMELLO #66");
        
        Hilo camello3 = new Hilo ("CAMELLO #20");
        
        Hilo camello4 = new Hilo ("CAMELLO #51");
        
        camello1.run();
        camello2.run();
        camello3.run();
        camello4.run();
        
        System.out.println("\t***********************************************************");
        System.out.println("\t\t************CARRERA DE CAMELLOS************");
        System.out.println("\t***********************************************************");
        
    }
    
}
