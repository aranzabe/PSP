/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carreradecamellos;

/**
 *
 * @author ivanc
 */
public class Hilo extends Thread{

    private int numAle;
    
    public Hilo(String nombreCamello) {
        super(nombreCamello);
    }

    public int recorreCasillas (int numAle, String dorsalCamello){
        int posicionCamello;
        
        if (numAle <= 100 && numAle >=90){
            System.out.println("\t\t\t" + dorsalCamello + " ha avanzado 1 CASILLA");
            posicionCamello = 1;
        }else{
            if (numAle < 90 && numAle >=80){
                System.out.println("\t\t\t" + dorsalCamello + " ha avanzado 2 CASILLAS");
                posicionCamello = 2;
            }else{
                if (numAle < 80 && numAle >=70){
                    System.out.println("\t\t\t" + dorsalCamello + " ha avanzado 3 CASILLAS");
                    posicionCamello = 3;
                }else{
                    if (numAle < 70 && numAle >=60){
                        System.out.println("\t\t\t" + dorsalCamello + " ha avanzado 4 CASILLAS");
                        posicionCamello = 4;
                    }else{
                        if (numAle < 60 && numAle >=50){
                            System.out.println("\t\t\t" + dorsalCamello + " ha avanzado 5 CASILLAS");
                            posicionCamello = 5;
                        }else{
                            if (numAle < 50 && numAle >=40){
                                System.out.println("\t\t\t" + dorsalCamello + " ha avanzado 6 CASILLAS");
                                posicionCamello = 6;
                            }else{
                                if (numAle < 40 && numAle >=30){
                                    System.out.println("\t\t\t" + dorsalCamello + " ha avanzado 7 CASILLAS");
                                    posicionCamello = 7;
                                }else{
                                    if (numAle < 30 && numAle >=20){
                                        System.out.println("\t\t\t" + dorsalCamello + " ha avanzado 8 CASILLAS");
                                        posicionCamello = 8;
                                    }else{
                                        if (numAle < 20 && numAle >=10){
                                            System.out.println("\t\t\t" + dorsalCamello + " ha avanzado 9 CASILLAS");
                                            posicionCamello = 9;
                                        }else{
                                            System.out.println("\t\t\t" + dorsalCamello + " ha avanzado 10 CASILLAS");
                                            posicionCamello = 10;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        
        return posicionCamello;
    }
    
    public void muestraTotalRecorrido (int totalCasillas){
        switch (this.getName()){
            case "CAMELLO #32":
                System.out.println("\t\t" + this.getName() + " ha recorrido un total de "+ totalCasillas + " casillas");
                break;
            case "CAMELLO #66":
                System.out.println("\t\t" + this.getName() + " ha recorrido un total de "+ totalCasillas + " casillas");
                break;
            case "CAMELLO #20":
                System.out.println("\t\t" + this.getName() + " ha recorrido un total de "+ totalCasillas + " casillas");
                break;
            case "CAMELLO #51":
                System.out.println("\t\t" + this.getName() + " ha recorrido un total de "+ totalCasillas + " casillas");
                break;
         }
    }
    
    @Override
    public void run() {
        int totalCamello= 0;
        int casillasCamello = 0;
        Podio podio;
        try {
            for (int i = 1; i < 10; i++) {
                numAle = (int) (Math.random() * 100);
                switch (this.getName()){
                    case "CAMELLO #32":
                        casillasCamello = 0;
                        casillasCamello += recorreCasillas(numAle, this.getName());
                        break;
                    case "CAMELLO #66":
                        casillasCamello = 0;
                        casillasCamello += recorreCasillas(numAle, this.getName());
                        break;
                    case "CAMELLO #20":
                        casillasCamello = 0;
                        casillasCamello += recorreCasillas(numAle, this.getName());
                        break;
                    case "CAMELLO #51":
                        casillasCamello = 0;
                        casillasCamello += recorreCasillas(numAle, this.getName());
                        break;
                }
                
                totalCamello += casillasCamello;
                
            }
            
            System.out.println();
            
            muestraTotalRecorrido(totalCamello);
            
            if (totalCamello >= 50){
                System.out.println("\t\t       " + this.getName().toUpperCase() + " ha finalizado la carrera");
            }else{
                System.out.println("\t\t    " + this.getName().toUpperCase() + " no ha finalizado la carrera");
            }
            
            
            
            System.out.println();
            Thread.sleep(750);
        } catch (InterruptedException ex) {
        }
        
    }    
}
