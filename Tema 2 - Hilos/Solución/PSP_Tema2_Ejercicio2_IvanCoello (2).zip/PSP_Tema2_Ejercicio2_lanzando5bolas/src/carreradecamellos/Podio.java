/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carreradecamellos;

/**
 *
 * @author ivanc
 */
public class Podio {
    
    //-----------------------------ATRIBUTOS------------------------------------
    private String nombreDorsalCamello;
    private int totalCasillas;
    //--------------------------------------------------------------------------
    
    //---------------------------CONSTRUCTORES----------------------------------
    public Podio(String nombreDorsalCamello, int totalCasillas) {
        this.nombreDorsalCamello = nombreDorsalCamello;
        this.totalCasillas = totalCasillas;
    }
    //--------------------------------------------------------------------------
    
    //--------------------------GETTERS Y SETTERS-------------------------------
    public String getNombreDorsalCamello() {
        return nombreDorsalCamello;
    }
    public void setNombreDorsalCamello(String nombreDorsalCamello) {
        this.nombreDorsalCamello = nombreDorsalCamello;
    }

    public int getTotalCasillas() {
        return totalCasillas;
    }
    public void setTotalCasillas(int totalCasillas) {
        this.totalCasillas = totalCasillas;
    }
    //--------------------------------------------------------------------------

}
