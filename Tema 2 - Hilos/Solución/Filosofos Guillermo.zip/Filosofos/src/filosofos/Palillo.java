
package filosofos;

import java.util.concurrent.Semaphore;

/**
 *
 * @author Guille
 */
public class Palillo {
    
    private Semaphore sem = new Semaphore(1);
    
    public void coger() throws InterruptedException{
        sem.acquire();   
    }
   
    public void dejar(){
        sem.release();
    }
    
    public boolean intentarCoger(){
        return sem.tryAcquire();
    }
}
