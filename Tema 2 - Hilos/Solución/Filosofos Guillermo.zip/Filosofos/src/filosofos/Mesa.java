
package filosofos;

import java.util.ArrayList;

/**
 *
 * @author Guille
 */
public class Mesa {
    
    private ArrayList<Palillo> palillos = new ArrayList<>();
    private ArrayList<Filosofo> filosofos = new ArrayList<>();

    public Mesa(int num) {
        
        //creo los palillos necesarios para los filosofos
        for (int i = 0; i < num; i++) {
            Palillo p = new Palillo();
            palillos.add(p);
        }
        
        //asigno cuales serán los palillos de cada filosofo
        //y creo los filosofos
        for (int i = 0; i < num; i++) {
            int aux = i+1;
            if (i == num-1) {
                aux = 0;
            }
            Palillo izq = palillos.get(i);
            Palillo der = palillos.get(aux);
            aux++;
            
            Filosofo f = new Filosofo(""+i,this,izq,der);
            filosofos.add(f);
            f.start();
        }
    }    
}
