
package filosofos;

import java.util.Random;

/**
 *
 * @author Guille
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Mesa mesa = new Mesa(5);
    }
 
    
    
    public static int generarNumAleatorio(int inf, int sup){
         
        Random aleatorio = new Random();
        return (inf+aleatorio.nextInt( (sup+1) - inf));     
    }
    
}
