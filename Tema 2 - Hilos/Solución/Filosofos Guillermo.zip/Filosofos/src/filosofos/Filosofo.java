package filosofos;

/**
 *
 * @author Guille
 */
public class Filosofo extends Thread {

    private String nombre;
    private Palillo izquierdo;
    private Palillo derecho;
    private Mesa m;

    public Filosofo(String nombre, Mesa m, Palillo izq, Palillo der) {
        this.nombre = nombre;
        this.m = m;
        this.izquierdo = izq;
        this.derecho = der;
    }

    @Override
    public void run() {

        while (true) {

            try {

                pensar();
                comer();

            } catch (InterruptedException ex) {
            }
        }
    }

    private void pensar() throws InterruptedException {
        System.out.println("<" + this.nombre + "> Estoy pensando");
        Thread.sleep(Main.generarNumAleatorio(2000, 4000));
    }

    private void comer() throws InterruptedException {
        cogerPalillos();
        Thread.sleep(Main.generarNumAleatorio(2000, 4000));
        System.out.println("<" + this.nombre + "> Estoy comiendo");
        dejarPalillos();

    }

    private void cogerPalillos() throws InterruptedException {
        boolean conseguido = false;
        while (!conseguido) {
            if (derecho.intentarCoger()) {
                System.out.println("<" + this.nombre + "> Conseguido palillo derecho");
                if (izquierdo.intentarCoger()) {
                    System.out.println("<" + this.nombre + "> Conseguido palillo izquierdo");
                    conseguido = true;
                } else {
                    derecho.dejar();
                }
            }
        }
    }

    private void dejarPalillos() {
        derecho.dejar();
        izquierdo.dejar();
    }

}
