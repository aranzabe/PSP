/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carrerarelevos2;

/**
 *
 * @author fernando
 */
public class Atleta extends Thread {
    private int dorsal;
    private Testigo te;
    private int numeroEquipo;
    
    
    public Atleta(String ne, int dorsal, Testigo te, int numeroEquipo) {
        this.setName(ne + " corredor " + dorsal);
        this.dorsal = dorsal;
        this.te = te;
        this.numeroEquipo = numeroEquipo;
    }

    @Override
    public void run() {
        boolean acabadeCorrer = false;
        while(!acabadeCorrer){
            acabadeCorrer = te.cogerTestigo(this.dorsal, this.numeroEquipo);
        }
    }
    
    
    
}
