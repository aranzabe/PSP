/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carrerarelevos2;


/**
 *
 * @author fernando
 */
public class Testigo {
    private int turno=1;
    
    public synchronized  boolean cogerTestigo(int dorsal, int equipo) {
        boolean haCorrido=false;
        if (turno == dorsal){
            try {
                int tiempoCorrer = (int) (Math.random()*5000);
                System.out.println(Thread.currentThread().getName() + ": corriendo ("+ tiempoCorrer +")....");
                Thread.sleep(tiempoCorrer);
                
                turno++;
                haCorrido=true;
                if (turno==5){
                    Podio.subirPodio(equipo);
                    System.out.println(Thread.currentThread().getName() + ": acaba su carrera y la del equipo." + equipo);
                }
                else {
                    System.out.println(Thread.currentThread().getName() + ": acaba su carrera y pasa el testigo.");
                }
                notifyAll();
            } catch (InterruptedException ex) {
                System.err.println("Error en la ejecución: " + ex.getMessage());
            }
        }
        else {
            try {
                wait();
            } catch (InterruptedException ex) {
                System.err.println("Error en la ejecución: " + ex.getMessage());
            }
        }
        return haCorrido;
    }
    
}
