/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carrerarelevos2;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author fernando
 */
public class Equipo extends Thread {
    private Atleta atletas[];
    private Testigo testigo;
    private String nombreEquipo;
    private int numEquipo;

    public Equipo(String ne, int numEquipo) {
        this.nombreEquipo = ne;
        atletas = new Atleta[4];
        testigo = new Testigo();
        this.numEquipo = numEquipo;
        for (int i = 0; i < atletas.length; i++) {
            atletas[i]=new Atleta(ne, (i+1), this.testigo, this.numEquipo);
        }
    }

    @Override
    public void run() {
        this.comenzarCarrera();
        this.esperarFinal();
    }
    
    
    
    public void comenzarCarrera(){
        for (int i = 0; i < atletas.length; i++) {
            atletas[i].start();
        }
    }
    
    public void esperarFinal(){
        for (int i = 0; i < atletas.length; i++) {
            try {
                atletas[i].join();
            } catch (InterruptedException ex) {
                System.err.println("Error en la ejecución: " + ex.getMessage());
            }
        }
    }

    int getNumEquipo() {
        return this.numEquipo;
    }
}
