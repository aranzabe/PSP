/*
 * Generalización del ejercicio anterior (CarreraRelevos1) para cuatro equipos de cuatro atletas.
 */
package carrerarelevos2;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author fernando
 */
public class CarreraRelevos2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Equipo e[] = new Equipo[4];
        for (int i = 0; i < e.length; i++) {
            e[i] = new Equipo("Equipo " + (i+1), (i+1));
        }
        
        //Arrancamos a los equipos.
        for (int i = 0; i < e.length; i++) {
            e[i].start();
        }
        
        //Esperamos a los equipos.
        for (int i = 0; i < e.length; i++) {
            try {
                e[i].join();
            } catch (InterruptedException ex) {
                System.err.println("Error en la ejecución: " + ex.getMessage());
            }
        }
        
        System.out.println("Hilo principal acabando.");
        Podio.mostrarPodio();
    }
}
