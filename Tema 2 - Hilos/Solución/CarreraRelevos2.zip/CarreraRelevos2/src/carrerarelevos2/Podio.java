/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carrerarelevos2;

/**
 *
 * @author fernando
 */
public class Podio {
    private static int pod[];
    
    static {
        pod = new int[4];
    }
    
    public static synchronized  void subirPodio(int equipo){
        int i=0;
        boolean colocado=false;
        while(i<pod.length && !colocado){
            if (pod[i]==0){
                pod[i]=equipo;
                colocado=true;
            }
            i++;
        }
    }

    public static void mostrarPodio() {
        for (int i = 0; i < pod.length; i++) {
            System.out.println("Orden de llegada: " + pod[i] + " ");
        }
    }
}
