/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prod2cons3turnos;

/**
 *
 * @author faranzabe
 */
public class Recurso {

    private int valor;
    private boolean consumido;
    private int ordenConsumir = 1;
    private int ordenProducir = 1;

    public Recurso() {
        this.consumido = true;
    }

    public synchronized int producirValor(int prio) {

        if (this.consumido) {
            if (ordenProducir==prio) {
                this.valor = (int) (Math.random() * 100);
                this.consumido = false;
                System.out.println(Thread.currentThread().getName() + " produce el: " + this.valor);
                ordenProducir++;
                if (ordenProducir==3){
                    ordenProducir=1;
                }
                notifyAll();
            } else {
                try {
                    wait();
                } catch (InterruptedException ex) {
                }
            }
        }

        return this.valor;
    }

    public synchronized int consumirValor(int prio) {

        int dato = 0;

        if (!this.consumido) {
            if (ordenConsumir == prio) {
                dato = this.valor;
                this.consumido = true;
                System.out.println(Thread.currentThread().getName() + " consume: " + dato);
                ordenConsumir++;
                if (ordenConsumir == 4) {
                    ordenConsumir = 1;
                }
                notifyAll();
            }
        } else {
            try {
                wait();
            } catch (InterruptedException ex) {
            }
        }
        return dato;
    }
}
