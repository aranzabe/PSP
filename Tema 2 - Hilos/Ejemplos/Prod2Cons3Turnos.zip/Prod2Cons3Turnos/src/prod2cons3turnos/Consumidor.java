/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prod2cons3turnos;


/**
 *
 * @author faranzabe
 */
public class Consumidor extends Thread{
    
    private Recurso r;
    private int prioridad;

    public Consumidor(Recurso r, String nombre, int prioridad) {
        super(nombre);
        this.r = r;
        this.prioridad = prioridad;
    }

    @Override
    public void run() {
        
        do {
            this.r.consumirValor(this.prioridad);    
        } while (true);
    }
}
