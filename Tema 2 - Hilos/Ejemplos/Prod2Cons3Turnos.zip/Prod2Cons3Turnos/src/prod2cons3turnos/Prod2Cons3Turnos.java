/*
 * Este ejercicio tiene dos productores que generan un número por turnos y que será consumido por los
 * tres consumidores por turno: P1 --> C1   P2 --> C2   P1 --> C3  P2 --> C1 etc...
 */
package prod2cons3turnos;

/**
 *
 * @author fernando
 */
public class Prod2Cons3Turnos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Recurso r = new Recurso();
        
        Productor p1 = new Productor(r, "P1", 1);
        Productor p2 = new Productor(r, "P2", 2);
        Consumidor c1 = new Consumidor(r, "C1", 1);
        Consumidor c2 = new Consumidor(r, "C2", 2);
        Consumidor c3 = new Consumidor(r, "C3", 3);
        
        p1.start();
        p2.start();
        c1.start();
        c2.start();
        c3.start();
    }
    
}
