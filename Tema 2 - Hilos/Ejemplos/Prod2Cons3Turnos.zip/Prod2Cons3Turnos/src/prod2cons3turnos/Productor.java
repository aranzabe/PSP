/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prod2cons3turnos;


/**
 *
 * @author faranzabe
 */
public class Productor extends Thread{
    
    private Recurso r;
    private int prioridad;

    public Productor(Recurso r, String nombre, int prioridad) {
        super(nombre);
        this.r = r;
        this.prioridad = prioridad;
    }

    @Override
    public void run() {
        
        do{
            
            this.r.producirValor(this.prioridad);
        
        }while(true);
        
    }
}
