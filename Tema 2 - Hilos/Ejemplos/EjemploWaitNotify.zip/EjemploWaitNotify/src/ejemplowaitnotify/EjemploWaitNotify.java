
package ejemplowaitnotify;


public class EjemploWaitNotify {


    public static void main(String[] args) throws InterruptedException {
        // Objeto en comun, se encarga del wait y notify
        Saludo s = new Saludo();
       
        /*Instancio los hilos y le paso como parametros:
         *
         * El Nombre del Hilo(en este caso es el nombre del personal)
         * ----El objeto en comun (Saludo)----
         * Un booleano para verificar si es profe o alumno.
         *
        */       

        Personal Alumno1 = new Personal("Ana", s, false);
        Personal Alumno2 = new Personal("José", s, false);
        Personal Alumno3 = new Personal("Pedro", s, false);
        Personal Profe = new Personal("Profe", s, true);
       
             //Lanzo los hilos       
            Alumno1.start();           
            Alumno3.start();  
            Alumno2.start(); 
            Thread.sleep(2000);
            Profe.start();
                                  


    }
}
