package ejemplowaitnotify;


/**
 *
 * @author fernando
 */
public class Saludo {

public Saludo(){       
    }
   
    /* Si no es profe, la persona se va a quedar esperando a que llegue el profe
    Se hace wait de el hilo que esta corriendo y se bloquea, hasta que
    se le avise que ya puede saludar.*/
    //public void saludoAlumno(String nombre){
    public synchronized void saludoAlumno(String nombre){
        try {
                wait();
                System.out.println(nombre.toUpperCase() + ": Buenos días profe.");
                //notify();
            
        } catch (InterruptedException ex) 
        { 
            System.out.println("Error inesperado.");
        }
    }
   
    //Si es profesor, saluda y luego despierta a los alumnos para que saluden
    // El notifyAll despierta a todos los hilos que esten bloqueados
    public synchronized void saludoProfe(String nombre){
        System.out.println("****** "+nombre + ": Buenos días, hermosos. ******");
        //notifyAll();
        notify(); //--> Sólo despertaría a un hilo.
    }    
}
