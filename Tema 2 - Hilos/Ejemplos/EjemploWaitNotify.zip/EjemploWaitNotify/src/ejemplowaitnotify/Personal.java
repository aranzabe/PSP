
package ejemplowaitnotify;



public class Personal extends Thread {
    private Saludo saludo;
    private boolean esProfe;
   
    
    public Personal(String nombre, Saludo salu, boolean esProfe){
        this.setName(nombre);
        this.saludo = salu;
        this.esProfe = esProfe;
    }
   
    public void run(){
        System.out.println(this.getName() + " llegó.");
        try {
            Thread.sleep(100);
            //Verifico si el personal que se está ejecutando ahora es profe o alumno.
            if(esProfe){
                saludo.saludoProfe(this.getName());
            }else{
                saludo.saludoAlumno(this.getName());
            }
           
        } catch (InterruptedException ex) {
            System.out.println("Error producido en el hilo: " + Thread.currentThread().getName());
        }
    }
}

