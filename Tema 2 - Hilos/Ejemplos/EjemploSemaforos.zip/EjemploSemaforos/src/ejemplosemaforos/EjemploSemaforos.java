/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplosemaforos;

import java.util.concurrent.Semaphore;

/**
 *
 * @author fernando
 */
public class EjemploSemaforos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        //Opción a)
        Hilo h1= new Hilo();
        Hilo h2=new Hilo();
        Hilo h3=new Hilo();
        
        //Opción b)
//        Semaphore sema = new Semaphore(2);
//        Hilo h1 = new Hilo(sema);
//        Hilo h2 = new Hilo(sema);
//        Hilo h3 = new Hilo(sema);
        
        h1.start();
        h2.start();
        h3.start();
        
        h3.join();
        System.out.println("h3 terminado" );
        h1.join();
        System.out.println("h1 terminado" );
        h2.join();
        System.out.println("h2 terminado" );
        
    }
}
