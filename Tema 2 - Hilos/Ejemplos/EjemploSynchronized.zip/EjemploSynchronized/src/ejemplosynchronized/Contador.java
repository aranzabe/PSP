package ejemplosynchronized;

public class Contador {

    private int valor = 0;

    public  synchronized void incrementa() {
    //public void incrementa() {
        int aux;
            aux = valor;
            aux++;
            valor = aux;
    }

    public long getValor() {
        return valor;
    }

}
