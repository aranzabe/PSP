package ejemplosynchronized;


public class Contable extends Thread {
    private Contador contador;

    public Contable (Contador c, String nombre) {
        contador=c;
        this.setName(nombre);
    }
    
    public void run () {
        int i;
        long aux;
        
        for (i=1;i<=2000; i++) {
            contador.incrementa();
        }

        System.out.println("Contado hasta ahora ("+ this.getName() + "): " + contador.getValor());
    }  
}
