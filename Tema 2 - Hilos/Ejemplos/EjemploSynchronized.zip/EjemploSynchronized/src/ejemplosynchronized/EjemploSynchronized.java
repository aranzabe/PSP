package ejemplosynchronized;


public class EjemploSynchronized {


    public static void main(String[] args) {
        Contable c1 , c2 ;
        Contador c = new Contador();
        c1 = new Contable(c, "C1");
        c2 = new Contable(c, "C2");
        c1.start();
        c2.start();
    }
}
