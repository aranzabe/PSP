/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplomonitor;

/**
 *
 * @author fernando
 */
public class EjemploMonitor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            Monitor m = new Monitor();
            HiloDuerme hdu = new HiloDuerme("El que duerme", m);
            HiloDespierta hde = new HiloDespierta("El que despierta", m);
             
            hdu.start();
            Thread.sleep(2000);
            hde.start();
        } catch (InterruptedException ex) {
        }
    }
    
}
