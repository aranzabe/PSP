/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplomonitor;


/**
 *
 * @author fernando
 */
public class Monitor {
    
    public synchronized  void duerme(){
        try {
            System.out.println("El hilo " + Thread.currentThread().getName() + " se duerme.");
            wait();
            System.out.println("Me despierto");
        } catch (InterruptedException ex) {
        }
    }
    
    public synchronized void despierta(){
        System.out.println("El hilo " + Thread.currentThread().getName() + " despertando a todos.");
        notifyAll();
    }
}
