/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplomonitor;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author fernando
 */
public class HiloDuerme extends Thread {
    private Monitor mo;

    public HiloDuerme(String name) {
        super(name);
    }

    HiloDuerme(String name, Monitor m) {
        super(name);
        this.mo = m;
    }

    @Override
    public void run() {
        //duerme();
        mo.duerme();
    }

    private synchronized void duerme() {
        try {
            System.out.println("El hilo " + this.getName() + " se duerme.");
            wait();
            System.out.println("Me despierto");
        } catch (InterruptedException ex) {
        }
    }
    
    public void despierta(){
        
    }
    
}
