/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplomonitor;

/**
 *
 * @author fernando
 */
public class HiloDespierta extends Thread {
    private Monitor mo;
    
    public HiloDespierta(String name) {
        super(name);
    }

    HiloDespierta(String name, Monitor m) {
        super(name);
        this.mo = m;
    }

    @Override
    public void run() {
        //System.out.println("Despertando a todos.");
        //despierta();
        mo.despierta();
    }

    private synchronized  void despierta() {
        notifyAll();
    }
}
