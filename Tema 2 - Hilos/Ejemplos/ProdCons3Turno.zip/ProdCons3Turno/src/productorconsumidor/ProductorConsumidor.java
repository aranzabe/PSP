/*
 * Este ejercicio tiene un productor que genera un número y que será consumido por los
 * tres consumidores por turno: P --> C1   P --> C2   P --> C3  P --> C1 etc...
 */
package productorconsumidor;

/**
 *
 * @author faranzabe
 */
public class ProductorConsumidor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Recurso r = new Recurso();
        
        Productor p = new Productor(r, "P");
        Consumidor c1 = new Consumidor(r, "C1", 1);
        Consumidor c2 = new Consumidor(r, "C2", 2);
        Consumidor c3 = new Consumidor(r, "C3", 3);
        
        p.start();
        c1.start();
        c2.start();
        c3.start();
    }

   
}
