/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package productorconsumidor;


/**
 *
 * @author faranzabe
 */
public class Consumidor extends Thread{
    
    private Recurso r;
    private int prioridad;

    public Consumidor(Recurso r, String nombre, int prioridad) {
        super(nombre);
        this.r = r;
        this.prioridad = prioridad;
    }

    @Override
    public void run() {
        int prio;
        
        do {
            prio = this.prioridad;
            this.r.consumirValor(prio);    
        } while (true);
    }
}
