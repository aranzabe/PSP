/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package productorconsumidor;


/**
 *
 * @author faranzabe
 */
public class Recurso {

    private int valor;
    private boolean consumido;
    private int orden;

    public Recurso() {
        this.consumido = true;
        this.orden=1;
    }

    public synchronized int producirValor() {

        if (this.consumido) {
            this.valor = (int) (Math.random() * 100);
            this.consumido = false;
            System.out.println(Thread.currentThread().getName() + " produce el: " + this.valor);
            notifyAll();
        } else {
            try {
                wait();
            } catch (InterruptedException ex) {
            }
        }

        return this.valor;
    }

    public synchronized int consumirValor(int prio) {

        int dato = 0;

        if (!this.consumido) {
            if (orden == prio) {
                dato = this.valor;
                this.consumido = true;
                System.out.println(Thread.currentThread().getName() + " consume: " + dato);
                orden++;
                if(orden == 4){
                    orden = 1;
                }
                notifyAll();
            }
        } else {
            try {
                wait();
            } catch (InterruptedException ex) {
            }
        }
        return dato;
    }
}
