/*
 *
 */
package clases;

import java.util.concurrent.Semaphore;

/**
 *
 * @author angel
 */
public class Filosofo extends Thread {

    private static Semaphore[] palillos = new Semaphore[5];
    private Thread hilo;
    private int id;

    static {
        for (int i = 0; i < palillos.length; i++) {
            palillos[i] = new Semaphore(1);
        }
    }

    public Filosofo(String nombre, int id) {
        this.hilo = new Thread(this);
        this.hilo.setName(nombre);
        this.id = id;
    }

    public void start() {
        this.hilo.start();
    }

    @Override
    public void run() {
        while (true) {
            pensar();

            comer();
        }
    }

    private void pensar() {
        try {
            System.out.println(this.hilo.getName() + " Está pensando");
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            System.out.println("Ocurrió une error inesperado " + e.getMessage());
        }
    }

    private void comer() {
        System.out.println("A " + this.hilo.getName() + " le ha entrado hambre y se dispone a comer");
        if (palillos[this.id - 1].tryAcquire()) {

            System.out.println(this.hilo.getName() + " coje el palillo izquierdo");
            if (this.id == 5) {
                if (palillos[0].tryAcquire()) {

                    System.out.println(this.hilo.getName() + " coje el palillo derecho");
                    System.out.println(this.hilo.getName() + " está comiendo");
                    try {
                        Thread.sleep(8000);
                    } catch (InterruptedException e) {
                        System.out.println("Ocurrió un error inesperado " + e.getMessage());
                    }
                    palillos[0].release();
                } else {
                    System.out.println(this.hilo.getName() + " no ha podido cojer el palillo derecho,no puede comer");
                }

            } else {

                if (palillos[this.id].tryAcquire()) {
                    System.out.println(this.hilo.getName() + " coje el palillo derecho");
                    System.out.println(this.hilo.getName() + " está comiendo");
                    try {
                        Thread.sleep(8000);
                    } catch (InterruptedException e) {
                        System.out.println("Ocurrió un error inesperado " + e.getMessage());
                    }
                    palillos[this.id].release();
                } else {
                    System.out.println(this.hilo.getName() + " no ha podido cojer el palillo derecho, no puede comer ");
                }
            }
            palillos[this.id - 1].release();

        } else {
            System.out.println(this.hilo.getName() + " no ha podido cojer el palillo izquierdo, no puede comer");
        }
    }
}
