package main;



import clases.Filosofo;

/**
 *
 * @author angel
 */
public class Filosofos {

	
	public static void main(String[] args) {
		
		String [] nombres = {"Platón", "Aristóteles", "Descartes", "Kant","Séneca"};
		for (int i = 0; i < nombres.length; i++) {
			Filosofo filosofo = new Filosofo (nombres[i],i+1);
			filosofo.start();
		}
	}
}
