package personal;

import cafeteria.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author jorge
 */
public class Cocinero extends Thread {
    
    private ArrayList<Comanda> comandas;
    private Local local;
    private int idPedido;

    public Cocinero(String string, Local local, ArrayList<Comanda> listaComandas) {
        super(string);
        this.local = local;
        this.comandas = listaComandas;
        this.idPedido = 1;
    }
    
    synchronized void anotarPedido(Cliente cliente) {
        comandas.add(new Comanda(idPedido, cliente));
        this.idPedido++;
    }
    
    @Override
    public void run() {
        try {
            int pedido = 0;
            while (!local.isCerrado() || local.hayPedidoEnCola(pedido)) {
                if (local.hayPedidoEnCola(pedido)) {
                    prepararPedido(comandas.get(pedido));
                    pedido++;
                    sleep(1000);
                }
            }
            System.out.println("El cocinero se va a su casa.");
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
    }
    
    private void prepararPedido(Comanda comanda) throws InterruptedException {
        System.out.println("Preparando " + comanda.getDescripcion());
        sleep((int) (Math.random() * 10000 + 5000));        
        System.out.println("SERVIDO " + comanda.getDescripcion().toUpperCase());
        comanda.preparado();        
    }        
    
}
