package personal;

import cafeteria.*;
import static java.lang.Thread.sleep;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author jorge
 */
public class Camarero extends Thread {

    private Local local;
    private boolean ocupado;    
    private Cocinero cocinero;
    protected Comanda comanda;

    public Camarero(String nombre, Cocinero cocinero, Local local) {
        super(nombre);
        this.local = local;
        this.ocupado = false;
        this.cocinero = cocinero;
    }

    public synchronized void servirPedido(Cliente cliente, String peticion) {
        System.out.println("Se ha servido " + peticion + " al cliente " + cliente.getName());
        cliente.despertar();
    }

    public synchronized void realizarPeticion(int peticion, Cliente cliente) throws InterruptedException {
        String pedido = local.tipoPedido(peticion);
        switch (peticion) {
            case 1:
            case 2:
            case 3:
                servirPedido(cliente, pedido);
                break;
            case 4:
                //cliente.dormir();
                servirCafe(cliente, pedido);
                break;
            case 5:
                //cliente.dormir();
                tramitarPedido(cliente);
                break;
        }
    }

    public boolean isOcupado() {
        return ocupado;
    }

    public void setOcupado(boolean ocupado) {
        this.ocupado = ocupado;
    }

    private synchronized void servirCafe(Cliente cliente, String pedido) throws InterruptedException {
        local.cogerMaquina();
        sleep(5000);
        local.soltarMaquina();
        servirPedido(cliente, pedido);
    }

    private synchronized void tramitarPedido(Cliente cliente) throws InterruptedException {
        cocinero.anotarPedido(cliente);
    }

    @Override
    public void run() {
        int pedido=0;
        while (!local.isCerrado()||local.hayPedidoEnCola(pedido)) {  
            if (!ocupado && local.pedidoPreparado(this)) {
                servirComanda();    
                pedido++;
            }
        }       
        System.out.println(this.getName()+" se va a su casa.");
    }

    public synchronized void asignarComanda(Comanda comanda) {
        this.comanda = comanda;
    }

    synchronized void servirComanda() {                            
            System.out.print(this.getName() + " ");            
            servirPedido(comanda.getCliente(), comanda.getDescripcion());
            comanda.servido();            
            //local.cerrar();        
    }

}
