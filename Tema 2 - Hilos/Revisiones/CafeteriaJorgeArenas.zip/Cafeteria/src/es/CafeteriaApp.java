package es;

import cafeteria.*;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author jorge
 */
public class CafeteriaApp {

    public static void main(String[] args) throws InterruptedException {
        Local local = new Local(10, 2);        
        ArrayList<Cliente> clientes = new ArrayList<>();
        Cliente c;
        int timer = 0, segundos = 12;
        while (!local.isCerrado()) {                           
            if (timer <= segundos) {
                c = new Cliente(local);
                clientes.add(c);
                c.start();
                Thread.sleep(1000);
                timer++;
            } else {
                System.out.println("Ha llegado la hora de cerrar.");
                local.cerrar();
            }        
        }        
        for (Cliente cliente : clientes) {
            cliente.join();
        }
        System.out.println("Todos los clientes han abandonado el local");
    }
}
