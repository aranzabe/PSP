/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cafeteria;

import java.util.logging.Level;
import java.util.logging.Logger;
import personal.Camarero;

/**
 *
 * @author jorge
 */
public class Cliente extends Thread {

    private String name;
    private Local local;
    private Camarero camarero;

    public Cliente(Local local) {
        this.local = local;
        this.name = super.getName();
    }

    @Override
    public void run() {
        try {
            if (local.intentarEntrar()) {
                System.out.println(name + " ha llegado.");                
                trabajoCamarero();
                sleep(5000);
                local.abandonar(this);
            } else {
                System.out.println("Aforo completo " + this.name + " se va.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private synchronized void trabajoCamarero() throws InterruptedException {
        local.solicitarCamarero();
        camarero = local.asignarCamarero();
        System.out.println(camarero.getName() + " asignado a " + this.getName());
        int peticion = (int) (Math.random() * 5 + 1);
        camarero.realizarPeticion(peticion, this);        
        local.liberarCamarero(camarero);        
    }

    public synchronized void despertar() {
        notify();
    }

    public synchronized void dormir() throws InterruptedException {
        wait();
    }

}
