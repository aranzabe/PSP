package cafeteria;

import java.util.ArrayList;
import java.util.concurrent.Semaphore;
import personal.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author jorge
 */
public class Local {

    private Semaphore aforo, camarerosLibres, maquinaCafe = new Semaphore(1);
    private Camarero[] camareros;
    private Cocinero cocinero;
    private boolean cerrado;
    private ArrayList<Comanda> comandas = new ArrayList<>();

    public Local(int aforo, int camareros) {
        this.aforo = new Semaphore(aforo);
        this.camareros = new Camarero[camareros];
        this.camarerosLibres = new Semaphore(camareros);
        generarPersonal();
        this.cerrado = false;
    }

    void generarPersonal() {
        this.cocinero = new Cocinero("Cocinero", this, comandas);
        for (int i = 0; i < camareros.length; i++) {
            camareros[i] = new Camarero("Camarero " + (i + 1), cocinero, this);
            camareros[i].start();
        }
        this.cocinero.start();
    }

    void solicitarCamarero() throws InterruptedException {
        camarerosLibres.acquire();
    }

    public String tipoPedido(int peticion) {
        switch (peticion) {
            case 1:
                return "chucherías";
            case 2:
                return "bebida";
            case 3:
                return "bocadillo preparado";
            case 4:
                return "café";
            case 5:
                return "comida para preparar";
        }
        return "";
    }

    public boolean isCerrado() {
        return cerrado;
    }

    public void cerrar() {
        System.out.println("Local cerrado. vuelva mañana");
        this.cerrado = true;
    }

    synchronized void liberarCamarero(Camarero c) {
        camarerosLibres.release();
        c.setOcupado(false);        
    }

    public boolean intentarEntrar() {
        return aforo.tryAcquire();
    }

    void abandonar(Cliente c) {
        aforo.release();
        System.out.println(c.getName() + " se va.");
    }

    synchronized Camarero asignarCamarero() {
        for (int i = 0; i < camareros.length; i++) {
            if (!camareros[i].isOcupado()) {
                camareros[i].setOcupado(true);
                return camareros[i];
            }
        }
        return null;
    }

    public void cogerMaquina() throws InterruptedException {
        maquinaCafe.acquire();
    }

    public void soltarMaquina() {
        maquinaCafe.release();
    }

    public synchronized boolean pedidoPreparado(Camarero camarero) {        
        for (int i = 0; i < comandas.size(); i++) {            
            if (comandas.get(i).isPreparado() && !comandas.get(i).isServido()) {
                camarero.asignarComanda(comandas.get(i));
                return true;
            }
        }
        return false;
    }

    public void servirPedido() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public boolean hayPedidoEnCola(int pedido) {
        return pedido < comandas.size();
    }

}
