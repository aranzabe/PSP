/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cafeteria;

import personal.*;

/**
 *
 * @author jorge
 */
public class Comanda {
    private int pedidoID;    
    private String descripcion;
    private Cocinero cocinero;
    private Cliente cliente;
    private boolean preparado,servido;
    
    public Comanda(int pedidoID,Cliente cliente) {
        this.pedidoID = pedidoID;
        this.descripcion="Pedido "+pedidoID;
        this.preparado=false;        
        this.servido=false;  
        this.cliente=cliente;
    }

    public void preparado() {
        this.preparado = true;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public int getPedidoID() {
        return pedidoID;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public boolean isPreparado() {
        return preparado;
    }

    public boolean isServido() {
        return servido;
    }

    public void servido() {
        this.servido = true;
    }
       
    
}
