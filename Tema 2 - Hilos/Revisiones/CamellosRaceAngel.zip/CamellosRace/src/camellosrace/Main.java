/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package camellosrace;

import static camellosrace.Camellos.mostrarPodio;
import static camellosrace.Camellos.podio;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author angel
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Camellos c1 = new Camellos(1);
        Camellos c2 = new Camellos(2);
        Camellos c3 = new Camellos(3);
        Camellos c4 = new Camellos(4);
        Camellos c5 = new Camellos(5);

        c1.start();
        c2.start();
        c3.start();
        c4.start();
        c5.start();

        try {
            c1.join();
            c2.join();
            c3.join();
            c4.join();
            c5.join();
        } catch (InterruptedException ex) {
        }
        System.out.println("#########  PODIO   ########");
        mostrarPodio();
        System.out.println("");
    }
    
    
}
