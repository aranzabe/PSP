/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package camellosrace;

/**
 *
 * @author angel
 */
public class Camellos extends Thread {

    protected static int[] podio = {0, 0, 0, 0};
    private int num;
    private final int meta = 100;

    public Camellos( int num) {
        this.num = num;
    }

    
    

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    @Override
    public void run() {
        int pasos = 0;
        int avance = 0;
        while (pasos < meta) {
            int x100 = (int) (Math.random() * 100);
            if (x100 <= 40) {
                avance = (int) (Math.random() * 3 + 1);
                pasos += avance;
            } else if (x100 > 40 && x100 <= 70) {
                avance = (int) (Math.random() * 7 + 4);
                pasos += avance;
            } else if (x100 > 70 && x100 <= 90) {
                avance = (int) (Math.random() * 9 + 8);
                pasos += avance;
            } else if (x100 > 90 && x100 <= 95) {
                avance = 10;
                pasos += avance;
            } else if (x100 > 95 && x100 <= 100) {
                avance = 0;
                pasos += avance;

            }
            if (pasos >= meta) {
                System.out.println("***Camello " + this.num + " ha terminado***");

            }
            System.out.println("Camello:" + this.getNum() +" Avance " + pasos);
        }

        int i=0;
        boolean colocado=false;
        while(i < podio.length && !colocado) {
            if (podio[i] == 0) {
                podio[i] = this.getNum();
                colocado=true;
            }
            i++;
        }
        
        
    }
    
    //Me falla por podio ser estatico y me dice que no puedo poner el getnum para que coja el numero del camello
    //por eso lo he incluido en el run, si no lo hubiera hecho debajo
    /*public static synchronized  void subirPodio(){
        int i=0;
        boolean colocado=false;
        while(i<podio.length && !colocado){
            if (podio[i]==0){
                podio[i]=this.getNum();
                colocado=true;
            }
            i++;
        }
    }*/

    public static void mostrarPodio() {
        for (int i = 0; i < podio.length; i++) {
            System.out.println("Orden de llegada: " + podio[i] + " ");
        }
    }
    
    
    
}
