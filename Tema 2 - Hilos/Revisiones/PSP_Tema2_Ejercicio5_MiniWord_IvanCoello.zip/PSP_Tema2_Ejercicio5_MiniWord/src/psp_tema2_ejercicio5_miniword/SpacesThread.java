package psp_tema2_ejercicio5_miniword;

public class SpacesThread extends Thread {

    public SpacesThread(String cadena) {
        super(cadena);
    }

    @Override
    public void run() {

        int numEspacios = 0;

        for (int i = 0; i < this.getName().length(); i++) {
            if (this.getName().charAt(i) == ' '){
                numEspacios++;
            }
        }

        System.out.println("\""+this.getName()+"\" tiene "+numEspacios+" espacios");
    }
}
