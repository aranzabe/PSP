package psp_tema2_ejercicio5_miniword;

import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;

public class DigitsThread extends Thread{

    private JTextPane txtDigitos;
    private JTextArea txaAreaEscritura;
    
    public DigitsThread(String string) {
        super(string);
    }
    
    DigitsThread(JTextArea txaAreaEscritura, JTextPane txtDigitos) {
       this.txaAreaEscritura = txaAreaEscritura;
       this.txtDigitos = txtDigitos;
    }

    @Override
    public void run() {

        String consonantes = "0123456789";
        int numConsonantes = 0;
        for(int i=0;i<this.txaAreaEscritura.getText().length();i++)
        {
            // recorremos las vocales para comparar con cada una de las letras
            for(int j=0;j<consonantes.length();j++)
            {
                if(this.txaAreaEscritura.getText().charAt(i)==consonantes.charAt(j))
                {
                    // aumentamos el contador para la vocal encontrada
                    numConsonantes++;
                }
            }
        }
        txtDigitos.setText(String.valueOf(numConsonantes));

    }

}
