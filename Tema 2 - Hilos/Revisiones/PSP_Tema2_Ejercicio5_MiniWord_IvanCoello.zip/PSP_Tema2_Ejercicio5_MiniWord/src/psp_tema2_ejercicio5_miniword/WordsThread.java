package psp_tema2_ejercicio5_miniword;

import java.util.StringTokenizer;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;

public class WordsThread extends Thread{

    private JTextPane txtPalabras;
    private JTextArea txaAreaEscritura;
    
    public WordsThread(String cadena) {
        super(cadena);
    }
    

    WordsThread(JTextArea txaAreaEscritura, JTextPane txtPalabras) {
        this.txaAreaEscritura = txaAreaEscritura;
        this.txtPalabras = txtPalabras;
    }

    @Override
    public void run() {

        int numPalabras;

        StringTokenizer stringTokenizer = new StringTokenizer(this.txaAreaEscritura.getText(), " ");

        numPalabras = stringTokenizer.countTokens();
        
        txtPalabras.setText(String.valueOf(numPalabras));
        
    }
}
