package psp_tema2_ejercicio5_miniword;

import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;

public class VowelsThread extends Thread {
    
    private JTextPane txtVocales;
    private JTextArea txaAreaEscritura;

    public VowelsThread(String cadena) {
        super(cadena);
    }
    
    VowelsThread(JTextArea txaAreaEscritura, JTextPane txtVocales) {
        this.txaAreaEscritura = txaAreaEscritura;
        this.txtVocales = txtVocales;
    }


    @Override
    public void run() {

        String vocales = "aeiouAEIOU";
        int numVocales = 0;
        for(int i=0;i<this.txaAreaEscritura.getText().length();i++)
        {
            // recorremos las vocales para comparar con cada una de las letras
            for(int j=0;j<vocales.length();j++)
            {
                if(this.txaAreaEscritura.getText().charAt(i)==vocales.charAt(j))
                {
                    // aumentamos el contador para la vocal encontrada
                    numVocales++;
                }
            }
        }
        
        txtVocales.setText(String.valueOf(numVocales));

    }

}
