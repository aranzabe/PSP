/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es;

import java.util.concurrent.Semaphore;

/**
 *
 * @author jorge
 */
public class Planta {

    private Semaphore plazasLibres;

    public Planta(int numero, int filas, int columnas) {
        this.plazasLibres = new Semaphore(filas * columnas);
    }

    public Semaphore getPlazasLibres() {
        return plazasLibres;
    }

}
