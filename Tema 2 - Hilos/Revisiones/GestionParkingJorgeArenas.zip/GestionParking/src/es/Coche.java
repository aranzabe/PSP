/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es;

import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author jorge
 */
public class Coche extends Thread {

    private int matricula;
    private Parking parking;

    public Coche(Parking parking) {
        this.matricula = (int) (Math.random() * 8999 + 1000);
        this.parking = parking;
    }

    @Override
    public void run() {
        try {
            if (parking.getPlazas().tryAcquire()) {
                System.out.println(this.matricula + " ha accedido al garaje");
                for (int i = 0; i < parking.getPlantas().length; i++) {
                    if (parking.getPlantas()[i].getPlazasLibres().tryAcquire()) {
                        System.out.println(this.matricula + " ha aparcado en la planta " + (i - i * 2));
                        if(i<3)aumentarBarra(i);
                        sleep((int) (Math.random() * 15000 + 10000));
                        parking.getPlantas()[i].getPlazasLibres().release();
                        parking.getPlazas().release();
                        System.out.println(this.matricula + " ha abandonado el garaje.");
                        if(i<3)disminuirBarra(i);
                        break;
                    }
                }
            } else {
                System.out.println("El garaje esta completo, " + this.matricula + " se va.");
            }
        } catch (InterruptedException ex) {
            Logger.getLogger(Coche.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void disminuirBarra(int i) {
        switch (i) {
            case 0:
                parking.getEntorno().getPgbPlanta1().setValue(parking.getEntorno().getPgbPlanta1().getValue() - 1);
                break;
            case 1:
                parking.getEntorno().getPgbPlanta2().setValue(parking.getEntorno().getPgbPlanta2().getValue() - 1);
                break;
            case 2:
                parking.getEntorno().getPgbPlanta3().setValue(parking.getEntorno().getPgbPlanta3().getValue() - 1);
                break;
        }
    }

    private void aumentarBarra(int i) {
        switch (i) {
            case 0:
                parking.getEntorno().getPgbPlanta1().setValue(parking.getEntorno().getPgbPlanta1().getValue() + 1);
                break;
            case 1:
                parking.getEntorno().getPgbPlanta2().setValue(parking.getEntorno().getPgbPlanta2().getValue() + 1);
                break;
            case 2:
                parking.getEntorno().getPgbPlanta3().setValue(parking.getEntorno().getPgbPlanta3().getValue() + 1);
                break;
        }
    }
}//Fin de clase

