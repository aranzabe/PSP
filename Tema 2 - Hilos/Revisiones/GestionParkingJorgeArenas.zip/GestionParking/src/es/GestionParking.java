/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es;

import javax.swing.JOptionPane;

/**
 *
 * @author jorge
 */
public class GestionParking {

    public static Parking parking = new Parking(3,3, 3);

    public static void main(String[] args) throws InterruptedException {       
        parking.start();
        parking.join();
        System.out.println("\nGaraje vacío, sentimos las molestias. ¡VUELVA PRONTO!");
        JOptionPane.showMessageDialog(null, "Parking vacío, sentimos las molestias. ¡VUELVA PRONTO!","ADVERTENCIA", JOptionPane.INFORMATION_MESSAGE);
        System.exit(0);
    }
}
