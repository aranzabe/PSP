package localizacion;

import participante.Coche;

public class Plaza {

    protected boolean disponible;
    Coche coche;

    public Plaza() {
        this.disponible = true; //la plaza está disponible por defecto
        this.coche = null;//la plaza no tiene coche por defecto
    }

    public boolean isDisponible() {
        return disponible;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    public Coche getCoche() {
        return coche;
    }

    public void setCoche(Coche coche) {
        this.coche = coche;
    }

    public synchronized void aparcar (Coche coche){
        this.setCoche(coche);
        this.setDisponible(false);
    }

    public void salir (Coche coche){
        this.setCoche(null);
        this.setDisponible(true);
    }

}
