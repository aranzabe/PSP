package localizacion;

import participante.Coche;

public class Planta {

    protected String planta;
    Plaza[][] aparcamiento;
    Boolean isDisponible;

    public Planta(String planta) {
        this.planta = planta;
        this.aparcamiento = new Plaza[3][3];
        for (int f = 0; f < aparcamiento.length; f++) {
            for (int c = 0; c < aparcamiento[0].length; c++) {
                aparcamiento[f][c] = new Plaza();
            }
        }
        this.isDisponible = true;
    }

    public String getPlanta() {
        return planta;
    }
    public void setPlanta(String planta) {
        this.planta = planta;
    }
    public Plaza[][] getAparcamiento() {
        return aparcamiento;
    }
    public void setAparcamiento(Plaza[][] aparcamiento) {
        this.aparcamiento = aparcamiento;
    }
    public Boolean getDisponible() {
        return isDisponible;
    }
    public void setDisponible(Boolean disponible) {
        isDisponible = disponible;
    }

    public boolean aparcar(Coche c){
        boolean aparcado = false;
        int i = 0;
        while (i < this.aparcamiento.length && !aparcado) {
            int j = 0;
            while (j < this.aparcamiento[0].length && !aparcado) {
                if (this.aparcamiento[i][j].getCoche() == null){
                    this.aparcamiento[i][j].aparcar(c);
                    aparcado = true;
                }
                j++;
            }
            i++;
        }
        return aparcado;
    }

    public boolean salir(Coche c){
        boolean plazaLibre = false;
        int i = 0;
        while (i < this.aparcamiento.length && !plazaLibre) {
            int j = 0;
            while (j < this.aparcamiento[0].length && !plazaLibre) {
                if (this.aparcamiento[i][j].getCoche() != null){
                    this.aparcamiento[i][j].salir(c);
                    plazaLibre = true;
                }
                j++;
            }
            i++;
        }
        return plazaLibre;
    }

    public void verPlazasDisponibles(){
        System.out.println("\t\t\t************ Planta "+this.getPlanta()+" ************");
        for (int f = 0; f < this.aparcamiento.length; f++) {
            for (int c = 0; c < this.aparcamiento[0].length; c++) {
                System.out.println("\t\t\t\tPlaza " + (f + 1) + "-" + (c + 1) + " Disponible: " + this.aparcamiento[f][c].isDisponible());
            }
        }
        System.out.println("\t\t\t***********************************");
    }

    public boolean hayPlaza(){
        int plazasDisponibles = 0;
        for (int f = 0; f < this.aparcamiento.length; f++) {
            for (int c = 0; c < this.aparcamiento[0].length; c++) {
                if (this.aparcamiento[f][f].getCoche() == null){
                    plazasDisponibles++;
                }
            }
        }
        if (plazasDisponibles > 0){
            return true;
        }else{
            return false;
        }
    }

}
