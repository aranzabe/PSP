package localizacion;

import participante.Coche;

public class Parking {

    //Semáforo del total de plazas de todo el parking.
    Planta[] parking;

    public Parking() {
        this.parking = new Planta[3];
        for (int i = 0; i < parking.length; i++) {
            parking[i] = new Planta("-"+i);
        }
    }

    public void monitorizarParking(){
        for (int i = 0; i < this.parking.length; i++) {
            this.parking[i].verPlazasDisponibles();
            System.out.println();
        }
    }

    public void intentarAparcarEnElParking(Coche c){
        boolean aparcado = false;
        int j;
        j = 0;
        while (j < this.parking.length && !aparcado) {
            if (this.parking[j].aparcar(c)){
                aparcado = true;
                System.out.println("\t\t\t\t\t"+c.getMatricula()+" ha aparcado.");
            }
            j++;
        }
        /*
        if (!this.hayPlazasParking()){
            System.out.println(c.getMatricula()+" no ha podido aparcar porque no hay plazas");
        }else{
            j = 0;
            while (j < this.parking.length && !aparcado) {
                if (this.parking[j].aparcar(c)){
                    aparcado = true;
                    System.out.println("\t\t\t\t\t"+c.getMatricula()+" ha aparcado.");
                }
                j++;
            }
        }
        */
    }

    public void salirDelParking(Coche c){
        boolean plazaLibre = false;
        int j = 0;
        while (j < this.parking.length && !plazaLibre) {
            if (this.parking[j].salir(c)){
                plazaLibre = true;
                System.out.println("\t\t\t\t"+c.getMatricula()+" ha salido del parking.");
            }
            j++;
        }
    }

   ublic boolean hayPlazasParking(){
        int hayPlaza = 0;
        for (int i = 0; i < this.parking.length; i++) {
            if (this.parking[i].hayPlaza()){
                hayPlaza++;
            }
        }
        if (hayPlaza > 0){
            System.out.println("\t\t\t\t\tHAY PLAZAS DISPONIBLES");
            return true;
        }else {
            System.out.println("\t\t\t\t\tNO HAY PLAZAS DISPONIBLES");
            return false;
        }
    }

}
