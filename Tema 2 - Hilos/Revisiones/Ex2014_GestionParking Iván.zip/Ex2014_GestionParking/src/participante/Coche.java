package participante;

import localizacion.Parking;

public class Coche extends Thread {

    protected String matricula;
    private static Parking parking = new Parking();

    public Coche() {
        this.matricula = generarMatricula();
    }

    public String getMatricula() {
        return matricula;
    }

    private String generarMatricula() {
        int number;
        String matr;
        number = (int) (10000 * Math.random());
        StringBuilder matriculaBuilder = new StringBuilder("" + number);
        for (int i = matriculaBuilder.length(); i < 4; i++) {
            matriculaBuilder.insert(0, "0");
        }
        matr = matriculaBuilder.toString();
        return matr;
    }

    

    @Override
    public void run() {

        if (parking.hayPlazasParking()) {
            parking.aparcarEnElParking(this);
        } else {
            System.out.println(this.getMatricula() + " no ha podido aparcar porque no hay plazas");
        }

        //parking.monitorizarParking();
        parking.salirDelParking(this);
        parking.monitorizarParking();

    }

}
