package simulacion;

import participante.Coche;

public class Simulacion {

    public static void main(String[] args) {
        int itPorTiempo = 0;
        

        while (true) {//10m entre 5s = 120 iteracciones 
            if (itPorTiempo % 10 == 0){
                Coche c = new Coche();
                c.start();
            }
        }
            /*
        Hecho:
            Consultar el estado del Parking.
            Consultar las plazas.
             */
 /*
        Parking parking = new Parking();

        Coche[] coches = new Coche[30];

        for (int i = 0; i < coches.length; i++) {
            coches[i] = new Coche();
            parking.aparcarEnElParking(coches[i]);
        }

        parking.monitorizarParking();

        parking.salirDelParking(coches[coches.length-1]);

        parking.monitorizarParking();
        //System.out.println("¿Hay plazas disponibles?: "+parking.hayPlazasParking());
             */
        }

    }
