/*
14º Un barbero en una peluquería espera a los clientes durmiendo, cuando llega uno,
lo despierta para que le corte el pelo, si continúan llegando clientes toman asiento en
las sillas disponibles en la sala de espera; si llega un cliente y todas las sillas están
ocupadas, se va. Los tiempos de duración del corte de pelo por cada cliente son
aleatorios, así como las llegadas de los mismos a la peluquería.
*/
package ejerciciobarberia;

/**
 *
 * @author ivanc
 */
public class simulacion {
    
    public static void main(String[] args) throws InterruptedException {
        
        int i;
        Barberia clientes[] = new Barberia[20];//SIMULACIÓN CON 20 CLIENTES
        
        //Declaramos los 20 clientes que van a la barbera.
        for (i = 0; i < clientes.length; i++) {
            clientes[i] = new Barberia("Cliente #"+(i+1));
        }
        //los clientes empiezan a ir a la barberia.
        for (i = 0; i < clientes.length; i++) {
            clientes[i].start();
        }
        
        for (i = 0; i < clientes.length; i++) {
            clientes[i].join();
            System.out.println(clientes[i].getName()+" SE HA IDO DE LA BARBERIA.");
        }
        
    }
    
}
