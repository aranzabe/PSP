package ejerciciobarberia;

import java.util.concurrent.Semaphore;

/**
 *
 * @author ivanc
 */
class Barberos extends Thread{
    
    private static final Semaphore barberosDisponibles = new Semaphore(2);
    
    public Barberos(String string) {
        super(string);
    }
    
    @Override
    public void run() {
        int tiempoCortePelo;      
        try {
        
            barberosDisponibles.acquire();
            System.out.println(this.getName()+ " SE ESTÁ CORTANDO EL PELO.");
            tiempoCortePelo = (int) (Math.random() * 5000 + 2000);
            sleep(tiempoCortePelo);
            System.out.println(this.getName() + " HA ACABADO DE CORTARSE EL PELO");
            barberosDisponibles.release();
            tiempoCortePelo = (int) (Math.random() * 500);
            sleep(tiempoCortePelo);
            
        } catch (InterruptedException ie) {}     
    }
}
