package ejerciciobarberia;

import java.util.concurrent.Semaphore;

/**
 *
 * @author ivanc
 */
public class Barberia extends Thread {
    
    // dentro de la barbería hay 4 asientos de espera solo
    private static final Semaphore asientosLibres = new Semaphore(4);
    
    public Barberia(String name) {
        super(name);
    }
    
    @Override
    public void run() {
        Barberos barberos = new Barberos(this.getName());
        int espera;
        try {
            
            asientosLibres.acquire();
            System.out.println(this.getName()+ " HA COGIDO ASIENTO EN LA BARBERÍA.");
            espera = (int) (Math.random() * 5000 + 2000);
            sleep(espera);
            barberos.start();
            //barberos.join(); versión COVID-19 aforo máximo de 4 CLIENTES XD
            System.out.println(this.getName() + " VA A CORTARSE EL PELO.");
            asientosLibres.release();
            espera = (int) (Math.random() * 500);
            sleep(espera);
            
        } catch (InterruptedException ie) {}
    }
}
