/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guorsnl;

/**
 *
 * @author sheil
 */
public class GuorSNL {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        new GuorJFrame().setVisible(true);
        
        HiloVocales hv = new HiloVocales(GuorJFrame.taTexto.getText());
        HiloNumeros hn = new HiloNumeros(GuorJFrame.taTexto.getText());
        HiloEspacios he = new HiloEspacios(GuorJFrame.taTexto.getText());
        HiloPalabra hp = new HiloPalabra(GuorJFrame.taTexto.getText());
        
        
        hv.start();
        hn.start();
        he.start();
        hp.start();
    }
    
}
