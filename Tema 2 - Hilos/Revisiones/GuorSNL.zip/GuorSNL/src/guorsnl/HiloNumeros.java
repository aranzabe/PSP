/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guorsnl;

/**
 *
 * @author sheil
 */
public class HiloNumeros extends Thread{
    
    private String texto;

    public HiloNumeros(String texto) {
        this.texto = texto;
    }
    
    

    @Override
    public void run() {
        super.run(); 
        contadorNumeros();
    }

    private void contadorNumeros() {
       Character numeros [] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};
       int contNumeros = 0;
       
        for (int i = 0; i < this.texto.length(); i++) {
            for (int j = 0; j < numeros.length; j++) {
                if(numeros[j].equals(texto.charAt(i))){
                    contNumeros++;
                }
            }
            
        }
        //System.out.println("Numeros: "+contNumeros);
        GuorJFrame.txtNumeros.setText(String.valueOf(contNumeros));
    }
    
    
    
}
