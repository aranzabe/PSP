/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package contadorletras;
import java.util.StringTokenizer;
/**
 *
 * @author sheil
 */
public class HiloPalabra extends Thread{

    private String texto; 
    
    public HiloPalabra(String texto) {
        this.texto = texto;
    }

    @Override
    public void run() {
        super.run(); //To change body of generated methods, choose Tools | Templates.
        contadorPalabras();
    }

    private void contadorPalabras() {
        StringTokenizer st = new StringTokenizer(texto);
        
        System.out.println("Palabras: " + st.countTokens());
    }
    
    
    
}
