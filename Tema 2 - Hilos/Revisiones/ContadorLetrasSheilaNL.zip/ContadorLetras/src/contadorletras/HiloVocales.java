/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package contadorletras;

/**
 *
 * @author sheil
 */
public class HiloVocales extends Thread{
    
    private String texto;
    

    public HiloVocales(String texto) {
       this.texto = texto;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

 
    @Override
    public void run() {
        contadorVocales();
    }

    private void contadorVocales() {
        String text = this.texto;
        int longitud = texto.length();
        int voc = 0;
        
        for (int i = 0; i < longitud; i++) {
            if(texto.charAt(i)=='a' || texto.charAt(i)=='e' || texto.charAt(i)=='i' || texto.charAt(i)=='o' || texto.charAt(i)=='u'){
                voc ++;
            }
        }
        System.out.println("Vocales: "+voc);
    }

    
    
    
    
}
