/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package contadorletras;

/**
 *
 * @author sheil
 */
public class HiloEspacios extends Thread{
    
    private String texto;

    public HiloEspacios(String texto) {
        this.texto = texto;
    }

    @Override
    public void run() {
        super.run(); //To change body of generated methods, choose Tools | Templates.
        contadorEspacios();
    }

    private void contadorEspacios() {
       int contEspacios = 0;
       
        for (int i = 0; i < texto.length(); i++) {
            if(texto.charAt(i) == ' '){
                contEspacios++;
            }
        }
        
        System.out.println("Espacios: "+contEspacios);
    }
    
    
    
}
