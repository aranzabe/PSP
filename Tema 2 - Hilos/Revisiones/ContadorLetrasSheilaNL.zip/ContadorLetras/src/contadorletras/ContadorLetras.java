/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package contadorletras;

/**
 *
 * @author sheil
 */
public class ContadorLetras {

        
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String  text = "hola que tal estamos 1234";
        
        HiloVocales hv = new HiloVocales(text);
        HiloNumeros hn = new HiloNumeros(text);
        HiloEspacios he = new HiloEspacios(text);
        HiloPalabra hp = new HiloPalabra(text);
        
        
        hv.start();
        hn.start();
        he.start();
        hp.start();
    }
    
}
