
package abc;

import java.util.concurrent.Semaphore;

/**
 *
 * @author Guille
 */
public class Hilo extends Thread{
    
    private static Semaphore sem = new Semaphore(1);
    private static int turno=0;

    public Hilo(String name) {
        super(name);
    }   
    
    @Override
    public synchronized void run(){
        
        while(true){
        try {
            sem.acquire();
            switch(turno){
                case 0:
                    escribirA();
                    break;
                case 1:
                    escribirB();
                    break;
                case 2:
                    escribirC();
                    break;
            }
            sem.release();
        } catch (InterruptedException ex) {
        }
        }
        
    }
    
    public void escribirA(){
        System.out.print("A");
        turno++;
    }
    
    public void escribirB(){
        System.out.print("B");
        turno++;
    }
    
    public void escribirC(){
        System.out.print("C");
        turno=0;
    }
}
