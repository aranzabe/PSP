
package abc;

/**
 *
 * @author Guille
 */
public class ABC {

    public static void main(String[] args) {
        
        Hilo h1 = new Hilo("h1");
        Hilo h2 = new Hilo("h2");
        Hilo h3 = new Hilo("h3");
        
        h1.start();
        h2.start();
        h3.start();
        
        
    }
    
}
