/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tragabolas;

/**
 *
 * @author angel
 */
public class Tragabolas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Juego j = new Juego();
        Jugadores j1 = new Jugadores(1,j);
        Jugadores j2 = new Jugadores(2,j);
        Jugadores j3 = new Jugadores(3,j);
        Jugadores j4 = new Jugadores(4,j);
        
        
        j1.start();
        j2.start();
        j3.start();
        j4.start();
        
        try{
            j1.join();
            j2.join();
            j3.join();
            j4.join();
        }catch(InterruptedException ex){
            
        }
        
        System.out.println("-----------------------");
        System.out.println("Total");
        System.out.println("Jugador 1 ha cogido " + j1.getTakeIt() + " bolas");
        System.out.println("Jugador 2 ha cogido " + j2.getTakeIt() + " bolas");
        System.out.println("Jugador 3 ha cogido " + j3.getTakeIt() + " bolas");
        System.out.println("Jugador 4 ha cogido " + j4.getTakeIt() + " bolas");
        System.out.println("-----------------------");
    }
    
}
