/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tragabolas;

/**
 *
 * @author angel
 */
public class Jugadores extends Thread{
    private int bolas = 5;
    private int takeIt = 0;
    private int id;
    private Juego j;
    public static int totalBolas = 20;

    public Jugadores(int id, Juego j) {
        this.id = id;
        this.j = j;
    }

    @Override
    public void run() {
        while (Jugadores.totalBolas > 0) {
            boolean poner = j.ponerBola(id);
            if (poner) {
                bolas--;
            }

            
            while (j.existeBola()) {
                boolean atrapada = j.atraparBola(id);
                if (atrapada) {
                    takeIt++;
                }
            }
        }
    }

    public int getTakeIt() {
        return takeIt;
    }

}
