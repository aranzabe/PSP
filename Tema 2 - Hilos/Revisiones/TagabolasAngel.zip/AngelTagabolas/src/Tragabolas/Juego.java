/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tragabolas;

/**
 *
 * @author angel
 */
public class Juego {
    private int bola = 0;
    private int turno = 1;
    
    
    public synchronized boolean atraparBola(int id) {
        boolean take = false;
        if (bola == 1) {
            take = true;
            bola = 0;
            System.out.println("El Jugador nº " + id + " ha cogido una bola.");
        }
        return take;
    }
    
    public synchronized boolean existeBola(){
        notifyAll();
        return bola==1;
    }
    
    public synchronized boolean ponerBola(int id){
        boolean poner = false;
        if(id == turno && bola==0){
            bola = 1;
            turno++;
            if (turno == 5){
                turno=1;
            }
            poner = true;
            Jugadores.totalBolas--;
            System.out.println("La Bola la ha puesto el jugador " + id);
            notifyAll();
        }else{
            try {
                wait();
            } catch (InterruptedException ex) {
            }
        }
        return poner;
    }
}
