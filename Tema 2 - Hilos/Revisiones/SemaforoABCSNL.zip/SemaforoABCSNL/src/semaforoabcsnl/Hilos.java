/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package semaforoabcsnl;

import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author sheil
 */
public class Hilos extends Thread{
    Semaphore sem = new Semaphore(1);
    int orden=1;
    
    private String nombre;
    private int turno;

    public Hilos(String nombre, int turno) {
        this.nombre = nombre;
        this.turno = turno;
    }
    
  
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getTurno() {
        return turno;
    }

    public void setTurno(int turno) {
        this.turno = turno;
    }
    
    

    @Override
    public void run() {    
     
       while (true){
           try {
               sem.acquire();
               if(this.getTurno()==orden){
                   System.out.println(this.nombre);
                   Thread.sleep(500);
                   orden++;
                   if(orden==3){
                       orden=1;
                   }
                    sem.release();
               }else{
                   sem.release();
               }
              
           } catch (InterruptedException ex) {
               
           }
       }
    }
}
         
    
    
    

