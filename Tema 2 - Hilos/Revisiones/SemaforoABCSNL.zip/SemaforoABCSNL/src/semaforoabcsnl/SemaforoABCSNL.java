/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package semaforoabcsnl;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author sheil
 */
public class SemaforoABCSNL {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Hilos hiloA = new Hilos ("A", 1);
        Hilos hiloB = new Hilos ("B", 2);
        Hilos hiloC = new Hilos ("C", 3);
        
        hiloA.start();
        hiloB.start();
        hiloC.start();
        
        try {
            hiloA.join();
            hiloB.join();
            hiloC.join();
        } catch (InterruptedException ex) {
            
        }
        
    }
    
}
