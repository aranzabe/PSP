package objetos;

import java.util.concurrent.Semaphore;

/**
 *
 * @author ivanc
 */
public class MaquinaCafe {
    
    private Semaphore maquinaCafe = new Semaphore(1);

    public Semaphore getMaquinaCafe() {
        return maquinaCafe;
    }

    public void setMaquinaCafe(Semaphore maquinaCafe) {
        this.maquinaCafe = maquinaCafe;
    }
    
    public void preparCafe() throws InterruptedException {
        maquinaCafe.acquire();
    }
    public void sacarCafe() {
        maquinaCafe.release();
    }
    
}
