/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objetos;

import participantes.Cliente;

/**
 *
 * @author ivanc
 */
public class Pedido {
    private int tipoPedido;
    private String pedido;
    private boolean preparado;

    public Pedido(Cliente cliente) {
        this.preparado = false;
        this.tipoPedido = (int) (Math.random()*5 + 1);
        switch (tipoPedido){
            case 1:
                pedido = "chucherías";
                break;
            case 2:
                pedido = "bebidas";
                break;
            case 3: 
                pedido = "bocadillos preparados";
                break;
            case 4:
                pedido = "cafés";
                break;
            case 5:
                pedido = "comida para preparar";
                break;
        }
    }

    public int getTipoPedido() {
        return tipoPedido;
    }
    public void setTipoPedido(int tipoPedido) {
        this.tipoPedido = tipoPedido;
    }
    public String getPedido() {
        return pedido;
    }
    public void setPedido(String pedido) {
        this.pedido = pedido;
    }
    public boolean isPreparado() {
        return preparado;
    }
    public void setPreparado(boolean preparado) {
        this.preparado = preparado;
    }
}
