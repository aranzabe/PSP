/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lugar;

import participantes.Cliente;

/**
 *
 * @author ivanc
 */
public class Cafeteria {
    public void empezarSimulacion() {
        Cliente[] clientes = new Cliente[50];
        //lo he hecho así para probar los 50 clientes
        //pero so quiero hacerlo con mas clientes, se puede hacer como la barberia
        // genero mas clientes y en el semaforo de cafeteria lo hago de 50, y los que entran piden
        //y los que no entran se van
        int i;
        for (i = 0; i < clientes.length; i++) {
            clientes[i] = new Cliente();
        }
        for (i = 0; i < clientes.length; i++) {
            clientes[i].start();
        }
    }
    
}
