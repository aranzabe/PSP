package participantes;

import objetos.Pedido;

/**
 *
 * @author ivanc
 */
public class Cliente extends Thread {
    private final String codigoCliente;
    private final Pedido pedido;
    static Camarero c = new Camarero();
    
    public Cliente() {
        this.codigoCliente = generarIdCliente();
        this.pedido = new Pedido(this);
    }

    public String getCodigoCliente() {
        return codigoCliente;
    }
    public Pedido getPedido() {
        return pedido;
    }
    
    private String generarIdCliente (){
        int number;
        String id;
        number = (int)(10000 * Math.random());
        StringBuilder idBuilder = new StringBuilder("" + number);
        for(int i = idBuilder.length(); i < 4; i++){
            idBuilder.insert(0, "0");
        }
        id = idBuilder.toString();
        return id;
    }    
    
    @Override
    public void run() {
        try {
            c.atender(this);
        } catch (InterruptedException ex) {
        }
    }
}
