package participantes;

import java.util.ArrayList;
import java.util.concurrent.Semaphore;
import objetos.Pedido;

/**
 *
 * @author ivanc
 */
public class Cocinero {
    
    private final Semaphore disponible = new Semaphore(1);
    private static ArrayList<Pedido> pedidos = new ArrayList<>();
    
    protected void addComanda (Cliente c){
        pedidos.add(c.getPedido());
    }
    
    protected void prepararPedido() throws InterruptedException{
        for (int i = 0; i < pedidos.size(); i++) {
            if (!pedidos.get(i).isPreparado()){
                cocinar(pedidos.get(i));
            }
        }
    }
    
    private void cocinar (Pedido p) throws InterruptedException{
        disponible.acquire();//el cocinero ya está ocupado
        System.out.println("El cocinero está cocinando...");
        p.setPreparado(true);
        devolverPedido(p);
    }
    
    public void devolverPedido(Pedido p) {
        disponible.release();
        System.out.println("El cocinero devuelve al camarero el pedido...");
    }
    
}
