package participantes;

import java.util.concurrent.Semaphore;
import objetos.MaquinaCafe;

/**
 *
 * @author ivanc
 */
public class Camarero {
    private final Semaphore camarerosDisponibles;
    static Cocinero cocinero = new Cocinero();
    static Camarero camarero = new Camarero();
    static MaquinaCafe cafetera = new MaquinaCafe();

    public Camarero() {
        this.camarerosDisponibles = new Semaphore(2);
    }

    public Semaphore getCamarerosDisponibles() {
        return camarerosDisponibles;
    }
    
    public void atender (Cliente c) throws InterruptedException{
        camarerosDisponibles.acquire();
        if (c.getPedido().getTipoPedido() == 1 ||c.getPedido().getTipoPedido() == 2||c.getPedido().getTipoPedido() == 3){
            System.out.println("El cliente "+c.getCodigoCliente() + " ha pedido " + c.getPedido().getPedido());
            darPedido(c);
        } 
        if (c.getPedido().getTipoPedido() == 4){
            cafetera.getMaquinaCafe().acquire();
            System.out.println("El cliente "+c.getCodigoCliente() + " ha pedido " + c.getPedido().getPedido());
            cafetera.getMaquinaCafe().release();
            darPedido(c);
        }
        if (c.getPedido().getTipoPedido() == 5){
            System.out.println("El cliente "+c.getCodigoCliente() + " ha pedido " + c.getPedido().getPedido());
            cocinero.addComanda(c);
            cocinero.prepararPedido();
            darPedido(c);
        }
    }
    public void darPedido(Cliente c){
        System.out.println("El camarero le da su pedido " + c.getPedido().getPedido() + ", al cliente " + c.getCodigoCliente());
        camarerosDisponibles.release();
    }
    
}
