/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simulacion;

import lugar.Cafeteria;

/**
 *
 * @author ivanc
 */
public class Simulacion {
    
    public static void main(String[] args) {
        Cafeteria c = new Cafeteria();
        c.empezarSimulacion();
    }
    
}
