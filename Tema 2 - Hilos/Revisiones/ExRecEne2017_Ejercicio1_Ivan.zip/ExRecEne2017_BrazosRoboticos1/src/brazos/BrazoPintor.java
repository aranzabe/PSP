package brazos;

import java.util.concurrent.Semaphore;
import objeto.Coche;

/**
 *
 * @author ivanc
 */
public class BrazoPintor implements generadorID{
    
    String nombreRobotPintor;

    public BrazoPintor() {
        this.nombreRobotPintor = generarID();
    }

    public String getNombreRobotPintor() {
        return nombreRobotPintor;
    }

    public void pintar(Coche c, Semaphore montando) throws InterruptedException{
        montando.release();
        System.out.println("Robot "+this.getNombreRobotPintor()+" --> pintando");
        c.setPintado(true);
        montando.acquire();
    }

    @Override
    public String generarID() {
        int number;
        String id;
        number = (int)(10000 * Math.random());
        StringBuilder idBuilder = new StringBuilder("" + number);
        for(int i = idBuilder.length(); i < 4; i++){
            idBuilder.insert(0, "0");
        }
        id = idBuilder.toString();
        return id;
    }
    
    
    
}
