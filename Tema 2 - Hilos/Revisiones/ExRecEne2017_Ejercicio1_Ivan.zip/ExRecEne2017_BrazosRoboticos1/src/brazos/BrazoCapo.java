package brazos;

import objeto.Coche;

import java.util.concurrent.Semaphore;

/**
 *
 * @author ivanc
 */
public class BrazoCapo implements generadorID{
    
    String nombreRobotCapo;

    public BrazoCapo() {
        this.nombreRobotCapo = generarID();
    }

    public String getNombreRobotCapo() {
        return nombreRobotCapo;
    }

    public void montarCapo(Coche c, Semaphore montando) throws InterruptedException{
        montando.acquire();
        System.out.println("Robot "+this.getNombreRobotCapo()+" --> montando capó");
        c.setCapoMontado(true);
        montando.release();
    }

    @Override
    public String generarID() {
        int number;
        String id;
        number = (int)(10000 * Math.random());
        StringBuilder idBuilder = new StringBuilder("" + number);
        for(int i = idBuilder.length(); i < 4; i++){
            idBuilder.insert(0, "0");
        }
        id = idBuilder.toString();
        return id;
    }
    
}
