/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objeto;

import brazos.BrazoCapo;
import brazos.BrazoMotor;
import brazos.BrazoPintor;
import brazos.BrazoPuertas;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ivanc
 */
public class Coche extends Thread{
 
    private boolean puertasMontadas;
    private boolean motorMontado;
    private boolean capoMontado;
    private boolean pintado;
    protected static Semaphore trabajando = new Semaphore(1);
    private static BrazoPuertas bp = new BrazoPuertas();
    private static BrazoCapo bc = new BrazoCapo();
    private static BrazoMotor bm = new BrazoMotor();
    private static BrazoPintor bpint = new BrazoPintor();

    public Coche() {
        this.puertasMontadas = false;
        this.motorMontado = false;
        this.capoMontado = false;
        this.pintado = false;
    }

    public boolean isPuertasMontadas() {
        return puertasMontadas;
    }
    public void setPuertasMontadas(boolean puertasMontadas) {
        this.puertasMontadas = puertasMontadas;
    }
    public boolean isMotorMontado() {
        return motorMontado;
    }
    public void setMotorMontado(boolean motorMontado) {
        this.motorMontado = motorMontado;
    }
    public boolean isCapoMontado() {
        return capoMontado;
    }
    public void setCapoMontado(boolean capoMontado) {
        this.capoMontado = capoMontado;
    }
    public boolean isPintado() {
        return pintado;
    }
    public void setPintado(boolean pintado) {
        this.pintado = pintado;
    }
    
    @Override
    public void run() {
        try {
            bp.montarPuertas(this,trabajando);
            bm.montarMotor(this,trabajando);
            bc.montarCapo(this,trabajando);
            bpint.pintar( this,trabajando);
            System.out.println();
        } catch (InterruptedException ex) {
        }
    }
    
    public void verInfo(){
        System.out.println("Puertas montadas: "+this.isPuertasMontadas());
        System.out.println("Motor montados: "+this.isMotorMontado());
        System.out.println("Capo montado: "+this.isCapoMontado());
        System.out.println("Puertas Montadas: "+this.isPuertasMontadas());
        System.out.println("Pintado: "+this.isPintado());

    }
    
}
