package simulacion;

import objeto.Coche;

/**
 *
 * @author ivanc
 */
public class simulacion {
    
    public static void main(String[] args) throws InterruptedException {
        
        Coche[] coches = new Coche[50];
        
        for (int i = 0; i < coches.length; i++) {
            coches[i] = new Coche();
        }
        
        for (int i = 0; i < coches.length; i++) {
            coches[i].start();
        }
        
    }
    
}
