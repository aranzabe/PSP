/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio4;

/**
 *
 * @author disen
 */
public class HiloVocales extends Thread {
    private int contador;
    private String texto;

    public HiloVocales(String texto) {
        this.texto = texto;
    }

    public int getContador() {
        return contador;
    }

    public void setContador(int contador) {
        this.contador = contador;
    }
    
    @Override
    public synchronized void run()  {
        String vocales="aeiouAEIOU"; 
        for(int i = 0; i < texto.length(); i++) {
            for(int j=0;j<vocales.length();j++){
                if(texto.charAt(i)==vocales.charAt(j)){
                    
                    contador++;
                }
            }
        }
        
        System.out.println("Nº de vocales: "+contador);
            
            
    }
    
    
}
