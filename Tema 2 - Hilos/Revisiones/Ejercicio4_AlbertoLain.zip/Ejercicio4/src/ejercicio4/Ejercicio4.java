/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author disen
 */
public class Ejercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader (isr);
        System.out.print("Introduzca una cadena: ");
        String cadena=br.readLine();
        
        HiloVocales hilvoc=new HiloVocales(cadena);
        HiloDigitos hildig=new HiloDigitos(cadena);
        HiloPalabras hilpalab=new HiloPalabras(cadena);
        HiloEspacios hilesp=new HiloEspacios(cadena);
        
        hilvoc.start();
        hildig.start();
        hilpalab.start();
        hilesp.start();
    }
    
}
