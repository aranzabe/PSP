/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio4;

/**
 *
 * @author disen
 */
public class HiloEspacios extends Thread {
    private int contador;
    private String texto;

    public HiloEspacios(String texto) {
        this.texto = texto;
    }

    public int getContador() {
        return contador;
    }

    public void setContador(int contador) {
        this.contador = contador;
    }
    
    
    @Override
    public synchronized void run()  {
        for (int i = 0; i < texto.length(); i++) {
           
            if (texto.charAt(i) == ' '){
                contador++;
            }
        }
        
        System.out.println("Nº de espacios: "+contador);
            
    }
}
