/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Principal;

import Objetos.*;
import java.util.ArrayList;


/**
 *
 * @author jorge
 */
public class CadenaMontajeApp {
    public static void main(String[] args) throws InterruptedException {
        Cadena cadena= new Cadena();      
        Coche c;                
        for (int i = 0; i < 10; i++) {
            c=new Coche(i+1,(int)Math.random()*8999+1000,5);                       
            cadena.entrar();            
            System.out.println("soy "+c.getName());
            cadena.asignarCoche(c);            
            if(i==0)cadena.iniciar();
        }                           
        cadena.esperarFin();
        System.out.println("Todos los coches montados.");
        //System.exit(0);
    }
}
