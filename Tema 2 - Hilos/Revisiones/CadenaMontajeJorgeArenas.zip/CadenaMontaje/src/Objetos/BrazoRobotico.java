/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Objetos;

/**
 *
 * @author jorge
 */
public class BrazoRobotico extends Thread {

    protected Cadena cadena;
    protected Coche coche;
    private String nombre;

    public BrazoRobotico(String nombre, Cadena cadena) {
        super(nombre);
        this.cadena = cadena;
    }

    void pasarCoche(Coche coche) {
        this.coche = coche;
    }

    synchronized void despertar() {
        notify();
    }
    synchronized void dormir() throws InterruptedException{
        wait();
    }
}
