/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Objetos;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author jorge
 */
public class Motor extends BrazoRobotico {

    public Motor(String nombre, Cadena cadena) {
        super(nombre, cadena);
    }

    @Override
    public void run() {
        while (!cadena.isFin()) {
            if (coche.isPuertasPuestas() && !coche.isMotorPuesto()) {
                try {
                    sleep(2000);
                    System.out.println("Motor puesto");
                    coche.ponerMotor();
                    cadena.motorPuesto();
                    cadena.despertarPintar();
                    dormir();
                } catch (InterruptedException ex) {
                }
            }
        }
    }

}
