/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Objetos;

/**
 *
 * @author jorge
 */
public class Pintar extends BrazoRobotico {
    
    public Pintar(String nombre,Cadena cadena) {
        super(nombre,cadena);
    }
    
    @Override
    public void run() {
       try{
        while(!cadena.isFin()){
            if(coche.isCapoPuesto()){
                sleep(2000);
                System.out.println("coche pintado.");
                System.out.println("-----------------------------");
                cadena.entregarCoche();
                cadena.despertarPuertasCapo();
                dormir();
            }
       }
       }catch(Exception e){e.printStackTrace();}
    }
    
}
