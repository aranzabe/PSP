package Objetos;

import java.util.concurrent.Semaphore;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author jorge
 */
public class Cadena {
    
    private BrazoRobotico[] puertasCapo;
    private BrazoRobotico motor, pintar;
    private Semaphore turno;
    private boolean fin=false;

    public Cadena() {
        this.puertasCapo = new BrazoRobotico[2];
        this.turno = new Semaphore(1);
        generarBrazos();        
    }

    private void generarBrazos() {
        this.motor = new Motor("motor", this);
        this.pintar = new Pintar("pintar", this);

        for (int i = 0; i < puertasCapo.length; i++) {
            this.puertasCapo[i] = new PuertasCapo("puertasCapo " + i, this);
        }
    }

    public synchronized void asignarCoche(Coche coche) {
        
        for (int i = 0; i < puertasCapo.length; i++) {
            this.puertasCapo[i].pasarCoche(coche);
        }
        this.motor.pasarCoche(coche);
        this.pintar.pasarCoche(coche);
        
    }


    public void iniciar() {        
        for (int i = 0; i < puertasCapo.length; i++) {
            this.puertasCapo[i].start();
        }
        this.motor.start();
        this.pintar.start();
    }

    synchronized void motorPuesto() {
        for (int i = 0; i < puertasCapo.length; i++) {
            this.puertasCapo[i].despertar();
        }
    }

    void entregarCoche() {
        turno.release();
    }

    void despertarPintar() {
        pintar.despertar();
    }

    synchronized void despertarPuertasCapo() {
        for (int i = 0; i < puertasCapo.length; i++) {
            puertasCapo[i].despertar();            
        }
    }

    public void esperarFin() throws InterruptedException {
        for (int i = 0; i < puertasCapo.length; i++) {
            this.puertasCapo[i].join();
        }
        this.motor.join();
        this.pintar.join();
    }

    public boolean isFin() {
        return fin;
    }

    public void finalizar() {
        this.fin=true;
    }

    public void entrar() throws InterruptedException {
        turno.acquire();
    }

    void despertarMotor() {
        motor.despertar();
    }

}
