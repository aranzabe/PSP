/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Objetos;

import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author jorge
 */
public class Coche {

    private String name;
    private int matricula;        ;    
    private Semaphore[] puertas;
    private int contPuertas=0;
    private boolean motorPuesto,puertasPuestas,capoPuesto,pintado;    
    
    public Coche(int numCoche,int matricula, int puertas) {   
        this.name="Coche "+numCoche;
        this.matricula = matricula;
        this.puertas =new Semaphore[puertas];
        for (int i = 0; i < this.puertas.length; i++) {
            this.puertas[i]= new Semaphore(1);
        }            
        iniciarComponentes();
    }         

    private void iniciarComponentes() {
        this.motorPuesto=false;
        this.puertasPuestas=false;
        this.pintado=false;
        this.capoPuesto=false;
    }

    public synchronized boolean isMotorPuesto() {
        return motorPuesto;
    }

    public boolean isPuertasPuestas() {
        return puertasPuestas;
    }

    public boolean isPintado() {
        return pintado;
    }

    boolean intentarPonerPuerta(int i) {
        return puertas[i].tryAcquire();
    }

    void ponerPuerta() throws InterruptedException {
        Thread.sleep((int)(Math.random()*3000+2000));        
        contPuertas++;
        System.out.println("Puerta "+contPuertas+" colocada");
        if(contPuertas==puertas.length)this.puertasPuestas=true;        
    }

    int numPuertas() {
        return puertas.length;
    }

    synchronized void ponerCapo() {
        this.capoPuesto=true;
        System.out.println("Capó colocado");
    }

    public boolean isCapoPuesto() {
        return capoPuesto;
    }

    void ponerMotor() {
        this.motorPuesto=true;
    }

    public String getName() {
        return name;
    }


    

}
