/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Objetos;

/**
 *
 * @author jorge
 */
public class PuertasCapo extends BrazoRobotico {

    public PuertasCapo(String nombre, Cadena cadena) {
        super(nombre, cadena);
    }

    @Override
    public void run() {
        int puerta = 0;
        try {
            while (!cadena.isFin()) {
                if (!coche.isPuertasPuestas()) {
                    if (coche.intentarPonerPuerta(puerta)) {
                        coche.ponerPuerta();
                    } else {
                        if (puerta < coche.numPuertas() - 1) {
                            puerta++;
                        }
                    }
                } else {
                    if (!coche.isMotorPuesto()) {
                        cadena.despertarMotor();
                        dormir();
                        ponerCapo(coche);
                        puerta = 0;                        
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private synchronized void ponerCapo(Coche c) throws InterruptedException {
        if (c.isMotorPuesto()) {
            sleep(1000);
            c.ponerCapo();
        }
    }
}
