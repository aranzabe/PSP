package Camellos;

/**
 *
 * @author Almudena
 */
public class HilosCamellos extends Thread {

    private String nombre;
    private String dorsal;
    private int puntos;

    public HilosCamellos(String nombre, String dorsal, int puntos) {
        this.nombre = nombre;
        this.dorsal = dorsal;
        this.puntos = puntos;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDorsal() {
        return dorsal;
    }

    public void setDorsal(String dorsal) {
        this.dorsal = dorsal;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }

    @Override
    public void run(){
        int avance = 0;
        int aleatorio;
        do {
            aleatorio = (int) (Math.random() * 100 + 1);
            if (aleatorio <= 40) {
                avance = (int) (Math.random() * 3 + 1);
                if (avance + this.puntos > 10) {
                    this.puntos = 10;
                } else {
                    this.puntos += avance;
                }
            } else {
                if (aleatorio >= 41 && aleatorio <= 70) {
                    avance = (int) (Math.random() * (7 - 4 + 1) + 4);
                    if (avance + this.puntos > 10) {
                        this.puntos = 10;
                    } else {
                        this.puntos += avance;
                    }
                } else {
                    if (aleatorio >= 71 && aleatorio <= 90) {
                        avance = (int) (Math.random() * (9 - 8 + 1) + 8);
                        if (avance + this.puntos > 10) {
                            this.puntos = 10;
                        } else {
                            this.puntos += avance;
                        }
                    } else {
                        avance = 10;
                        if(avance + this.puntos > 10) {
                            this.puntos = 10;
                        }else {
                    this.puntos += avance;
                }
                    }
                }
            }

            System.out.println("Soy el camello: " + this.getNombre() + ", con dorsal:  "
                    + this.getDorsal() + " y tengo " + this.puntos + " puntos");

        } while (this.puntos < 10);

    }

}
