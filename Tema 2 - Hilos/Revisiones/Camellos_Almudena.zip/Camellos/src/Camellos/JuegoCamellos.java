package Camellos;

/**
 *
 * @author Almudena
 */
public class JuegoCamellos {

    public static void main(String[] args) {
        int puntos = 0;
               
        HilosCamellos c1 = new HilosCamellos("Camello1", "D01", puntos);
        HilosCamellos c2 = new HilosCamellos("Camello2", "D02", puntos);
        HilosCamellos c3 = new HilosCamellos("Camello3", "D03", puntos);
        HilosCamellos c4 = new HilosCamellos("Camello4", "D04", puntos);
        HilosCamellos c5 = new HilosCamellos("Camello5", "D05", puntos);
        
        c1.start();
        c2.start();
        c3.start();
        c4.start();
        c5.start();
        
    }
    
}
