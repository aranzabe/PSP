/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciocamellos;

/**
 *
 * @author disen
 */
public class EjercicioCamellos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Camello camello1 = new Camello("1");
        Camello camello2 = new Camello("2");
        Camello camello3 = new Camello("3");

        camello1.start();
        camello2.start();
        camello3.start();

        try {
            camello1.join();
            camello2.join();
            camello3.join();
        } catch (InterruptedException ex) {
            System.out.println(ex.getMessage());
        }
        
        /*System.out.println("#########  PODIO   ########");
        for (int i = 0; i < Camello.ganador.length; i++) {
            System.out.printf(Camello.ganador[i] + "\t");
        }
        System.out.println("");*/
    }
    
    
}
