/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciocamellos;

/**
 *
 * @author disen
 */
public class Camello implements Runnable {
    //podium de los camellos
    //protected static int[] ganador = {0, 0, 0, 0, 0};
    
    private String dorsal;
    private final int META = 100;

    private Thread hilo;

    public Camello() {
        hilo = new Thread(this);
    }

    public Camello(String dorsal) {
        hilo = new Thread(this);
        hilo.setName(dorsal);

    }

    public String getDorsal() {
        return dorsal;
    }

    public void setDorsal(String dorsal) {
        this.dorsal = dorsal;
    }

    public void start() {
        hilo.start();
    }

    public void join() throws InterruptedException {
        hilo.join();

    }

    @Override
    public void run() {
        int pasos = 0;
        int avance = 0;

        do {
            int porcentaje = (int) (Math.random() * 100);
            if (porcentaje <= 40) {
                avance = (int) (Math.random() * 3 + 1);
                pasos += avance;
            } else if (porcentaje > 40 && porcentaje <= 70) {
                avance = (int) (Math.random() * 7 + 4);
                pasos += avance;
            } else if (porcentaje > 70 && porcentaje <= 90) {
                avance = (int) (Math.random() * 9 + 8);
                pasos += avance;
            } else if (porcentaje > 90 && porcentaje <= 100) {
                avance = 10;
                pasos += avance;
            }

            if (pasos >= META) {
                System.out.println("***Camello " + hilo.getName() + " ha terminado***");

            }

            try {
                Thread.sleep(150);
            } catch (InterruptedException ex) {
                System.out.println(ex.getMessage());
            }
            System.out.println("Camello:" + hilo.getName() + " Avance " + pasos);

        } while (pasos < META);

        /*int i = 0;
        boolean salir = false;
        
        while (i < ganador.length && !salir) {

            if (ganador[i] == 0) {
                ganador[i] = Integer.parseInt(hilo.getName());
                salir = true;
            }
            i++;
        }*/
        }
    }
