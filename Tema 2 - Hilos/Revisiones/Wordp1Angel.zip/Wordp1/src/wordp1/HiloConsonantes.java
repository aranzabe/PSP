/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wordp1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;

/**
 *
 * @author angel
 */
public class HiloConsonantes extends Thread {

    private int conso = 0;
    private String f;

    public HiloConsonantes(String f) {
        this.f = f;
    }

    @Override
    public void run() {

        for (int i = 0; i < this.f.length(); i++) {
            char c = f.charAt(i);

            if (c != 'a' || c != 'e' || c != 'i' || c != 'o' || c != 'u' || c != 'A' || c != 'E' || c != 'I' || c != 'O' || c != 'U') {
                conso++;
            }
        }
        infoConso();
    }

    public void infoConso() {
        System.out.println("El numero de consonantes es " + conso);

    }

}
