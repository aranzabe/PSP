/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wordp1;

/**
 *
 * @author angel
 */
public class HiloEspacios extends Thread{
    private int esp=0;
    private String f;

    public HiloEspacios(String f) {
        this.f = f;
    }
    
    
    
    @Override
    public void run() {
        
        for (int i = 0; i < f.length(); i++) {

            char c = f.charAt(i);

            if (c == ' ' ) {
                esp++;

            }

        }
        infoEsp();
    }
    public void infoEsp(){
        System.out.println("El numero de espacios es " + esp);
        
        
    }
    
    
    
}
