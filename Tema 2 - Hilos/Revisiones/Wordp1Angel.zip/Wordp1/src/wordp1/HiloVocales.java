/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wordp1;



/**
 *
 * @author angel
 */
public class HiloVocales extends Thread {

    private int vocales = 0;
    private String f;

    public HiloVocales(String f) {
        this.f = f;
    }

    
    
    @Override
    public void run() {

        for (int i = 0; i < f.length(); i++) {

            char c = f.charAt(i);

            if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' || c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U') {
                vocales++;

            }

        }
        infoVoca();
    }
    public void infoVoca(){
        System.out.println("El numero de vocales es " + vocales);
        
        
    }
}