/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wordp1;


/**
 *
 * @author angel
 */
public class HiloPalabras extends Thread {

    private int conteoPalabras = 0;
    private boolean palabra = false;
    private String f;

    public HiloPalabras(String f) {
        this.f = f;
    }
    
    
    
    @Override
    public void run() {
        int finDeLinea = f.length() - 1;

        for (int i = 0; i < f.length(); i++) {
            if (Character.isLetter(f.charAt(i)) && i != finDeLinea) {
                palabra = true;
            } else if (!Character.isLetter(f.charAt(i)) && palabra) {
                conteoPalabras++;
                palabra = false;
            } else if (Character.isLetter(f.charAt(i)) && i == finDeLinea) {
                conteoPalabras++;
            }
        }
        infoPala();
    }
    
    public void infoPala(){
        System.out.println("El numero de palabras es " + conteoPalabras);
        
        
    }
}
