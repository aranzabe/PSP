/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wordp1;



/**
 *
 * @author angel
 */
public class HiloDigitos extends Thread {

    private int digitos = 0;
    private String f;

    public HiloDigitos(String f) {
        this.f = f;
    }
    

    @Override
    public void run() {

        for (int i = 0; i < f.length(); i++) {

            char c = f.charAt(i);

            if (Character.isDigit(c)) {
                digitos++;

            }

        }
        infoDigi();
    }
    public void infoDigi(){
        System.out.println("El numero de digitos es " + digitos);
        
        
    }

}
