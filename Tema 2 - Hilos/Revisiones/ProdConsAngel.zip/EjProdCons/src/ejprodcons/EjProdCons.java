/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejprodcons;

/**
 *
 * @author angel
 */
public class EjProdCons {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Recurso r = new Recurso();

        Productor p = new Productor("P", r);
        Consumidor c = new Consumidor(r, "Paco");
        Consumidor c1 = new Consumidor(r, "Francisco");
        Consumidor c2 = new Consumidor(r, "Luis");

        p.start();
        c.start();
        c1.start();
        c2.start();
    }

}
