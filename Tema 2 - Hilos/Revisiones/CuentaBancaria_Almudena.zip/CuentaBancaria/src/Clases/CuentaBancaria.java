package Clases;

/**
 *
 * @author Almudena
 */
public class CuentaBancaria {

    protected static int saldo = 1000;
   
    
    public static void main(String[] args) {
        
       //Cuentas de ingreso 
       CuentaIngreso ci1 = new CuentaIngreso (saldo);
       CuentaIngreso ci2 = new CuentaIngreso (saldo);
       CuentaIngreso ci3 = new CuentaIngreso (saldo);
       CuentaIngreso ci4 = new CuentaIngreso (saldo);
       CuentaIngreso ci5 = new CuentaIngreso (saldo);
       CuentaIngreso ci6 = new CuentaIngreso (saldo);
       CuentaIngreso ci7 = new CuentaIngreso (saldo);
       CuentaIngreso ci8 = new CuentaIngreso (saldo);
       CuentaIngreso ci9 = new CuentaIngreso (saldo);
       CuentaIngreso ci10 = new CuentaIngreso (saldo);
       //Cuentas de extracción
       CuentaExtraccion ce1 = new CuentaExtraccion (saldo);
       CuentaExtraccion ce2 = new CuentaExtraccion (saldo);
       CuentaExtraccion ce3 = new CuentaExtraccion (saldo);
       CuentaExtraccion ce4 = new CuentaExtraccion (saldo);
       CuentaExtraccion ce5 = new CuentaExtraccion (saldo);
       
       System.out.println("----- Saldo inicial ----- " + saldo + " €");
       
       ci1.start();
       ci2.start();
       ci3.start();
       ci4.start();
       ci5.start();
       ci6.start();
       ci7.start();
       ci8.start();
       ci9.start();
       ci10.start();
       ce1.start();
       ce2.start();
       ce3.start();
       ce4.start();
       ce5.start();
       
    }
    
}
