package Clases;

/**
 *
 * @author Almudena
 */
public class CuentaIngreso extends Thread{

    CuentaIngreso(int saldo) {
        
    }    
    
    @Override
    public void run() {
        int ingreso;
        int saldoactual;
        
        try {
            
            ingreso = (int) (Math.random() * 50 + 1);            
            saldoactual = CuentaBancaria.saldo += ingreso;   
            Thread.sleep(1000);
            System.out.println("Ingresar... " + ingreso + " € ------- Saldo actual ------ " + saldoactual + " €");            
        } catch (InterruptedException ex) {            
        }
    }
    
    
    
}
