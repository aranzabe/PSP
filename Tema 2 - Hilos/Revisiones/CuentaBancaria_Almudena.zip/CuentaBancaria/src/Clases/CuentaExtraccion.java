package Clases;

/**
 *
 * @author Almudena
 */
public class CuentaExtraccion extends Thread{
    
    public CuentaExtraccion(int saldo) {
        
    }
    
     @Override
    public void run() {
        int extraccion;
        int saldoactual;        
        
        try {            
            extraccion = (int) (Math.random()*50 + 1);            
            saldoactual = CuentaBancaria.saldo -= extraccion;    
            Thread.sleep(1000);
            System.out.println("Extraer... " + extraccion + " € ------- Saldo actual ------ " + saldoactual + " €");
            
        } catch (InterruptedException ex) {
            
        }
    }
}
