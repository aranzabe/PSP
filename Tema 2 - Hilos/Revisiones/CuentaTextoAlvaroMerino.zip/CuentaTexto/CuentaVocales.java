package CuentaTexto;

import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author Alvaro Merino
 */
public class CuentaVocales extends Thread {
    private int vocales;
    private JTextArea textArea;
    private JTextField textField;
    String texto;

    public CuentaVocales(JTextArea textArea, JTextField textField) {
        this.textArea=textArea;
        this.textField=textField;
    }
    
    
    @Override
    public void run() {
         texto= textArea.getText().toLowerCase();
        for(int i=0;i<texto.length();i++){
            if(texto.charAt(i)=='a' || texto.charAt(i)=='e' || texto.charAt(i)=='i' || texto.charAt(i)=='o' || texto.charAt(i)=='u'){
                vocales++;
            }
        }
        //System.out.println("Números de vocales: "+vocales);
        textField.setText(Integer.toString(vocales));
        
    }
    
}
