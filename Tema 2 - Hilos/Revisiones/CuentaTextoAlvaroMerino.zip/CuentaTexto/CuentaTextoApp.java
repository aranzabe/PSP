package CuentaTexto;

/**
 *
 * @author Alvaro Merino
 * 
 */
public class CuentaTextoApp {
    public static void main(String[] args) {
        /*String texto="Simular una cuenta bancaria con dos hilos. Uno simulará el ingreso y el otro la " +
        "extracción de dinero de la cuenta. La cuenta tendrá un capital inicial. Realizar 10 " +
        "ingresos y 5 extracciones.";
        
        CuentaVocales contarvocales = new CuentaVocales(texto);
        CuentaPalabras contarpalabras = new CuentaPalabras(texto);
        
        
        contarvocales.start();
        contarpalabras.start();*/
        
        
    }
    
    
}
