package CuentaTexto;

import java.util.StringTokenizer;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author Alvaro Merino
 */
public class CuentaPalabras extends Thread {
    private int espacios;
    private JTextArea textArea;
    private JTextField textFieldPalabras;
    private JTextField textFieldEspacios;
    String texto;

    public CuentaPalabras(JTextArea textArea, JTextField textFieldPalabras, JTextField textFieldEspacios) {
        this.textArea = textArea;
        this.textFieldPalabras = textFieldPalabras;
        this.textFieldEspacios = textFieldEspacios;
    }

    

    @Override
    public void run() {
        texto = textArea.getText().toLowerCase();
        StringTokenizer st = new StringTokenizer(texto);
        textFieldPalabras.setText(Integer.toString(st.countTokens()));
        int espacios=0;
        for (int i = 0; i < this.texto.length(); i++) {
            
            if (this.texto.charAt(i) == ' ') espacios++;
        }
        textFieldEspacios.setText(Integer.toString(espacios));
        
        
    }
    
    
}
