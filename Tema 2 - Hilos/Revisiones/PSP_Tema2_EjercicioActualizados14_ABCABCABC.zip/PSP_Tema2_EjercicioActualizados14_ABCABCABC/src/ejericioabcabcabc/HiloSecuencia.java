/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejericioabcabcabc;

import java.util.concurrent.Semaphore;
/**
 *
 * @author ivanc
 */
public class HiloSecuencia extends Thread {
    
    private static final Semaphore ordenSecuencia = new Semaphore(1);
    
    @Override
    public void run() {  
        HiloEscribirA ha = new HiloEscribirA();
        HiloEscribirB hb = new HiloEscribirB();
        HiloEscribirC hc = new HiloEscribirC();
        if (ordenSecuencia.tryAcquire()){
            try {
                ha.start();
                ha.join();
                hb.start();
                hb.join();
                hc.start();
                hc.join();
                ordenSecuencia.release();
            } catch (InterruptedException ex) {}
        }else{
        }
    }
}
