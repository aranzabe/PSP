/*
 * 14º Se crean tres hilos de manera que uno ejecuta escribirA, otro escribirB y el tercero
 * escribirC. Introduce los semáforos oportunos para que la salida sea:
 * ABCABCABCABCABCABC.
 */
package ejericioabcabcabc;

/**
 *
 * @author ivanc
 */
public class PSP_Tema2_EjercicioActualizados14_ABCABCABC {

    /**
     * @param args the command line arguments
     * @throws java.lang.InterruptedException
     */
    public static void main(String[] args) throws InterruptedException {
        int i;
        HiloSecuencia secuencias[] = new HiloSecuencia[5];
        for (i = 0; i < secuencias.length; i++) {
            secuencias[i] = new HiloSecuencia();
        }
        for (i = 0; i < secuencias.length; i++) {
            secuencias[i].start();
            secuencias[i].join();
        }        
    }
}
