/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package word;

import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author disen
 */
public class HiloVocales extends Thread {
    private JTextArea texto;
    private JTextField contadorVocales;
    private int contador;

    public HiloVocales(JTextArea texto,JTextField contadorVocales) {
        this.contadorVocales = contadorVocales;
        this.texto = texto;
    }

    public int getContador() {
        return contador;
    }

    public void setContador(int contador) {
        this.contador = contador;
    }
    
    
    
    @Override
	public synchronized void run()  {
            String vocales="aeiouAEIOU";
            String text=texto.getText();
            for(int i = 0; i < text.length(); i++) {
                for(int j=0;j<vocales.length();j++){
                    if(text.charAt(i)==vocales.charAt(j)){
                    
                    contador++;
                }
            }
            }
            
            this.contadorVocales.setText(String.valueOf(this.contador));
        }
}
